﻿# -*- coding: utf-8 -*-
import lib3sat

lib3sat.list()