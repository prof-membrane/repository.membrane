﻿# -*- coding: utf-8 -*-
from lib3sat import *
import xbmc
list()