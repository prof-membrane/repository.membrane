﻿# -*- coding: utf-8 -*-
from lib3sat import *
import xbmc
xbmc.log(str(lib3satListMain()))
#from libMediathek import *
list()