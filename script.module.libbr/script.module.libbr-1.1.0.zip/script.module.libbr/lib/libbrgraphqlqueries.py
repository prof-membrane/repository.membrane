# -*- coding: utf-8 -*-

import libmediathek3 as libmediathek

def getQueryShows(letter=''):
	return _dependencyBuilder(Dquery_SearchPageQuery)
def getQueryEpisodes():
	return _dependencyBuilder(Dquery_SeriesPageRendererQuery)
def getQueryVideo():#TODO: path
	return Squery_DetailPageRendererQuery
def getQueryDate():
	return _dependencyBuilder(Dquery_ProgrammeContainerRefetchQuery)

def _dependencyBuilder(base):
	l = [base[0]]
	for subDep in base[1]:
		l = _addDep(subDep,l)
	
	result = ''
	for s in l:
		result += s
	return result.replace('\\n','').replace('\n','').replace('\r','')
	
def _addDep(dep,l):
	if dep[0] not in l:
		l.append(dep[0])
		for subDep in dep[1]:
			l = _addDep(subDep,l)
	return l

	
	
#Strings for queries
Squery_SearchPageQuery = """query SearchPageQuery(
  $letter: String
) { 
  viewer {
    ...Search_viewer
    id
  }
}"""

Squery_SeriesPageRendererQuery = """query SeriesPageRendererQuery(
  $id: ID!
  $itemCount: Int
  $clipCount: Int
  $previousEpisodesFilter: ProgrammeFilter
  $clipsOnlyFilter: ProgrammeFilter
) {
  viewer {
    ...SeriesPage_viewer_2PDDaq
    id
  }
}"""

Squery_DetailPageRendererQuery = """query DetailPageRendererQuery(
  $clipId: ID!
  $isClip: Boolean!
  $isLivestream: Boolean!
  $livestream: ID!
) {
  viewer {
    ...DetailPage_viewer_22r5xP
    id
  }
}

fragment DetailPage_viewer_22r5xP on Viewer {
  ...VideoPlayer_viewer_22r5xP
  detailClip: clip(id: $clipId) {
    __typename
    id
    title
  }
}

fragment VideoPlayer_viewer_22r5xP on Viewer {
  id
  clip(id: $clipId) @include(if: $isClip) {
    __typename
    id
    ageRestriction
    videoFiles(first: 100) {
      edges {
        node {
          __typename
          id
          mimetype
          publicLocation
          videoProfile {
            __typename
            id
            width
          }
        }
      }
    }
    title
    defaultTeaserImage @include(if: $isClip) {
      __typename
      imageFiles(first: 1) {
        edges {
          node {
            __typename
            id
            publicLocation
            crops(first: 1) {
              edges {
                node {
                  __typename
                  publicLocation
                  id
                }
              }
            }
          }
        }
      }
      id
    }
    ... on ProgrammeInterface {
      episodeOf {
        __typename
        defaultTeaserImage @include(if: $isClip) {
          __typename
          imageFiles(first: 1) {
            edges {
              node {
                __typename
                id
                publicLocation
                crops(first: 1) {
                  edges {
                    node {
                      __typename
                      publicLocation
                      id
                    }
                  }
                }
              }
            }
          }
          id
        }
        id
      }
    }
    myInteractions {
      __typename
      completed
      progress
      id
    }
    ...Settings_clip
  }
  livestream(id: $livestream) @include(if: $isLivestream) {
    __typename
    id
    streamingUrls(first: 10, filter: {accessibleIn: {contains: "GeoZone:http://ard.de/ontologies/coreConcepts#GeoZone_World"}, hasEmbeddedSubtitles: {eq: false}}) {
      edges {
        node {
          __typename
          id
          publicLocation
        }
      }
    }
  }
}

fragment Settings_clip on ClipInterface {
  videoFiles(first: 100) {
    edges {
      node {
        __typename
        id
        mimetype
        publicLocation
        videoProfile {
          __typename
          id
          width
          height
        }
      }
    }
  }
}"""

Squery_ProgrammeContainerRefetchQuery = """

query ProgrammeContainerRefetchQuery(
  $broadcastServiceId: ID!
  $programmeFilter: ProgrammeFilter!
) {
  viewer {
    broadcastService(id: $broadcastServiceId) {
      __typename
      ...ProgrammeContainer_broadcastService_fYjpM
      id
    }
    id
  }
}"""


#Strings for fragments

Sfragment_Search_viewer = """

fragment Search_viewer on Viewer {
  ...SeriesIndex_viewer
}"""

Sfragment_SeriesIndex_viewer = """

fragment SeriesIndex_viewer on Viewer {
  seriesIndexAllSeries: allSeries(first: 1000, orderBy: TITLE_ASC, filter: {title: {startsWith: "A"}, audioOnly: {eq: false}, status: {id: {eq: "Status:http://ard.de/ontologies/lifeCycle#published"}}}) {
    edges {
      node {
        __typename
        id
        title
        ...SeriesTeaserBox_node
        ...TeaserListItem_node
      }
    }
  }
}"""

#Added: kicker, description, shortDescription
Sfragment_SeriesIndex_viewer = """

fragment SeriesIndex_viewer on Viewer {
  seriesIndexAllSeries: allSeries(first: 1000, orderBy: TITLE_ASC, filter: {title: {startsWith: $letter}, audioOnly: {eq: false}, status: {id: {eq: "Status:http://ard.de/ontologies/lifeCycle#published"}}}) {
    edges {
      node {
        __typename
        id
        title
        kicker
        description
        shortDescription
        ...SeriesTeaserBox_node
        ...TeaserListItem_node
      }
    }
  }
}"""

Sfragment_SeriesTeaserBox_node = """

fragment SeriesTeaserBox_node on Node {
  __typename
  id
  ... on CreativeWorkInterface {
    ...TeaserImage_creativeWorkInterface
  }
  ... on SeriesInterface {
    ...SubscribeAction_series
    subscribed
    title
  }
}
"""
Sfragment_TeaserListItem_node = """

fragment TeaserListItem_node on Node {
  __typename
  id
  ... on CreativeWorkInterface {
    ...TeaserImage_creativeWorkInterface
  }
  ... on ClipInterface {
    title
  }
}"""

Sfragment_TeaserImage_creativeWorkInterface = """

fragment TeaserImage_creativeWorkInterface on CreativeWorkInterface {
  id
  kicker
  title
  teaserImages(first: 1) {
    edges {
      node {
        __typename
        shortDescription
        id
      }
    }
  }
  defaultTeaserImage {
    __typename
    imageFiles(first: 1) {
      edges {
        node {
          __typename
          id
          publicLocation
          crops(first: 10) {
            count
            edges {
              node {
                __typename
                publicLocation
                width
                height
                id
              }
            }
          }
        }
      }
    }
    id
  }
}"""

Sfragment_SubscribeAction_series = """

fragment SubscribeAction_series on SeriesInterface {
  id
  subscribed
}"""


Sfragment_SeriesPage_viewer_2PDDaq = """

fragment SeriesPage_viewer_2PDDaq on Viewer {
  series(id: $id) {
    __typename
    ...TeaserImage_creativeWorkInterface
    ...SeriesBrandBanner_series
    ...ChildContentRedirect_creativeWork
    clipsOnly: episodes(orderBy: VERSIONFROM_DESC, first: $clipCount, filter: $clipsOnlyFilter) {
      ...ProgrammeSlider_programmes
    }
    previousEpisodes: episodes(first: $itemCount, orderBy: BROADCASTS_START_DESC, filter: $previousEpisodesFilter) {
      ...ProgrammeSlider_programmes
      edges {
        node {
          __typename
          ...SmallTeaserBox_node
          id
        }
      }
    }
    id
  }
}"""

Sfragment_SeriesBrandBanner_series = """

fragment SeriesBrandBanner_series on SeriesInterface {
  ...SubscribeAction_series
  title
  shortDescription
  externalURLS(first: 1) {
    edges {
      node {
        __typename
        id
        url
        label
      }
    }
  }
  brandingImages(first: 1) {
    edges {
      node {
        __typename
        imageFiles(first: 1) {
          edges {
            node {
              __typename
              publicLocation
              id
            }
          }
        }
        id
      }
    }
  }
}"""

Sfragment_SubscribeAction_series = """

fragment SubscribeAction_series on SeriesInterface {
  id
  subscribed
}"""

Sfragment_ChildContentRedirect_creativeWork = """

fragment ChildContentRedirect_creativeWork on CreativeWorkInterface {
  categories(first: 100) {
    edges {
      node {
        __typename
        id
      }
    }
  }
}"""

Sfragment_ProgrammeSlider_programmes = """

fragment ProgrammeSlider_programmes on ProgrammeConnection {
  edges {
    node {
      __typename
      ...SmallTeaserBox_node
      id
    }
  }
}"""

#Added: description, shortDescription
Sfragment_SmallTeaserBox_node = """

fragment SmallTeaserBox_node on Node {
  id
  ... on CreativeWorkInterface {
    ...TeaserImage_creativeWorkInterface
  }
  ... on ClipInterface {
    id
    title
    kicker
    description
    shortDescription
    ...Bookmark_clip
    ...Duration_clip
    ...Progress_clip
  }
  ... on ProgrammeInterface {
    broadcasts(first: 1, orderBy: START_DESC) {
      edges {
        node {
          __typename
          start
          id
        }
      }
    }
  }
}"""

Sfragment_Bookmark_clip = """

fragment Bookmark_clip on ClipInterface {
  id
  bookmarked
  title
}"""

Sfragment_Duration_clip = """

fragment Duration_clip on ClipInterface {
  duration
}"""

Sfragment_Progress_clip = """

fragment Progress_clip on ClipInterface {
  myInteractions {
    __typename
    progress
    completed
    id
  }
}"""



Sfragment_ProgrammeTeaserBox_programme = """

fragment ProgrammeTeaserBox_programme on ProgrammeInterface {
  title
  broadcasts(first: 1) {
    edges {
      node {
        __typename
        start
        end
        id
      }
    }
  }
  ... on CreativeWorkInterface {
    ...TeaserImage_creativeWorkInterface
  }
  ... on ClipInterface {
    title
    kicker
    essences(first: 1) {
      count
    }
    ...Bookmark_clip
    ...Duration_clip
  }
}"""


Sfragment_ProgrammeTableRow_programme = """

fragment ProgrammeTableRow_programme on ProgrammeInterface {
  ...ProgrammeTeaserBox_programme
  title
  kicker
  broadcasts(first: 1) {
    edges {
      node {
        __typename
        start
        end
        id
      }
    }
  }
  id
}"""


Sfragment_ProgrammeTable_programmes = """

fragment ProgrammeTable_programmes on ProgrammeConnection {
  edges {
    node {
      __typename
      id
      ...ProgrammeTableRow_programme
    }
  }
}"""


Sfragment_ProgrammeContainer_broadcastService_fYjpM = """

fragment ProgrammeContainer_broadcastService_fYjpM on BroadcastServiceInterface {
  id
  containerToday: programmes(first: 96, orderBy: BROADCASTS_START_ASC, filter: $programmeFilter) {
    ...ProgrammeTable_programmes
  }
}"""

#Dependencies tree
Dfragment_SubscribeAction_series 					= [Sfragment_SubscribeAction_series,					[]]
Dfragment_TeaserImage_creativeWorkInterface			= [Sfragment_TeaserImage_creativeWorkInterface,			[]]
Dfragment_TeaserListItem_node						= [Sfragment_TeaserListItem_node,						[Dfragment_TeaserImage_creativeWorkInterface]]
Dfragment_SeriesTeaserBox_node						= [Sfragment_SeriesTeaserBox_node,						[Dfragment_TeaserImage_creativeWorkInterface,Dfragment_SubscribeAction_series]]
Dfragment_SeriesIndex_viewer						= [Sfragment_SeriesIndex_viewer,						[Dfragment_SeriesTeaserBox_node,Dfragment_TeaserListItem_node]]
Dfragment_Search_viewer 							= [Sfragment_Search_viewer,								[Dfragment_SeriesIndex_viewer]]

Dfragment_Progress_clip 							= [Sfragment_Progress_clip,								[]]
Dfragment_Duration_clip 							= [Sfragment_Duration_clip,								[]]
Dfragment_Bookmark_clip 							= [Sfragment_Bookmark_clip,								[]]
Dfragment_SmallTeaserBox_node 						= [Sfragment_SmallTeaserBox_node,						[Dfragment_TeaserImage_creativeWorkInterface,Dfragment_Bookmark_clip,Dfragment_Duration_clip,Dfragment_Progress_clip]]
Dfragment_ProgrammeSlider_programmes		 		= [Sfragment_ProgrammeSlider_programmes,				[Dfragment_SmallTeaserBox_node]]
Dfragment_ChildContentRedirect_creativeWork			= [Sfragment_ChildContentRedirect_creativeWork,			[]]
Dfragment_SubscribeAction_series					= [Sfragment_SubscribeAction_series,					[]]
Dfragment_SeriesBrandBanner_series					= [Sfragment_SeriesBrandBanner_series,					[Dfragment_SubscribeAction_series]]
Dfragment_SeriesPage_viewer_2PDDaq					= [Sfragment_SeriesPage_viewer_2PDDaq,					[Dfragment_TeaserImage_creativeWorkInterface,Dfragment_SeriesBrandBanner_series,Dfragment_ChildContentRedirect_creativeWork,Dfragment_ProgrammeSlider_programmes,Dfragment_SmallTeaserBox_node]]

Dfragment_ProgrammeTeaserBox_programme				= [Sfragment_ProgrammeTeaserBox_programme,				[Dfragment_TeaserImage_creativeWorkInterface,Dfragment_Duration_clip,Dfragment_Bookmark_clip]]
Dfragment_ProgrammeTableRow_programme				= [Sfragment_ProgrammeTableRow_programme,				[Dfragment_ProgrammeTeaserBox_programme]]
Dfragment_ProgrammeTable_programmes					= [Sfragment_ProgrammeTable_programmes,					[Dfragment_ProgrammeTableRow_programme]]
Dfragment_ProgrammeContainer_broadcastService_fYjpM = [Sfragment_ProgrammeContainer_broadcastService_fYjpM, [Dfragment_ProgrammeTable_programmes]]

Dquery_SearchPageQuery								= [Squery_SearchPageQuery,								[Dfragment_Search_viewer]]
Dquery_SeriesPageRendererQuery						= [Squery_SeriesPageRendererQuery,						[Dfragment_SeriesPage_viewer_2PDDaq]]
Dquery_ProgrammeContainerRefetchQuery				= [Squery_ProgrammeContainerRefetchQuery,				[Dfragment_ProgrammeContainer_broadcastService_fYjpM]]