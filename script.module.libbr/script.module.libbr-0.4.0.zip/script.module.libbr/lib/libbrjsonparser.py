# -*- coding: utf-8 -*-
import xbmc
import json
import urllib

import libmediathek3 as libMediathek

pluginpath = 'plugin://script.module.libArd/'
chan = {"BR":"channel_28107",
		"br":"channel_28107",
		"ARD-Alpha":"channel_28487",
		"ardalpha":"channel_28487"}

def _parseMain():
	response = libMediathek.getUrl("http://www.br.de/system/halTocJson.jsp")
	j = json.loads(response)
	url = j["medcc"]["version"]["1"]["href"]
	response = libMediathek.getUrl(url)
	return json.loads(response)
	
def parseShows(letter):
	j = _parseMain()
	url = j["_links"]["broadcastSeriesAz"]["href"]
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	url = j['az']['_links'][letter.lower()]['href']
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	list = []
	for show in j["_embedded"]["teasers"]:
		#xbmc.log(str(show))
		dict = {}
		dict['url'] = show["_links"]["self"]["href"]
		dict['_name'] = show["headline"]
		dict['_tvshowtitle'] = show["topline"]
		if 'br-core:teaserText' in show["documentProperties"]:
			dict['_plot'] = show["documentProperties"]["br-core:teaserText"]
		try: dict['_thumb'] = show['teaserImage']['_links']['original']['href']
		except: pass
		dict['_type'] = 'shows'
		dict['mode'] = 'libBrListVideos'
		
		list.append(dict)
	return list
	
def search(searchString):
	j = _parseMain()
	url = j["_links"]["search"]["href"].replace('{term}',urllib.quote_plus(searchString))
	return parseLinks(url)
	
def parseVideos(url):
	if not 'latestVideos' in url:
		response = libMediathek.getUrl(url)
		j = json.loads(response)
		if "_links" in j and 'latestVideos' in j["_links"]:
			url = j["_links"]["latestVideos"]["href"]
		else: return []
	return parseLinks(url)
	
def parseLinks(url):
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	list = []
	if not '_embedded' in j:
		return list
	for show in j["_embedded"]["teasers"]:
		dict = {}
		dict['url'] = show["_links"]["self"]["href"]
		dict['_name'] = show["topline"]
		if 'headline' in show:
			dict['_name'] += ' - ' + show['headline']
			dict['_tvshowtitle'] = show['topline']
			
		dict['_subtitle'] = show["topline"]
		dict['_plot'] = show["teaserText"]
		dict['_channel'] = show["channelTitle"]
		duration = show['documentProperties']["br-core:duration"].split(':')
		dict['_duration'] = str(int(duration[0]) * 3600 + int(duration[1]) * 60 + int(duration[2]))
		
		xbmc.log(str(show["teaserImage"]["_links"]))#image512
		if 'image512' in show["teaserImage"]["_links"]:
			dict['_thumb'] = show["teaserImage"]["_links"]["image512"]["href"]
		elif 'image256' in show["teaserImage"]["_links"]:
			dict['_thumb'] = show["teaserImage"]["_links"]["image256"]["href"]
		try:
			if show['hasSubtitle']:
				dict['_hasSubtitle'] = 'true'
				#dict['plot'] += '\n\nUntertitel'
		except:pass
		dict['_type'] = 'video'
		dict['mode'] = 'libBrPlay'
		
		list.append(dict)
	try:
		dict = {}
		dict['_type'] = 'nextPage'
		dict['url'] = j['_embedded']['_links']['next']['href']
		list.append(dict)
	except: pass
	return list
	
def parseDate(date,channel='BR'):
	import time
	j = _parseMain()
	#xbmc.log(str(j))
	url = j["_links"]["epg"]["href"]
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	url = j["epgDays"]["_links"][date]["href"]#date: 2016-12-30
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	#xbmc.log(str(j))
	list = []
	broadcasts = j["channels"][chan[channel]]["broadcasts"]
	for b in broadcasts:
		if "_links" in b and "video" in b["_links"]:
			xbmc.log(str(b))
			dict = {}
			dict["_name"] = b["headline"]
			if len(b["subTitle"]) > 0:
				dict['_name'] += ' - ' + b["subTitle"]
			dict["_plot"] = b["subTitle"]
			dict["_tvshowtitle"] = b["hasSubtitle"]
			dict["url"] = b["_links"]["video"]["href"]
			#2016-10-14T08:50:00+02:00
			dict["_epoch"] = int(time.mktime(time.strptime(b["broadcastStartDate"].split('+')[0], '%Y-%m-%dT%H:%M:%S')))
			dict["_epoch"] = str(dict["_epoch"])
			dict["_time"] = startTimeToInt(b["broadcastStartDate"][11:19])
			dict['_date'] = b["broadcastStartDate"][11:16]
			dict['_duration'] = (startTimeToInt(b["broadcastEndDate"][11:19]) - startTimeToInt(b["broadcastStartDate"][11:19])) * 60
			if dict['_duration'] < 0:
				dict['_duration'] = 86400 - abs(dict['_duration'])
			#TODO: rest of properties
			if b['hasSubtitle']:
				dict['_hasSubtitle'] = 'true'
				#dict['_plot'] += '\n\nUntertitel'
			dict['_type'] = 'date'
			dict['mode'] = 'libBrPlay'
			list.append(dict)
	return list
			
	
def parse(url):
	list = []
	response = libMediathek.getUrl(url)
	j = json.loads(response)

def parseVideo(url):#TODO grep the plot and other metadata from here
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	d = {}
	d['media'] = []
	assets = j["assets"]
	if 'dataTimedTextUrl' in j['_links']:
		d['subtitle'] = [{'url':j['_links']['dataTimedTextUrl']['href'], 'type':'ttml', 'lang': 'de'}]
		
	for asset in assets:
		if "type" in asset and asset["type"] == "HLS_HD":
			d['media'].append({'url':asset["_links"]["stream"]["href"], 'type': 'video', 'stream':'HLS'})
			return d
	for asset in assets:
		if "type" in asset and asset["type"] == "HLS":
			d['media'].append({'url':asset["_links"]["stream"]["href"], 'type': 'video', 'stream':'HLS'})
			return d
def startTimeToInt(s):
	HH,MM,SS = s.split(":")
	return int(HH) * 60 + int(MM)