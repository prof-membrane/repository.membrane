# -*- coding: utf-8 -*-
import json
import urllib

import libmediathek3 as libMediathek
import libbrgraphqlqueries

graphqlUrl = 'https://proxy-base.master.mango.express/graphql'
header = {'Content-Type':'application/json'	, 'Accept-Encoding':'gzip, deflate'}
chan = {"BR":"channel_28107",
		"br":"channel_28107",
		"ARD-Alpha":"channel_28487",
		"ardalpha":"channel_28487"}

	
def parseShows(letter):
	variables = {'letter':letter}
	p = json.dumps({'query': libbrgraphqlqueries.getQueryShows(letter), 'variables':variables})
	#header['Content-Length'] = len(p)
	response = libMediathek.getUrl(graphqlUrl,header,post=p)
	libMediathek.log(response)
	j = json.loads(response)
	l = []
	for edge in j['data']['viewer']['seriesIndexAllSeries']['edges']:
		d = {}
		node = edge['node']
		d['_name'] = node['title']
		d['_tvshowtitle'] = node['kicker']
		d['_plotoutline'] = node['kicker']
		d['_plot'] = node['kicker']
		if node['shortDescription'] != None:
			d['_plotoutline'] = node['shortDescription']
			d['_plot'] = node['shortDescription']
		if node['description'] != None:
			d['_plot'] = node['description']
		d['_thumb'] = node['defaultTeaserImage']['imageFiles']['edges'][0]['node']['publicLocation']
		#libMediathek.log(d['_thumb'])
		d['_type'] = 'dir'
		d['id'] = node['id']
		d['mode'] = 'libBrListVideos'
		l.append(d)
	return l
	
def parseDate(date,channel):
	#{"broadcastServiceId":"BroadcastService:http://ard.de/ontologies/ard#BR_Fernsehen",
	#"programmeFilter":{"status":{"id":{"eq":"Status:http://ard.de/ontologies/lifeCycle#published"}},
	#"broadcasts":{"start":{"gte":"2017-09-12T10:00:00.000Z","lte":"2017-09-13T04:00:00.000Z"}}}}
	programmeFilter = {'status':{'id':{'eq':'Status:http://ard.de/ontologies/lifeCycle#published'}}}
	broadcasts = {'start':{"gte":date+"T10:00:00.000Z","lte":date+"T23:59:59.000Z"}}
	variables = {'broadcastServiceId':'BroadcastService:http://ard.de/ontologies/ard#BR_Fernsehen', 'programmeFilter':programmeFilter, 'broadcasts':broadcasts}
	p = json.dumps({'query': libbrgraphqlqueries.getQueryDate(), 'variables':variables})
	#header['Content-Length'] = len(p)
	response = libMediathek.getUrl(graphqlUrl,header,post=p)
	libMediathek.log(response)
	j = json.loads(response)
	l = []
	for edge in j['data']['viewer']['broadcastService']['containerToday']['edges']:
		d = {}
		node = edge['node']
		d['_name'] = node['title']
		d['_tvshowtitle'] = node['kicker']
		d['_plotoutline'] = node['kicker']
		d['_plot'] = node['kicker']
		if 'shortDescription' in node and node['shortDescription'] != None:
			d['_plotoutline'] = node['shortDescription']
			d['_plot'] = node['shortDescription']
		if 'description' in node and node['description'] != None:
			d['_plot'] = node['description']
		d['_duration'] = str(node['duration'])
		d['_thumb'] = node['defaultTeaserImage']['imageFiles']['edges'][0]['node']['publicLocation']
		#libMediathek.log(d['_thumb'])
		d['_type'] = 'video'
		d['id'] = node['id']
		d['mode'] = 'libBrPlay'
		l.append(d)
	return l

		
	
def parseVideos(id):
	variables = {'id':id,"itemCount":31,"clipCount":6,"previousEpisodesFilter":{"essences":{"empty":{"eq":False}},"broadcasts":{"empty":{"eq":False},"start":{"lte":"2017-09-13T17:00:28.592Z"}}},"clipsOnlyFilter":{"broadcasts":{"empty":{"eq":True}},"essences":{"empty":{"eq":False}}}}
	p = json.dumps({'query': libbrgraphqlqueries.getQueryEpisodes(), 'variables':variables})
	#p = p[:-1] + ', "variables":{"id":"Series:584f4c523b467900117c0f47","itemCount":31,"clipCount":6,"previousEpisodesFilter":{"essences":{"empty":{"eq":false}},"broadcasts":{"empty":{"eq":false},"start":{"lte":"2017-09-13T17:00:28.592Z"}}},"clipsOnlyFilter":{"broadcasts":{"empty":{"eq":true}},"essences":{"empty":{"eq":false}}}}}'
	response = libMediathek.getUrl(graphqlUrl,header,post=p)
	libMediathek.log(response)
	j = json.loads(response)
	l = []
	for edge in j['data']['viewer']['series']['previousEpisodes']['edges']:
		d = {}
		node = edge['node']
		d['_name'] = node['title']
		d['_tvshowtitle'] = node['kicker']
		d['_plotoutline'] = node['kicker']
		d['_plot'] = node['kicker']
		if node['shortDescription'] != None:
			d['_plotoutline'] = node['shortDescription']
			d['_plot'] = node['shortDescription']
		if node['description'] != None:
			d['_plot'] = node['description']
		d['_duration'] = str(node['duration'])
		d['_thumb'] = node['defaultTeaserImage']['imageFiles']['edges'][0]['node']['publicLocation']
		#libMediathek.log(d['_thumb'])
		d['_type'] = 'video'
		d['id'] = node['id']
		d['mode'] = 'libBrPlay'
		l.append(d)
	return l
	
def parseVideo(id):
	variables = {'clipId':id, 'isClip':True, 'isLivestream':False, 'livestream':'Livestream:'}
	p = json.dumps({'query': libbrgraphqlqueries.getQueryVideo(), 'variables':variables})
	#p = p[:-1] + ', "variables":{"id":"Series:584f4c523b467900117c0f47","itemCount":31,"clipCount":6,"previousEpisodesFilter":{"essences":{"empty":{"eq":false}},"broadcasts":{"empty":{"eq":false},"start":{"lte":"2017-09-13T17:00:28.592Z"}}},"clipsOnlyFilter":{"broadcasts":{"empty":{"eq":true}},"essences":{"empty":{"eq":false}}}}}'
	response = libMediathek.getUrl(graphqlUrl,header,post=p)
	libMediathek.log(response)
	j = json.loads(response)
	l = []
	
	for edge in j['data']['viewer']['clip']['videoFiles']['edges']:
		d = {}
		node = edge['node']
		url = node['publicLocation']
		if 'm3u8' in url:
			videoUrl = url
	d = {}
	d['media'] = []
	d['media'].append({'url':videoUrl, 'stream':'HLS'})
	return d
	

def parseVideoOld(url):#TODO grep the plot and other metadata from here
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	d = {}
	d['media'] = []
	assets = j["assets"]
	#if 'dataTimedTextUrl' in j['_links']:
	#	d['subtitle'] = [{'url':j['_links']['dataTimedTextUrl']['href'], 'type':'ttml', 'lang': 'de'}]
		
	for asset in assets:
		if "type" in asset and asset["type"] == "HLS_HD":
			d['media'].append({'url':asset["_links"]["stream"]["href"], 'type': 'video', 'stream':'HLS'})
			return d
	for asset in assets:
		if "type" in asset and asset["type"] == "HLS":
			d['media'].append({'url':asset["_links"]["stream"]["href"], 'type': 'video', 'stream':'HLS'})
			return d
	
def search(searchString):
	j = _parseMain()
	url = j["_links"]["search"]["href"].replace('{term}',urllib.quote_plus(searchString))
	return parseLinks(url)
def parseLinks(url):
	response = libMediathek.getUrl(url)
	j = json.loads(response)
	l = []
	if not '_embedded' in j:
		return l
	for show in j["_embedded"]["teasers"]:
		d = {}
		d['url'] = show["_links"]["self"]["href"]
		d['_name'] = show["topline"]
		if 'headline' in show:
			d['_name'] += ' - ' + show['headline']
			d['_tvshowtitle'] = show['topline']
			
		d['_subtitle'] = show["topline"]
		d['_plot'] = show["teaserText"]
		d['_channel'] = show["channelTitle"]
		duration = show['documentProperties']["br-core:duration"].split(':')
		d['_duration'] = str(int(duration[0]) * 3600 + int(duration[1]) * 60 + int(duration[2]))
		
		if 'image512' in show["teaserImage"]["_links"]:
			d['_thumb'] = show["teaserImage"]["_links"]["image512"]["href"]
		elif 'image256' in show["teaserImage"]["_links"]:
			d['_thumb'] = show["teaserImage"]["_links"]["image256"]["href"]
		try:
			if show['hasSubtitle']:
				d['_hasSubtitle'] = 'true'
				#d['plot'] += '\n\nUntertitel'
		except:pass
		d['_type'] = 'video'
		d['mode'] = 'libBrPlayOld'
		
		l.append(d)
	try:
		d = {}
		d['_type'] = 'nextPage'
		d['url'] = j['_embedded']['_links']['next']['href']
		l.append(d)
	except: pass
	return l
			
	
def parse(url):
	l = []
	response = libMediathek.getUrl(url)
	j = json.loads(response)

def startTimeToInt(s):
	HH,MM,SS = s.split(":")
	return int(HH) * 60 + int(MM)