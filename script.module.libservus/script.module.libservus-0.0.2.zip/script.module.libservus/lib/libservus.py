# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import libmediathek3 as libMediathek
import libservusjsonparser

translation = libMediathek.getTranslation




def libServusListMain():
	l = []
	l.append({'_name':'Unterhaltung', 'mode':'libServusListShows', 'id':'1252976591205'})
	l.append({'_name':'Kultur', 'mode':'libServusListShows', 'id':'1252976589416'})
	l.append({'_name':'Sport', 'mode':'libServusListShows', 'id':'1252976590818'})
	l.append({'_name':'Entdecken', 'mode':'libServusListShows', 'id':'1252976590352'})
	#l.append({'_name':'Red Bull TV', 'mode':'libServusListShows', 'id':'1259334421241'})
	return l
	
def libServusListShows():
	return libservusjsonparser.parseShows(params['id'])
	
def libServusListEpisodes():
	return libservusjsonparser.parseEpisodes(params['id'])
	
def libServusPlay():
	
	
	
	d = {'media': [{'url':params['url'], 'type': 'video', 'stream':'http'}]}
	
	return d
	#return libServusParser.parseVideo(params['url'])
	
	
def list():	
	modes = {
	'libServusListMain': libServusListMain,
	'libServusListShows': libServusListShows,
	'libServusListEpisodes': libServusListEpisodes,
	#'libServusListVideos': libServusListVideos,
	'libServusPlay': libServusPlay
	}
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	mode = params.get('mode','libServusListMain')
	if mode == 'libServusPlay':
		libMediathek.play(libServusPlay())
	else:
		xbmc.log
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
