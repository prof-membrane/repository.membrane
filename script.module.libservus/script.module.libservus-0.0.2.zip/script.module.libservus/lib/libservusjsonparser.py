# -*- coding: utf-8 -*-
import xbmc
import json
import re
#import dateutil.parser
import libmediathek3 as libMediathek

def parseShows(id):
	l = []
	url = 'http://www.servustv.com/at/smarttv/get_shows?pagename=ServusTV/JSON/samsungtvapi&callback=callback&command=get_shows&limit=100&offset=0&category_id=' + id
	response = libMediathek.getUrl(url)[13:-2]
	j = json.loads(response)
	for data in j['data']:
		d = {}
		d['_name'] = data['title']
		d['_thumb'] = data['image_url']
		d['id'] = data['id']
		d['_type'] = 'dir'
		d['mode'] = 'libServusListEpisodes'
		l.append(d)
	return l
	
def parseEpisodes(id):
	l = []
	url = 'http://www.servustv.com/at/smarttv/get_episodes?pagename=ServusTV/JSON/samsungtvapi&callback=callback&command=get_episodes&limit=100&offset=0&show_id=' + id
	response = libMediathek.getUrl(url)[13:-2]
	xbmc.log(response)
	j = json.loads(response)
	for data in j['data']:
		d = {}
		#if data['subtitle'] == '':
		#	continue
		d['_name'] = data['subtitle']
		d['_plot'] = data['title']
		d['_tvshowtitle'] = data['show_human']
		d['_thumb'] = data['image_url']
		d['_duration'] = str(data['duration'])
		d['_epoch'] = str(data['date'])
		d['url'] = data['video_url']
		d['_type'] = 'video'
		d['mode'] = 'libServusPlay'
		l.append(d)
	return l
	