# -*- coding: utf-8 -*-
"""
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import sys
import json
import time
import socket

from datetime import date, timedelta
"""
from libMediathekUtils import *
from libMediathekListing import *
from libMediathekTtml2Srt import *
from libMediathekPremadeDirs import *
	
	

def listM():#TODO: rename
	
	global params
	params = get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	if not params.has_key('mode'):
		fallbackMode()
	else:
		modes.get(params['mode'],fallbackMode)()
		#libMediathek.setView(views.get(params['mode'],'default'))
	xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	