# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import sys
import json
import _libMediathekUtils as _utils
import time

startTime = int(round(time.time() * 1000))
def log(message = False):
	xbmc.log('Unithek Log: '+str(message))
def logTime():
	xbmc.log('libm Log: Runtime '+str(int(round(time.time() * 1000)) - startTime)+'ms')
logTime()

listCacheFile = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')+'cache.json').decode('utf-8')
cacheInfosFile = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')+'cacheinfos.json').decode('utf-8')
profilePath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
_utils.f_mkdir(profilePath)
hideAudioDisa = True
icon = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')+'/icon.png').decode('utf-8')
fanart = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path')+'/fanart.jpg').decode('utf-8')
translation = xbmcaddon.Addon(id='script.module.libMediathek').getLocalizedString

def checkIfCachedVersionIsAvailable():
	try:#TODO investigate
		j = _retrieveJson(cacheInfosFile)
		if sys.argv[2] == j.get('path','') and j.get('page',1) > 1:
			return True
		else: return False
	except: return False
def retrieveCached():
	xbmc.log('########## USING CACHED VERSION')
	for dict in _retrieveJson(listCacheFile):
		addEntry(dict)
		
def addE(dict,wnd):#not working properly :(
			
	u = _buildUri(dict)
	ilabels = {
		"Title": cleanString(dict.get('name','')),
		"Plot": cleanString(dict.get('plot','')),
		"Plotoutline": cleanString(dict.get('plot','')),
		"Duration": dict.get('duration',''),
		"Mpaa": dict.get('mpaa','')
		}
	ok=True
	liz=xbmcgui.ListItem(cleanString(dict.get('name','')), iconImage="DefaultFolder.png", thumbnailImage=dict.get('thumb',icon))
	liz.setInfo( type="Video", infoLabels=ilabels)
	liz.setProperty('fanart_image',dict.get('fanart',dict.get('thumb',fanart)))
	if 'type' in dict and dict['type'] == 'video':
		liz.setProperty('IsPlayable', 'true')
	wnd = xbmcgui.Window(xbmcgui.getCurrentWindowId())
	wnd.getControl(wnd.getFocusId()).addItem(liz)
	
def addEntries(l,page=-1):
	log("###########handle")
	log(str(sys.argv[1]))
	log("###########listsize")
	try:
		wnd = xbmcgui.Window(xbmcgui.getCurrentWindowId())
		a = wnd.getControl(wnd.getFocusId()).getSelectedPosition()
		log(str(a))
		#d = dir(wnd.getControl(wnd.getFocusId()))
		#for i in d:
		#	log(str(i))
		log(str(wnd.getControl(wnd.getFocusId()).size()))
	except:
		pass
	logTime()
	if page == 1:
		saveCache = True
	elif page > 1:
		j = _retrieveJson(listCacheFile)[:-1]
		l = j + l
		saveCache = True
	else:
		saveCache = False
	log('logging dir build time')
	logTime()
	#for dict in l:
	#	addE(dict)
	_buildDir(l)
	log('finished')
	logTime()
	cacheInfo = {}
	cacheInfo['path'] = sys.argv[2]
	cacheInfo['page'] = page
	
		
	if page == 1:
		xbmcplugin.endOfDirectory(int(sys.argv[1]))	
		try:
			xbmc.sleep(50)
			wnd = xbmcgui.Window(xbmcgui.getCurrentWindowId())
			wnd.getControl(wnd.getFocusId()).selectItem(0)
			xbmc.log(str(wnd.getControl(wnd.getFocusId()).getSelectedPosition()))
		except: pass
	elif page > 1:
		try:
			log('...')
			#xbmc.executebuiltin("XBMC.Container.Update()")
			#wnd = xbmcgui.Window(xbmcgui.getCurrentWindowId())
			#xbmcplugin.endOfDirectory(int(sys.argv[1]), updateListing = True, cacheToDisc = False)
			#xbmc.sleep(100)
			#wnd.getControl(wnd.getFocusId()).selectItem(0)
			#wnd.getControl(wnd.getFocusId()).selectItem(len(j)+1)
		except: pass
	else:
		xbmcplugin.endOfDirectory(int(sys.argv[1]))	
		
	if saveCache:
		_saveJson(listCacheFile,l)
	_saveJson(cacheInfosFile,cacheInfo)
	log('addentries ends')
	logTime()
def _saveJson(f,j):
	data = json.dumps(j)
	_utils.f_write(f,data)
def _retrieveJson(f):
	data = _utils.f_open(f)
	return json.loads(data)
	
def _buildDir(l):
	lists = []
	ok = False
	for dict in l:
		for key in dict:#sigh
			if isinstance(dict[key], unicode):
				dict[key] = dict[key].encode('utf-8')
		#xbmc.log(str(dict))
		if 'type' in dict and dict['type'] == 'nextPage':
			dict['name'] = translation(31040)
		if isinstance(dict["name"], unicode):
			dict["name"] = dict["name"].encode('utf-8')
		dict["name"] = cleanString(dict["name"])
		#dict["name"] = dict["name"].replace('&amp;','&')
		#if hideAudioDisa:
		#	if 'Hörfassung' in dict["name"] or 'Audiodeskription' in dict["name"]:
		#		return False
				
		u = _buildUri(dict)
		ilabels = {
			"Title": cleanString(dict.get('name','')),
			"Plot": cleanString(dict.get('plot','')),
			"Plotoutline": cleanString(dict.get('plot','')),
			"Duration": dict.get('duration',''),
			"Mpaa": dict.get('mpaa','')
			}
		ok=True
		liz=xbmcgui.ListItem(cleanString(dict.get('name','')), iconImage="DefaultFolder.png", thumbnailImage=dict.get('thumb',icon))
		#liz.setInfo( type="Video", infoLabels={ "Title": cleanString(dict.get('name','')) , "Plot": cleanString(dict.get('plot','')) , "Plotoutline": cleanString(dict.get('plot','')) , "Duration": dict.get('duration','') } )
		liz.setInfo( type="Video", infoLabels=ilabels)
		liz.setProperty('fanart_image',dict.get('fanart',dict.get('thumb',fanart)))
		
		if 'type' in dict and dict['type'] == 'video':
			liz.setProperty('IsPlayable', 'true')
			lists.append([u,liz,False])
		elif 'type' in dict and dict['type'] == 'nextPage':
			#lists.append([u,liz,True])
			lists.append([u,liz,False])
		else:
			lists.append([u,liz,True])
	xbmcplugin.addDirectoryItems(int(sys.argv[1]), lists)
	#xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="episodes" )		
	return ok

def addEntry(dict):	
	for key in dict:#sigh
		if isinstance(dict[key], unicode):
			dict[key] = dict[key].encode('utf-8')
	#xbmc.log(str(dict))
	if 'type' in dict and dict['type'] == 'nextPage':
		dict['name'] = translation(31040)
	if isinstance(dict["name"], unicode):
		dict["name"] = dict["name"].encode('utf-8')
	dict["name"] = cleanString(dict["name"])
	#dict["name"] = dict["name"].replace('&amp;','&')
	#if hideAudioDisa:
	#	if 'Hörfassung' in dict["name"] or 'Audiodeskription' in dict["name"]:
	#		return False
			
	u = _buildUri(dict)
	ilabels = {
		"Title": cleanString(dict.get('name','')),
		"Plot": cleanString(dict.get('plot','')),
		"Plotoutline": cleanString(dict.get('plot','')),
		"Duration": dict.get('duration',''),
		"Mpaa": dict.get('mpaa','')
		}
	ok=True
	liz=xbmcgui.ListItem(cleanString(dict.get('name','')), iconImage="DefaultFolder.png", thumbnailImage=dict.get('thumb',icon))
	#liz.setInfo( type="Video", infoLabels={ "Title": cleanString(dict.get('name','')) , "Plot": cleanString(dict.get('plot','')) , "Plotoutline": cleanString(dict.get('plot','')) , "Duration": dict.get('duration','') } )
	liz.setInfo( type="Video", infoLabels=ilabels)
	liz.setProperty('fanart_image',dict.get('fanart',dict.get('thumb',fanart)))
	xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="episodes" )
	if 'type' in dict and dict['type'] == 'video':
		liz.setProperty('IsPlayable', 'true')
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
	elif 'type' in dict and dict['type'] == 'nextPage':
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		
	return ok
	
def _buildUri(dict):
	u = dict.get('pluginpath',sys.argv[0])+'?'
	i = 0
	for key in dict.keys():
		if i > 0:
			u += '&'
		if isinstance(dict[key], basestring):
			dict[key] = dict[key]#.encode('utf8')
		else:
			dict[key] = str(dict[key])
		u += key + '=' + urllib.quote_plus(dict[key])
		i += 1
	return u
	

def cleanString(s):
  s = s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&#034;", "\"").replace("&#039;", "'").replace("&quot;", "\"").replace("&szlig;", "ß").replace("&ndash;", "-")
  s = s.replace("&Auml;", "Ä").replace("&Uuml;", "Ü").replace("&Ouml;", "Ö").replace("&auml;", "ä").replace("&uuml;", "ü").replace("&ouml;", "ö").replace("&eacute;", "é").replace("&egrave;", "è")
  s = s.replace("&#x00c4;","Ä").replace("&#x00e4;","ä").replace("&#x00d6;","Ö").replace("&#x00f6;","ö").replace("&#x00dc;","Ü").replace("&#x00fc;","ü").replace("&#x00df;","ß")
  s = s.replace("&apos;","'").strip()
  return s

	
def pvrCheckStartTimeIsComparable(a,b):
	n = abs(a-b)
	if n <= 15:
		return True
	else:
		return False
def pvrCheckIfMovie(name):
	if name.startswith("Fernsehfilm Deutschland"):
		return True
	else:
		return False
def pvrCheckDurationIsComparable(a,b,maxDeviation = 10):
	deviation = abs((a * 100) / b - 100)
	if deviation <= maxDeviation:
		return True
	else:
		return False

def pvrCheckNameIsComparable(a,b):
	if a == b:
		return True
	else:
		return _wordRatio(a,b)
	
def _wordRatio(a,b,maxRatio=0.7):
	xbmc.log(a)
	xbmc.log(b)
	i = 0
	aSplit = a.split(" ")
	bSplit = b.split(" ")
	for word in aSplit:
		if word in bSplit:
			i += 1
	ratio = i / len(aSplit) 
	if ratio >= maxRatio:
		return True
	else: return False
	
def get_params():
	param={}
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]= urllib.unquote_plus(splitparams[1])

	return param