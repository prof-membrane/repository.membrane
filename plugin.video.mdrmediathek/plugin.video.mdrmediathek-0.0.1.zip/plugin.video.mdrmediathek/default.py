﻿# -*- coding: utf-8 -*-
import libMdr

libMdr.list()