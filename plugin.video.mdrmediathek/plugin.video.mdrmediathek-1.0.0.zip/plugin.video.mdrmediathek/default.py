﻿# -*- coding: utf-8 -*-
import libmdr

libmdr.list()