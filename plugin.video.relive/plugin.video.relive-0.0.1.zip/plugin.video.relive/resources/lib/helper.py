# -*- coding: utf-8 -*-
from datetime import date
import xbmc

dateformat = 'weekday, DD. Month YYYY'  

months = {
			"Januar":1,
			"Februar":2,
			"März":3,
			"April":4,
			"Mai":5
		}#todo

def getMinutes():
	videodate = xbmc.getInfoLabel("ListItem.Date")
	t = videodate.split(" ")[-1]
	HH,MM = t.split(":")
	return int(HH) * 60 + int(MM)
	
def timeToMM(t):
	HH,MM = t.split(":")
	return int(HH) * 60 + int(MM)
	
def getChannelName():
	channel = xbmc.getInfoLabel("ListItem.ChannelName")
	channel = channel.lower().replace(" ","").replace(".","").replace("-","").replace("/","")
	return channel
	
def getDate():#TODO find out if there is a batter way to do this (JSON???)
	#videodate = xbmc.getInfoLabel("ListItem.Date")
	
	if dateformat == 'weekday, DD. Month YYYY':
		return getDateDE()
	
def getDateDE():
	videodate = xbmc.getInfoLabel("ListItem.StartDate")
	d = videodate.split(" ")
	DD = int(d[1].replace(".",""))
	MM = int(months[d[2]])
	YYYY = int(d[3])
	delta = date.today() - date(YYYY, MM, DD)
	return delta.days
	
def getInfos():
	
	xbmc.log(xbmc.getInfoLabel("ListItem.Label"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Label2"))
	xbmc.log(xbmc.getInfoLabel("ListItem.OriginalTitle"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Episode"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Season"))
	xbmc.log(xbmc.getInfoLabel("ListItem.FileName"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Date"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Tagline"))
	xbmc.log(xbmc.getInfoLabel("ListItem.EpisodeName"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Duration"))
	dict = {}

	dict["time"] = getMinutes()
	dict["duration"] = xbmc.getInfoLabel("ListItem.Duration")
	dict["name"] = xbmc.getInfoLabel("ListItem.Title")
	dict["episode"] = xbmc.getInfoLabel("ListItem.EpisodeName")

	dict["day"] = getDate()
	dict["channel"] = getChannelName()
	return dict