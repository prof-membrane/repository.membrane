# -*- coding: utf-8 -*-
import xbmc
import json
import libmediathek3 as libMediathek
import re
#import dateutil.parser

baseUrl = 'http://swrmediathek.de'

def getList(url,type,mode):
	xbmc.log(url)
	response = libMediathek.getUrl(url)
	return _findLiEntries(response,type,mode)
	
def getDate(d,type,mode):
	d = abs(int(d))
	response = libMediathek.getUrl('http://swrmediathek.de/app-2/svp.html')
	day = re.compile('<ul data-role="listview" data-theme="c" data-divider-theme="d">(.+?)</ul>', re.DOTALL).findall(response)[d]
	return _findLiEntries(day,type,mode)[::-1]
	
def _findLiEntries(response,type,mode):
	items = re.compile('<li data-icon="false">(.+?)</li>', re.DOTALL).findall(response)
	list = []
	for item in items:
		dict = {}
		dict['_name'] = re.compile('<h3>(.+?)</h3>', re.DOTALL).findall(item.replace(' class="teaserLink"',''))[0]
		uri = re.compile('href="(.+?)"', re.DOTALL).findall(item)[0]
		if not uri.startswith('/app-2/'):
			uri = '/app-2/' + uri
		dict['url'] = baseUrl + uri
		if 'data-src' in item:
			dict['_thumb'] = baseUrl + re.compile('data-src="(.+?)"', re.DOTALL).findall(item)[0]
		else:
			dict['_thumb'] = baseUrl + re.compile('src="(.+?)"', re.DOTALL).findall(item)[0]
		
		if '<p>' in item:
			dict['_plot'] = re.compile('<p>(.+?)</p>', re.DOTALL).findall(item)[0]
			s = dict['_plot'].split(' vom ')
			xbmc.log(dict['_plot'])
			xbmc.log(s[0])
			xbmc.log(s[1])
			DDMMYYYY,HHMM = s[1].split(' | ')
			d = DDMMYYYY.split('.')
			dict['_aired'] = d[2] + '-' + d[1] + '-'  + d[0] 
			dict['_airedtime'] = HHMM.replace(' Uhr','')
			if len(dict['_airedtime']) == 4:
				dict['_airedtime'] = '0' + dict['_airedtime']
			if '| Spielfilm' in dict['_name']:
				dict['_tvshowtitle'] = 'Spielfilm'
			else:
				dict['_tvshowtitle'] = s[0]
		
		dict['_type'] = type
		dict['mode'] = mode
		
		list.append(dict)
		xbmc.log(str(dict))
	return list

def getVideo(url):
	d = {}
	xbmc.log(url)
	response = libMediathek.getUrl(url)
	try:
		video = re.compile('"file":"(.+?).m3u8"').findall(response)[0] + '.m3u8'
	except:
		s = re.compile('"file":"(.+?).m.mp4"').findall(response)[0].split('/')
		#http://mp4-download.swr.de/swr-fernsehen/landesschau-aktuell-bw/20161019/893108.m.mp4
		#http://hls-ondemand.swr.de/i/swr-fernsehen/landesschau-aktuell-bw/20161019/893108.,xl,l,ml,m,sm,s,.mp4.csmil/master.m3u8
		video = 'http://hls-ondemand.swr.de/i/swr-fernsehen/'+s[4]+'/'+s[5]+'/'+s[6]+'.,xl,l,ml,m,sm,s,.mp4.csmil/master.m3u8'
	d['media'] = [{'url':video, 'type':'video', 'stream':'HLS'}]
	sub = re.compile("lucy2captionArray\((.+?)\)").findall(response)[0]
	if sub != "''":
		d['subtitle'] = [{'url':sub.replace("'",""), 'type': 'ttml', 'lang':'de'}]
	try:
		name = re.compile("title = '(.+?)'").findall(response)[-1]
		plot = re.compile("descl = '(.+?)'").findall(response)[-1]
		thumb = re.compile("image = '(.+?)'").findall(response)[-1]
		d['metadata'] = {'name':name, 'plot': plot, 'thumb':thumb}
	except: pass	
	return d





 
def parseShows(letter):
	response = libMediathek.getUrl('http://www1.wdr.de/mediathek/video/sendungen-a-z/sendungen-'+letter.lower()+'-102.html')
	uls = re.compile('<ul  class="list">(.+?)</ul>', re.DOTALL).findall(response)
	list = []
	for ul in uls:
		lis = re.compile('<li >(.+?)</li>', re.DOTALL).findall(ul)
		for li in lis:
			dict = {}
			strong = re.compile('<strong>(.+?)</strong>', re.DOTALL).findall(li)[0]
			if strong == 'mehr':
				dict['url'] = base + re.compile('href="(.+?)"', re.DOTALL).findall(li)[0]
				dict['_name'] = re.compile('<span>(.+?)</span>', re.DOTALL).findall(li)[0]
				dict['_thumb'] = base + re.compile('<img.+?src="(.+?)"', re.DOTALL).findall(li)[0]
				
				dict['_type'] = 'dir'
				dict['mode'] = 'libWdrListVideos'
				
				list.append(dict)
			else:#TODO!
				pass
		
	return list
	
def parseVideos(url):#TODO remove "mehr"
	response = libMediathek.getUrl(url)
	#<div class="box"
	typeA = re.compile('<div class="box".+?<a(.+?)>(.+?)</a>.+?<a(.+?)>(.+?)</a>', re.DOTALL).findall(response)
	list = []
	for href,show,href2,stuff in typeA:
		#xbmc.log(href)
		#xbmc.log(href2)
		if '<div class="media mediaA video">' in stuff:
			dict = {}
			#xbmc.log(stuff)
			dict['url'] = base + re.compile('href="(.+?)"', re.DOTALL).findall(href2)[0]
			if '<h4' in stuff:
				dict['_name'] = re.compile('<h4.+?>.+?<span class="hidden">Video:</span>(.+?)<', re.DOTALL).findall(stuff)[0].strip()
			else:
				dict['_name'] = show.strip()
			if '<img' in stuff:
				dict['_thumb'] = base + re.compile('<img.+?src="(.+?)"', re.DOTALL).findall(stuff)[0]
			dict['_plot'] = re.compile('<p class="teasertext">(.+?)<', re.DOTALL).findall(stuff)[0]
			dict['_type'] = 'video'
			dict['mode'] = 'libWdrPlay'
			
			list.append(dict)
	return list
"""	
def parseDate(date,channel='BR'):
	j = _parseMain()
	xbmc.log(str(j))
	url = j["_links"]["epg"]["href"]
	response = _utils.getUrl(url)
	j = json.loads(response)
	url = j["epgDays"]["_links"][date]["href"]#date: 2016-12-30
	response = _utils.getUrl(url)
	j = json.loads(response)
	
	list = []
	broadcasts = j["channels"][chan[channel]]["broadcasts"]
	for b in broadcasts:
		xbmc.log(str(b))
		if "_links" in b and "video" in b["_links"]:
			dict = {}
			
			dict["name"] = b["headline"]
			dict["plot"] = b["subTitle"]
			dict["subtitle"] = b["hasSubtitle"]
			dict["url"] = b["_links"]["video"]["href"]
			dict["time"] = startTimeToInt(b["broadcastStartDate"][11:19])
			#TODO: rest of properties
			dict['type'] = 'video'
			dict['mode'] = 'libBrPlay'
			list.append(dict)
	return list
"""		
	

def parseVideo(url):
	xbmc.log(url)
	response = libMediathek.getUrl(url)
	url2 = re.compile("'mediaObj': { 'url': '(.+?)'", re.DOTALL).findall(response)[0]
	xbmc.log(url2)
	response = libMediathek.getUrl(url2)
	videos = re.compile('"videoURL":"(.+?)"', re.DOTALL).findall(response)
	for video in videos:
		if 'm3u8' in video:
			vid = video
	return vid#todo subtitles
def startTimeToInt(s):
	HH,MM,SS = s.split(":")
	return int(HH) * 60 + int(MM)