# -*- coding: utf-8 -*-
import xbmc
import xbmcgui	

import sys
import resources.lib.helper as helper
import resources.lib.channels.dreisat as dreisat
#import resources.lib.channels.ard as ard
import resources.lib.channels.br as br
#import resources.lib.channels.daserste as daserste
import resources.lib.channels.zdf as zdf


hardCodedShows = {
'Tagesschau':'daserste',
'TAGESSCHAU':'daserste',
'ARD-Mittagsmagazin':'daserste',
'ZDF-Mittagsmagazin':'zdf',
}


def main():
	#xbmc.executebuiltin('ActivateWindow(10138)')

	#channel = helper.getChannelName()
	d = helper.getInfos()
	if d['name'] in hardCodedShows:
		xbmc.log(d['channel'])
		d['channel'] = hardCodedShows[d['name']]
	
	
	if d['channel'] in dreisat.channels:
		channelModule = dreisat
	elif d['channel'] in br.channels:
		channelModule = br
	elif d['channel'] in zdf.channels:
		channelModule = zdf
	#elif d['channel'] in daserste.channels:
	#	channelModule = daserste
	#elif d['channel'] in ard.channels:
	#	channelModule = ard
	#elif channel in arte.channels:
	#	arte.play()
	#elif channel in servustv.channels:
	#	servustv.play()
	else:
		xbmc.executebuiltin('Dialog.Close(10138)')
		xbmc.log("channel not supported")
		xbmc.executebuiltin("Notification(Kein Video gefunden,Sender wird nicht unterstützt, 7000)")
		sys.exit()


	#try:

	shows = channelModule.fetchShows(d)

	foundVideo = helper.findVideo(d,shows)
	#except: pass
	xbmc.executebuiltin('Dialog.Close(10138)')
	menuList = []
	actionList = []
	if foundVideo:
		if channelModule.supportsPlay:
			menuList.append("Aus Mediathek abspielen")
			actionList.append('play')
		if channelModule.supportsMore:
			menuList.append("Sendungsseite")
			actionList.append('more')
	else:
		if channelModule.supportsShow:
			foundShow = helper.findShow(d,channelModule.getShows())
			if foundShow:
				menuList.append("Sendungsseite")
				actionList.append('show')
			
	if channelModule.supportsSearch:
		menuList.append("In Mediathek suchen")
		actionList.append('search')
	if channelModule.supportsAddon:
		menuList.append(channelModule.addonName + ' aufrufen')
		actionList.append('addon')
		
	if len(menuList) == 0:
		sys.exit()

	selected = xbmcgui.Dialog().contextmenu(list=menuList)

	xbmc.executebuiltin('ActivateWindow(10138)')
	xbmc.log(str(selected))
	if selected == -1:
		xbmc.executebuiltin('Dialog.Close(10138)')
		sys.exit()
	action = actionList[selected]

	if action == 'play':
		import libmediathek3
		libmediathek3.play(channelModule.play(foundVideo),external=True)
	elif action == 'more':
		channelModule.more(foundVideo)
	elif action == 'show':
		channelModule.show(foundShow)
	elif action == 'search':
		searchString = d['name']
		#if 'episode' in d: ###TODO: BR Mediathek doesn't like this, need to build a switch
		#	searchString += ' '+d['episode']
		channelModule.search(searchString)
	elif action == 'addon':
		channelModule.addonPath
		xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_de_lite"]}}')
		#channelModule.addon()
	xbmc.executebuiltin('Dialog.Close(10138)')
	"""
	if foundShow:
		selected = xbmcgui.Dialog().contextmenu(list=["Aus Mediathek abspielen", "Weitere Beiträge zeigen", "In Mediathek suchen"])
		if selected == 0:
			channelModule.play(foundShow)
	else:
		selected = xbmcgui.Dialog().contextmenu(list=["In Mediathek suchen"])"""
#try:
main()
#except:	xbmc.executebuiltin('Dialog.Close(10138)')