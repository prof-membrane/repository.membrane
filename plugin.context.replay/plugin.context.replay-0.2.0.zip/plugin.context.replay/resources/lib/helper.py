# -*- coding: utf-8 -*-
from datetime import date
import xbmc,sys
import time

dateformat = 'weekday, DD. Month YYYY'  

months = {
			"Januar":1,
			"Februar":2,
			"März":3,
			"April":4,
			"Mai":5
		}#todo

def log(m):
	xbmc.log(m)
def getMinutes():
	t = xbmc.getInfoLabel("ListItem.Duration")
	s = t.split(":")
	HH = s[0]
	MM = s[1]
	return int(HH) * 60 + int(MM) + 120
	
def timeToMM(t):
	HH,MM = t.split(":")
	return int(HH) * 60 + int(MM)
	
def getDuration():
	d = xbmc.getInfoLabel("ListItem.Duration").split(":")
	for i, val in enumerate(d[::-1]):
		if i == 0:
			duration = int(val)
		elif i == 1:
			duration += int(val) * 60
		elif i == 2:
			duration += int(val) * 3600
	return duration
def getChannelName():
	channel = xbmc.getInfoLabel("ListItem.ChannelName")
	channel = channel.replace("HD","").replace(" ","").replace(".","").replace("-","").replace("/","").replace("_","").lower()
	return channel
	
def getDate():
	videodate = xbmc.getInfoLabel("ListItem.FileName")
	d = videodate.split(" ")[0]
	YYYY,MM,DD = d.split("-")
	delta = date.today() - date(int(YYYY), int(MM), int(DD))
	return delta.days
	
def getInfos():
	#import xbmcgui
	#win = xbmcgui.Window (xbmcgui.getCurrentWindowId())
	#xbmc.log(str(dir(win)))
	#"""
	xbmc.log(xbmc.getInfoLabel("ListItem.Label"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Label2"))
	xbmc.log(xbmc.getInfoLabel("ListItem.OriginalTitle"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Episode"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Season"))
	xbmc.log(xbmc.getInfoLabel("ListItem.FileName"))
	xbmc.log('date')
	
	xbmc.log(xbmc.getInfoLabel("ListItem.Date"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Tagline"))
	xbmc.log('episode')
	xbmc.log(xbmc.getInfoLabel("ListItem.EpisodeName"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Duration"))
	xbmc.log("#############")
	xbmc.log(xbmc.getInfoLabel("ListItem.Path"))
	xbmc.log("#############")
	xbmc.log(xbmc.getInfoLabel("ListItem.FileNameAndPath"))
	xbmc.log("#############")
	xbmc.log(sys.listitem.getLabel("Path"))
	#"""
	dict = {}
	#videodate = xbmc.getInfoLabel("ListItem.Date")
	#xbmc.log(videodate)#25.04.2016 19:50
	#dict["epoch"] = int(time.mktime(time.strptime(xbmc.getInfoLabel("ListItem.FileName").replace('.epg',''), '%Y-%m-%d %H:%M:%S')))
	#dict["epoch"] = int(time.mktime(time.strptime(xbmc.getInfoLabel("ListItem.Date"), '%m/%d/%Y %I:%M %p')))
	dict["epoch"] = int(time.mktime(time.strptime(xbmc.getInfoLabel("ListItem.Date"), '%d.%m.%Y %H:%M')))
	#dict["date"] = xbmc.getInfoLabel("ListItem.FileName").split(" ")[0]
	#dict["time"] = getMinutes()
	#dict["day"] = getDate()
	#if dict["time"] >= 1440:
	#	dict["time"] -= 1440
	#	dict["day"] = dict["day"] - 1
	dict["duration"] = getDuration()
	dict["name"] = xbmc.getInfoLabel("ListItem.Title")
	if dict["name"].endswith(')'):
		episode = dict["name"].split('(')[-1].replace(')','')#extracts episode number: "someseries (5)" -> 5
		if episode.isdigit():
			dict["episode"] = episode
			l = len(dict["episode"]) + 3
			dict["name"] = dict["name"][:-l]#removes " (5)"
		elif '/' in episode:
			s = episode.split('/')			
			if len(s) == 2:
				if s[0].isdigit() and s[1].isdigit():
					dict["episode"] = s[0]
					l = len(episode) + 3
					dict["name"] = dict["name"][:-l]#removes " (1/4)"
	dict["subtitle"] = xbmc.getInfoLabel("ListItem.EpisodeName")

	
	dict["channel"] = getChannelName()
	return dict
	
def findVideo(dict,list):
	
	log('###find vid')
	log(str(dict['epoch']))
	for d in list:
		if not '_epoch' in d:
			if '_airedISO8601' in d:
				t = time.mktime(time.strptime(d["_airedISO8601"][:19], '%Y-%m-%dT%H:%M:%S'))
				offset = d["_airedISO8601"].replace(':','')[-5:]
				#d['_epoch'] = str(int(t) + int(offset))
				d['_epoch'] = str(int(t))
		log(str(d['_epoch']))
		if int(d['_epoch']) == dict['epoch']:
			if 'duration' in d:
				if d['duration'] == '-1' or _checkDuration(dict['duration'],d['duration']):
					return d
			else:
				return d
	#log(str(dict))
	#log(str(list))
	return False
	
	
def _checkDuration(epgDuration,videoDuration):#compares duration between video end epg
	e = int(epgDuration)
	v = int(videoDuration)
	if abs(e - v) <= e * 0.5:
		return True
	else:
		return False
		
def _rateName(epgName,videoName):#returns a rating how similar the names are
	rating = 0
	if epgName in videoName or videoName in epgName:
		return 1
	e = epgName.lower().split(' ')
	v = videoName.lower().split(' ')
	for word in e:
		if word in v:
			rating += 1/len(e)
	return rating
def findShow(dict,list):
	for entry in list:
		if entry['name'] == dict['name']:
			return entry['url']
	return False
	