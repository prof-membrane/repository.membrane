# -*- coding: utf-8 -*-
import libBr
import time
import resources.lib.helper as helper

name = 'BR Mediathek'
addonName = 'BR Mediathek'
supportsPlay = True
supportsMore = False
supportsShow = True
supportsSearch = True
supportsAddon = True
channels = {"br":"br",
			   "brfernsehen":"br",
			   "brnord":"br",
			   "brfernsehennord":"br",
			   "brfernsehensued":"br",
			   "ardalpha":"ardalpha",
			  }
			  
def fetchShows(dict):
	libBr.params = {'name':'test'}
	d = time.strftime('%Y-%m-%d', time.localtime(dict['epoch']))
	return libBr.getDate(d,channels[dict['channel']])
def play(dict):
	libBr.play(dict)
	
### using ard mediathek for the rest, libBr provides access to shows by date only
import ard
#def search(searchString):
#	ard.search(searchString)
def search(searchString):
	import xbmc
	import urllib
	xbmc.executebuiltin('XBMC.ActivateWindow(videos,plugin://plugin.video.brmediathek/?mode=libBrListSearch&searchString='+urllib.quote_plus(searchString)+',return)')	

def addon():
	import xbmc
	xbmc.executeJSONRPC('{"jsonrpc": "2.0","method": "Addons.ExecuteAddon","params": {"wait": false,"addonid": "plugin.video.brmediathek"},"id": 2} }')	
def getShows():
	return ard.getShows()
	
def show(url):
	ard.show(url)