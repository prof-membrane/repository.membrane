# -*- coding: utf-8 -*-
import libDasErste
import time
import resources.lib.helper as helper

name = 'Das Erste Mediathek'
addonName = 'Das Erste Mediathek'
supportsPlay = True
supportsMore = False
supportsShow = True
supportsSearch = True
supportsAddon = True
channels = {"daserste":"daserste",}
			  
def fetchShows(dict):
	libDasErste.params = {'datum':'0'}
	#d = time.strftime('%Y-%m-%d', time.localtime(dict['epoch']))
	return libDasErste.libDasErsteListDateVideos()
def play(dict):
	libDasErste.params = dict
	libDasErste.libDasErstePvrPlay()
	
### using ard mediathek for the rest, libBr provides access to shows by date only
import ard
#def search(searchString):
#	ard.search(searchString)
def search(searchString):
	import xbmc
	import urllib
	xbmc.executebuiltin('XBMC.ActivateWindow(videos,plugin://plugin.video.brmediathek/?mode=libBrListSearch&searchString='+urllib.quote_plus(searchString)+',return)')	

def addon():
	import xbmc
	xbmc.executeJSONRPC('{"jsonrpc": "2.0","method": "Addons.ExecuteAddon","params": {"wait": false,"addonid": "plugin.video.brmediathek"},"id": 2} }')	
def getShows():
	return ard.getShows()
	
def show(url):
	ard.show(url)