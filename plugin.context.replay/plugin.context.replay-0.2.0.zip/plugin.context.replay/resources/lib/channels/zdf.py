# -*- coding: utf-8 -*-
import xbmc
import libzdf
import resources.lib.helper as helper

name = 'ZDF Mediathek'
addonName = 'ZDF Mediathek'
addonPath = 'plugin://plugin.video.zdfmediathek'

supportsPlay = True
supportsMore = False
supportsShow = False
supportsSearch = False
supportsAddon = True

channels = {"zdf":"zdf",
			   "zdfinfo":"zdfinfo",
			   "zdfneo":"zdfneo",
			   "neo":"zdfneo",
			   "neokika":"zdfneo",
			  }

def fetchShows(d):
	c = channels[d['channel']].replace('zdf','ZDF').replace('zdfinfo','ZDFinfo').replace('zdfneo','ZDFneo')
	libzdf.params = {'datum':'0','channel':c}
	return libzdf.libZdfListChannelDateVideos()
	
def play(d):
	libzdf.params = {'url':d['url']}
	return libzdf.libZdfPlay()
	
def listSimmilar():
	return
	
def listMore():
	return
	
def search(searchString):
	return

def addon():
	return