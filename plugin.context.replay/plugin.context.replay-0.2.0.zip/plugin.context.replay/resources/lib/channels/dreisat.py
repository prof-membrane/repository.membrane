# -*- coding: utf-8 -*-
import xbmc
import lib3sat
import resources.lib.helper as helper

name = '3sat Mediathek'
addonName = '3sat Mediathek'
addonPath = 'plugin://plugin.video.3satmediathek'

supportsPlay = True
supportsMore = False
supportsShow = False
supportsSearch = False
supportsAddon = True

channels = {"3sat":"3sat"}

def fetchShows(d):
	lib3sat.params = {'datum':'0'}
	return lib3sat.lib3satListDateVideos()
	
def play(d):
	lib3sat.params = {'url':d['url']}
	return lib3sat.lib3satXmlPlay()
	
def listSimmilar():
	return
	
def listMore():
	return
	
def search(searchString):
	import xbmc
	import urllib
	u = 'http://www.zdf.de/ZDFmediathek/xmlservice/web/detailsSuche?maxLength=50&types=Video&properties=HD%2CUntertitel%2CRSS&searchString='+urllib.quote_plus(searchString)
	xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_de_lite?mode=libZdfListPage&url='+urllib.quote_plus(u)+'"]}}')
	#xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_med_de?mode=libZdfListPage&url='+urllib.quote_plus(u)+'"]}}')
	#xbmc.executeJSONRPC('{"jsonrpc": "2.0","method": "Addons.ExecuteAddon","params": {"wait": false,"addonid": "script.module.libArd","params": ["?mode=libArdListSearch&searchString='+urllib.quote_plus(name)+'"]},"id": 2} }')

def addon():
	import xbmc
	xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_de_lite"]}}')
	#xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_med_de"]}}')