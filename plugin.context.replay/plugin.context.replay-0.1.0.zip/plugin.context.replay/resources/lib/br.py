# -*- coding: utf-8 -*-
import libBr
import resources.lib.helper as helper

name = 'BR Mediathek'
addonName = 'ARD Mediathek'
supportsPlay = True
supportsMore = False
supportsShow = True
supportsSearch = True
supportsAddon = True
channels = {"br":"br",
			   "brfernsehen":"br",
			   "brnord":"br",
			   "brfernsehennord":"br",
			   "ardalpha":"ardalpha",
			  }
			  
def fetchShows(dict):
	return libBr.getDate(dict['date'])
def play(dict):
	libBr.play(dict)
	
### using ard mediathek for the rest, libBr provides access to shows by date only
import ard
def search(searchString):
	ard.search(searchString)
	
def addon():
	ard.addon()
	
def getShows():
	return ard.getShows()
	
def show(url):
	ard.show(url)