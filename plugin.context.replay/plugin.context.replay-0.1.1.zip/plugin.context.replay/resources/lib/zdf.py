# -*- coding: utf-8 -*-
import xbmc
import libZdf
import resources.lib.helper as helper

name = 'ZDF Mediathek'
addonName = 'ZDF Mediathek'
supportsPlay = True
supportsMore = False
supportsShow = False
supportsSearch = True
supportsAddon = True

channels = {"zdf":"zdf",
			   "zdfinfo":"zdfinfo",
			   "3sat":"3sat",
			   "zdfkultur":"zdfkultur",
			   "zdfneo":"zdfneo",
			   "neo":"zdfneo",
			   "neokika":"zdfneo",
			   "phoenix":"phoenix"
			  }

def fetchShows(dict):
	if dict['time'] < 330:
		dict['day'] = dict['day'] + 1
	return libZdf.libZdfPvrDate(str(dict['day']),dict['channel'])
		
	#return libArd.libArdPvrDate(str(dict['day']),dict['channel'])
	
def play(dict):
	libZdf.libZdfPvrPlay(dict)
"""
	dict = helper.getInfos()
	if dict["channel"] != "neokika":
		libZdf.libZdfPvrPlay(dict["time"],dict["day"],dict["name"],channels[dict["channel"]])
	elif dict["time"] >= 1260 or dict["time"] < 360:# on dvb-t, neo and kika share a channel. neo broadcasts between 21:00 and 6:00
		libZdf.libZdfPvrPlay(dict["time"],dict["day"],dict["name"],channels[dict["channel"]])
	else:
		xbmc.executebuiltin("Notification(Kein Video gefunden,Sender wird nicht unterstützt, 7000)")
"""	
def listSimmilar():
	return
def listMore():
	return
def search(searchString):
	import xbmc
	import urllib
	u = 'http://www.zdf.de/ZDFmediathek/xmlservice/web/detailsSuche?maxLength=50&types=Video&properties=HD%2CUntertitel%2CRSS&searchString='+urllib.quote_plus(searchString)
	xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_de_lite?mode=libZdfListPage&url='+urllib.quote_plus(u)+'"]}}')
	#xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_med_de?mode=libZdfListPage&url='+urllib.quote_plus(u)+'"]}}')
	#xbmc.executeJSONRPC('{"jsonrpc": "2.0","method": "Addons.ExecuteAddon","params": {"wait": false,"addonid": "script.module.libArd","params": ["?mode=libArdListSearch&searchString='+urllib.quote_plus(name)+'"]},"id": 2} }')
def addon():
	import xbmc
	xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_de_lite"]}}')
	#xbmc.executeJSONRPC('{"jsonrpc": "2.0","id": 2,"method": "GUI.ActivateWindow","params": {"window": "videos","parameters": ["plugin://plugin.video.zdf_med_de"]}}')