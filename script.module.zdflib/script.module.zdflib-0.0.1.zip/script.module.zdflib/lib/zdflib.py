# -*- coding: utf-8 -*-
import zdf_listing
import zdf_play

def getNew():
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=%5FSTARTSEITE')
def getMostViewed():
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/meistGesehen?maxLength=50&id=%5FGLOBAL')
def getAZ(letter):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd='+letter+'&detailLevel=2&characterRangeStart='+letter)

	
def getXML(url):
	return zdf_listing.getXML(url)
def getVideoUrl(url):
	print 'playing:'+url
	return zdf_play.getVideoUrl(url)