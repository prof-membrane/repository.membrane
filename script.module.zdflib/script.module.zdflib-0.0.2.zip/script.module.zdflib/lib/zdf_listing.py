#!/usr/bin/python
# -*- coding: utf-8 -*-
import re
import sys
import xbmcplugin
import xbmcgui
import urllib
import _utils as utils


baseUrl = "http://www.zdf.de"
#'http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd=C&detailLevel=2&characterRangeStart=A'
fallbackImage = "http://www.zdf.de/ZDFmediathek/img/fallback/946x532.jpg"
defaultThumb = ''
def getXML(url,modeS='3',modeV='4'):
	print url
	items = []
	list = []
	response = utils.getUrl(url)
	if not '<teasers>' in response:
		return list
	teasers=re.compile('<teasers>(.+?)</teasers>', re.DOTALL).findall(response)[0]
	match_teaser=re.compile('<teaser(.+?)</teaser>', re.DOTALL).findall(teasers)
	for teaser in match_teaser:
		match_member=re.compile('member="(.+?)"', re.DOTALL).findall(teaser)
		match_type=re.compile('<type>(.+?)</type>', re.DOTALL).findall(teaser)
		match_teaserimages=re.compile('<teaserimages>(.+?)</teaserimages>', re.DOTALL).findall(teaser)
		thumb = chooseThumb(match_teaserimages[0])
		match_information=re.compile('<information>(.+?)</information>', re.DOTALL).findall(teaser)
		title,plot=getInfo(match_information[0])
		match_details=re.compile('<details>(.+?)</details>', re.DOTALL).findall(teaser)
		assetId,channel,length,channelLogo,airtime,timetolive,fsk,hasCaption,url=getDetails(match_details[0])
		#title = cleanTitle(title)
		type = match_type[0]

		if type == 'sendung' and length != '0':
			u = sys.argv[0]+"?url="+urllib.quote_plus(baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id='+assetId)+"&name="+urllib.quote_plus(title)+"&mode="+modeS
			liz = xbmcgui.ListItem(title, iconImage=defaultThumb, thumbnailImage=thumb)
			#liz.setInfo(type="Video", infoLabels={"Title": title})
			#liz.setProperty("fanart_image", defaultBackground)
			items.append((u, liz, True,))
			list.append([title, baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id='+assetId, thumb])
		elif type == 'video':
			#addLink(title,assetId,3,thumb,plot,length,airtime,timetolive,fsk,hasCaption,channel=channel)
			u = sys.argv[0]+"?url="+urllib.quote_plus(assetId)+"&name="+urllib.quote_plus(title)+"&mode="+modeV
			liz = xbmcgui.ListItem(title, iconImage=defaultThumb, thumbnailImage=thumb)
			liz.setInfo(type="Video", infoLabels={"Title": title})
			liz.setProperty('IsPlayable', 'true')
			#liz.setProperty("fanart_image", defaultBackground)
			items.append((u, liz, False,))
			list.append([title, assetId, thumb, plot, length, airtime])
	return list	
		
"""		
			addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id='+assetId,2,thumb,plot,channel)
		elif type == 'video':
			stuff = stuff + addLink(title,assetId,3,thumb,plot,length,airtime,timetolive,fsk,hasCaption,channel=channel)
		#elif type == 'imageseries_informativ':#TODO
		#	addLink(title,assetId,3,thumb,plot,length,airtime,timetolive,fsk,hasCaption)
		elif type == 'rubrik' and length != '0':
			stuff = stuff + addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&ak=web&id='+assetId,2,thumb,plot,channel)
		elif type == 'topthema' or type == 'thema' and length != '0':
			stuff = stuff + addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&ak=web&id='+assetId,2,thumb,plot,channel)
		elif type == 'sender' and length != '0':
			stuff = stuff + addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&ak=web&id='+assetId,2,thumb,plot,channel)
		elif type == 'livevideo':
			if match_member[0] == 'onAir':
				stuff = stuff + addLink(title,assetId,3,thumb,plot,0,airtime,timetolive,fsk,hasCaption,channel=channel)

	items = []
	l = getAZ(letter)
	for name, url, thumb in l:
		u = sys.argv[0]+"?url="+urllib.quote_plus(baseUrl+url+'&m23644322=quelle.tv&rss=true')+"&name="+urllib.quote_plus(name)+"&mode=listVideosRss"+"&nextpage=True"+"&hideshowname=True"+"&showName="+urllib.quote_plus(name)
		liz = xbmcgui.ListItem(name, iconImage=defaultThumb, thumbnailImage=thumb)
		liz.setInfo(type="Video", infoLabels={"Title": name})
		if useThumbAsFanart:
			if not thumb or thumb==icon or thumb==defaultThumb:
				thumb = defaultBackground
			liz.setProperty("fanart_image", thumb)
		else:
			liz.setProperty("fanart_image", defaultBackground)
		items.append([u, liz, True])
	return items
"""		

def getInfo(infos):
	match_title=re.compile('<title>(.+?)</title>', re.DOTALL).findall(infos)
	try:
		match_detail=re.compile('<detail>(.+?)</detail>', re.DOTALL).findall(infos)
		return match_title[0],match_detail[0]
	except:
		return match_title[0],''
	
def chooseThumb(images):
	thumb = fallbackImage
	height = 0
	width = 0
	match_images=re.compile('<teaserimage.+?key="(.+?)x(.+?)">(.+?)</teaserimage>', re.DOTALL).findall(images)
	for h,w,image in match_images:
		if not "fallback" in image:
			if int(h) > height or int(w) > width:
				height = int(h)
				width = int(w)
				thumb = image
	return thumb

def getDetails(details):
	try:
		match_assetId=re.compile('<assetId>(.+?)</assetId>', re.DOTALL).findall(details)
		assetId = match_assetId[0]
	except:
		assetId = ''
	
	try:
		match_channel=re.compile('<channel>(.+?)</channel>', re.DOTALL).findall(details)
		channel = match_channel[0]
	except:
		channel = ''
	
	try:
		if '<lengthSec>' in details:
			length = int(re.compile('<lengthSec>(.+?)</lengthSec>', re.DOTALL).findall(details)[0])
		else:
			match_length=re.compile('<length>(.+?)</length>', re.DOTALL).findall(details)
			length = match_length[0]
			if ' min ' in length:
				l = length.split(' min ')
				length = int(l[0]) * 60 + int(l[1])
			elif ' min' in length:
				l = length.replace(' min','')
				length = int(l) * 60
			elif '.000' in length:#get seconds
				length = length.replace('.000','')
				l = length.split(':')
				length = int(l[0]) * 3600 + int(l[1]) * 60 + int(l[2])
	except:
		length = '0'
		
	try:
		match_channelLogoSmall=re.compile('<channelLogoSmall>(.+?)</channelLogoSmall>', re.DOTALL).findall(details)
		channelLogo = match_channelLogoSmall[0]
	except:
		channelLogo = '0'
		
	try:
		match_airtime=re.compile('<airtime>(.+?)</airtime>', re.DOTALL).findall(details)
		airtime = match_airtime[0]
	except:
		airtime = '0'
		
	try:
		match_timetolive=re.compile('<timetolive>(.+?)</timetolive>', re.DOTALL).findall(details)
		timetolive = match_timetolive[0]
	except:
		timetolive = '0'
		
	try:
		match_fsk=re.compile('<fsk>(.+?)</fsk>', re.DOTALL).findall(details)
		fsk = match_fsk[0]
	except:
		fsk = ''
	
	try:
		match_hasCaption=re.compile('<hasCaption>(.+?)</hasCaption>', re.DOTALL).findall(details)
		hasCaption = match_hasCaption[0]
	except:
		hasCaption = '0'
		
	try:
		match_vcmsUrl=re.compile('<vcmsUrl>(.+?)</vcmsUrl>', re.DOTALL).findall(details)
		url = match_vcmsUrl[0]
	except:
		url = ''
	
	return assetId,channel,length,channelLogo,airtime,timetolive,fsk,hasCaption,url