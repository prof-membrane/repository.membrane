# -*- coding: utf-8 -*-
import xbmc
import json
import _utils
import xbmc
import json
import _utils
base = 'https://api.funk.net/v1.0'

def parse(url):
	response = _utils.getUrl(url)
	j = json.loads(response)
	l = []
	if 'includes' in j:
		part = 'includes'
	else:
		part = 'data'
	for item in j[part]:
		if item['type'] == 'series' or item['type'] == 'format':
			l.append(_parseSeries(item))
		elif item['type'] == 'video':
			l.append(_parseVideo(item))
		else:
			xbmc.log('unkown type: '+item['type'])
	return l
	
def _parseSeries(j):
	d = {}
	d['_name'] = j['attributes']['name']
	d['_thumb'] = j['attributes']['thumbnail']
	d['_plot'] = _cleanPlot(j['attributes']['description'])
	d['_airedISO8601'] = j['attributes']['createdAt']
	d['url'] = base + '/content/series/' + j['id']
	d['_rating'] = str(j['attributes']['kickKeepRatio'] * 10)
	d['mode'] = 'listDir'
	d['_type'] = 'shows'
	return d

def _parseVideo(j):
	d = {}
	d['_name'] = j['attributes']['title']
	
	d['_thumb'] = j['attributes']['image']['url']
	d['_plot'] = _cleanPlot(j['attributes']['text'])
	while '\n\n\n' in d['_plot']:
		d['_plot'] = d['_plot'].replace('\n\n\n','\n\n')
	d['_duration'] = str(j['attributes']['duration'])
	if 'season' in j['attributes']:
		d['_season'] = j['attributes']['season']
	if 'episode' in j['attributes']:
		d['_episode'] = j['attributes']['episode']
	
	if 'fsk' in j['attributes']:
		d['_mpaa'] = 'FSK ' + j['attributes']['fsk']
	
	d['_airedISO8601'] = j['attributes']['createdAt']
	
	d['url'] = 'https://cdnapisec.kaltura.com/p/1985051/sp/198505100/playManifest/entryId/'+j['attributes']['rootEntryId']+'/flavorIds/0/format/applehttp/protocol/https/a.m3u8'
	#d['url'] += '?referrer=aHR0cHM6Ly93d3cuZnVuay5uZXQ='
	
	d['entryId'] = j['attributes']['rootEntryId']
	d['mode'] = 'play'
	d['_type'] = 'video'
	return d
	
def _cleanPlot(plot):
	plot = plot.replace('<p>','')
	plot = plot.replace('</p>','')
	plot = plot.replace('<h4>','')
	plot = plot.replace('</h4>','')
	while '  ' in plot:
		plot = plot.replace('  ',' ')
	plot = plot.replace('\n ','')
	return plot
	