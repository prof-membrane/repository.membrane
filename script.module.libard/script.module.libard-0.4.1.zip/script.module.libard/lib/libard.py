# -*- coding: utf-8 -*-
import libardlisting
import libardrssparser
import libardplayer
#import player
#import subtitle
import libardjsonparser as libArdJsonParser

import libmediathek3 as libMediathek
import xbmc,xbmcaddon

#showSubtitles = xbmcaddon.Addon().getSetting('subtitle') == 'true'
#libMediathek.addEntry(d) = addEntry(d)

#u = "http://www.ardmediathek.de/appdata/servlet/tv/sendungAbisZ?json"
u2 = "http://www.ardmediathek.de/appdata/servlet/tv/sendungVerpasst?json&kanal=5868&tag=2"
#u3 = "http://www.ardmediathek.de/appdata/servlet/tv/Sendung?documentId=3822076&json"
u3 = "http://www.ardmediathek.de/appdata/servlet/tv/Sendung?documentId=32325376&json"
#libArdJsonParser.parseAZ(u)
#libArdJsonParser.parseDate(u2)
#libArdJsonParser.parseVideos(u3)


			  

def getNew():
	return libardlisting.listRSS('http://www.ardmediathek.de/tv/Neueste-Videos/mehr?documentId=21282466&rss=true')
def getMostViewed():
	return libardlisting.listRSS('http://www.ardmediathek.de/tv/Meistabgerufene-Videos/mehr?documentId=21282514&m23644322=quelle.tv&rss=true')

def getSearch(search_string,page=0):
	return libardlisting.listVideos('http://www.ardmediathek.de/suche?searchText='+search_string.replace(" ", "+"))

def getPage(url,page=1):
	return listing.listRSS(url,page)
	
#def getAZ(letter):
#	return listing.getAZ(letter)
def getVideosJson(url,page = '1'):
	return libArdJsonParser.parseVideos(url)

def getVideosXml(videoId):
	return listing.getVideosXml(videoId)
def parser(data):
	return rssparser.parser(data)

def libArdPvrDate(datum,channel):
	import libArdPvr
	return getDate('http://www.ardmediathek.de/tv/sendungVerpasst?tag='+datum+'&kanal='+libArdPvr.channelList[channel])
	
	
import time
import urllib,urllib2,re,random,xbmc,xbmcplugin,xbmcgui,xbmcaddon,cookielib,HTMLParser,datetime
import sys
from datetime import date, timedelta
translation = libMediathek.getTranslation
try:
	xbmc.log(sys.argv[0])
	xbmc.log(sys.argv[1])
	xbmc.log(sys.argv[2])
	pluginhandle = int(sys.argv[1])
except: pass
hideAudioDisa = True
#showSubtitles = False
helix = False
fanart = ''

addon = xbmcaddon.Addon()
transAddon = addon.getLocalizedString
transBuildin = xbmc.getLocalizedString

weekdayDict = { '0': translation(31013),#Sonntag
				'1': translation(31014),#Montag
				'2': translation(31015),#Dienstag
				'3': translation(31016),#Mittwoch
				'4': translation(31017),#Donnerstag
				'5': translation(31018),#Freitag
				'6': translation(31019),#Samstag
			  }

channels = {
			  'ARD-alpha':'5868',
			  'BR':'2224',
			  #['Einsfestival', :'673348' ],
			  #['EinsPlus',     :'4178842'],
			  'Das Erste':'208',
			  'HR':'5884',
			  'MDR':'5882',
			  'MDR Thüringen':'1386988',
			  'MDR Sachsen':'1386804',
			  'MDR Sachsen-Anhalt':'1386898',
			  'NDR Fernsehen':'5906',
			  'One':'673348',
			  'RB':'5898',
			  'RBB':'5874',
			  'SR':'5870',
			  'SWR Fernsehen':'5310',
			  'SWR Rheinland-Pfalz':'5872',
			  'SWR Baden-Württemberg':'5904',
			  'tagesschau24':'5878',
			  'WDR':'5902',}
			  
def libArdListMain():
	l = []
	l.append({'name':translation(31030), 'mode':'libArdListVideosSinglePage', 'url':'http://www.ardmediathek.de/tv/Neueste-Videos/mehr?documentId=21282466&rss=true'})
	l.append({'name':translation(31031), 'mode':'libArdListVideosSinglePage', 'url':'http://www.ardmediathek.de/tv/Meistabgerufene-Videos/mehr?documentId=21282514&m23644322=quelle.tv&rss=true'})
	#l.append({'name':translation(31032), 'mode':'libArdListLetters'})
	l.append({'name':translation(31032), 'mode':'libArdListShows'})
	l.append({'name':translation(31033), 'mode':'libArdListChannel'})
	l.append({'name':translation(31034), 'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/appdata/servlet/tv/Rubriken/mehr?documentId=21282550&json'})
	l.append({'name':translation(31035), 'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/appdata/servlet/tv/Themen/mehr?documentId=21301810&json'})
	#l.append({'name':'Fußball EM 2016',  'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/appdata/servlet/tv/EM-Highlights-Spiele-Tore/Thema?documentId=35531744&json'})
	#l.append({'name':'Olympia 2016',  'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/tv/Die-Olympischen-Spiele-2016/mehr?documentId=36636948'})
	#l.append({'name':translation(31039), 'mode':'libArdSearch'})
	return l
	
def libArdListVideos():
	return getVideosJson(params['url'])#,page)
		
def libArdListVideosSinglePage():
	page = params.get('page','1')
	xbmc.log(str(params))
	items,nextPage = libardlisting.listRSS(params['url'],page)
	return items
	
def libArdListLetters():
	return libMediathek.populateDirAZ('libArdListShows',[])
	
def libArdListShows():
	return libArdJsonParser.parseAZ()
	
def libArdListChannel():
	l = []
	for channel in channels:
		dict = {}
		dict['_name'] = channel
		dict['channel'] = channel
		dict['mode'] = 'libArdListChannelDate'
		l.append(dict)
		
	return l
	
def libArdListChannelDate():
	return libMediathek.populateDirDate('libArdListChannelDateVideos',params['channel'],True)
	
def libArdListChannelDateVideos():
	if False:
		url = 'http://www.ardmediathek.de/tv/sendungVerpasst?tag='+params['datum']+'&kanal='+channels[params['channel']]
		return libardlisting.listDate(url)
	url = 'http://www.ardmediathek.de/appdata/servlet/tv/sendungVerpasst?json&kanal='+channels[params['channel']]+'&tag='+params['datum']
	return libArdJsonParser.parseDate(url)
	
def libArdSearch():
	keyboard = xbmc.Keyboard('', 'TODO')
	keyboard.doModal()
	if keyboard.isConfirmed() and keyboard.getText():
		libArdListSearch(keyboard.getText())
		

def libArdListSearch(searchString):
	list = getSearch(searchString)
	for dict in list:
		dict['mode'] = 'libArdPlay'
		dict['type'] = 'video'
		libMediathek.addEntry(dict)
	
def libArdPlay():
	xbmc.log(str(params))
	url = libardplayer.getVideoUrl(videoID = params['documentId'])
	d = {'media': [{'url':url, 'type': 'video', 'stream':'hls'}]}
	
	return d

	

def list():
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','libArdListMain')
	xbmc.log(mode)
	if mode == 'libArdPlay':
		libMediathek.play(libArdPlay())
	else:
		l = modes.get(mode,libArdListMain)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
	
modes = {
	'libArdListMain':libArdListMain,
	'libArdListVideos':libArdListVideos,
	'libArdListVideosSinglePage':libArdListVideosSinglePage,
	'libArdListLetters':libArdListLetters,
	'libArdListShows':libArdListShows,
	'libArdListChannel':libArdListChannel,
	'libArdListChannelDate':libArdListChannelDate,
	'libArdListChannelDateVideos':libArdListChannelDateVideos,
	'libArdSearch':libArdSearch,
	'libArdListSearch':libArdListSearch,
	'libArdPlay':libArdPlay,
	}