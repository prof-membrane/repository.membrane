#!/usr/bin/python
# -*- coding: utf-8 -*-

def parseAZ(channel,letter):
	return []

def parseDate(channel,date):
	return []

def getVideoUrl(clipId):
	return None
