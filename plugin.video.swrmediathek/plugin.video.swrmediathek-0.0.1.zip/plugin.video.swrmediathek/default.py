﻿# -*- coding: utf-8 -*-
import libSwr

libSwr.list()