﻿# -*- coding: utf-8 -*-
import libswr

libswr.list()