﻿# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,string,random,cookielib,xbmcvfs

import json
import libMediathek
import resources.lib._utils as _utils

baseUrl = 'http://em.zdf.de/'
feed = 'http://em.zdf.de/feeds/myviewfilter/myviewlatest/'
pluginhandle = int(sys.argv[1])

def main():
	list = []
	response = _utils.getUrl(feed)
	j = json.loads(response)
	for data in j['myviewlatest']['data']:
		dict = {}
		dict['url'] = baseUrl + data["url"]
		dict['name'] = data["title"]
		dict['myview_id'] = data["myview_id"]
		dict['thumb'] = data["thumbnails"][0]["url"]
		dict['type'] = 'dir'
		dict['mode'] = 'listViews'
		list.append(dict)
	libMediathek.addEntries(list)
	
def listViews():
	list = []
	response = _utils.getUrl(params['url'])
	cameras = re.compile('<div class="cameras">(.+?)</div>', re.DOTALL).findall(response)[0]
	perspectives = re.compile('<a(.+?)</a>', re.DOTALL).findall(cameras)
	for persp in perspectives:
		dict = {}
		dict['name'] = re.compile('title="(.+?)"', re.DOTALL).findall(persp)[0]
		dict['url'] = baseUrl + re.compile('href="(.+?)"', re.DOTALL).findall(persp)[0]
		dict['thumb'] = params['thumb']
		dict['mode'] = 'play'
		dict['type'] = 'video'
		list.append(dict)
	libMediathek.addEntries(list)
	
def play():
	response = _utils.getUrl(params['url'])
	mp4 = re.compile('<meta name="assetmp4" content="(.+?)"', re.DOTALL).findall(response)[0]
	response = _utils.getUrl('http://em.zdf.de/myview/token/')
	token = re.compile('"(.+?)"', re.DOTALL).findall(response)[-1]
	
	url = mp4 + '?' + token
	
	listitem = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	
	
	
	



params=libMediathek.get_params()
if not params.has_key('mode'):
	main()
elif params['mode'] == 'listViews':
	listViews()
elif params['mode'] == 'play':
	play()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
