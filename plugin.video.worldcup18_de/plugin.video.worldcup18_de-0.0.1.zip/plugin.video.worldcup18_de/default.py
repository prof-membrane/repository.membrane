# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import resources.lib.jsonparser as jsonParser

translation = libMediathek.getTranslation
def main():
	l = []
	l.append({'_name':'Neuste Videos', 'mode':'listVideos', '_type': 'dir', 'url':'https://hbsard.deltatre.net/hbs/api/cup/fifawc/season/2018/videos/videolist'})
	l.append({'_name':'Heutige Spiele', 'mode':'listMatchesToday', '_type': 'dir', 'url':'https://hbsard.deltatre.net/hbs/api/cup/fifawc/season/2018/todaymatches?timezoneoffset=2'})
	l.append({'_name':'Spiele nach Datum', 'mode':'listMatchDates', '_type': 'dir'})
	return l
	
def listMatchDates():
	return jsonParser.parseMatchDates()
	
def listMatches():
	return jsonParser.parseMatches(params['url'])
	
def listMatchesToday():
	return jsonParser.parseMatchesToday(params['url'])
	
def listMatch():
	return jsonParser.parseMatch(params['url'])
		
def listVideos():
	return jsonParser.parseVideos(params['url'])
	
def listMulti():
	return jsonParser.grepMulti(params['matchId'])
	
def play():
	return jsonParser.getVideoUrl(params['vId'])


modes = {
'main': main,
'listMatchDates': listMatchDates,
'listMatches': listMatches,
'listMatchesToday': listMatchesToday,
'listMatch': listMatch,
'listVideos': listVideos,
'listMulti': listMulti,
'play': play
}	

def list():	
	global params
	params = libMediathek.get_params()
	
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		libMediathek.endOfDirectory()
list()