# -*- coding: utf-8 -*-
import re
import libmediathek3 as libMediathek

def grepToken():
	response = libMediathek.getUrl('https://www.zdf.de/')
	apitokens = re.compile("apiToken: '(.+?)'", re.DOTALL).findall(response)
	libMediathek.setSetting('tokenMenu', apitokens[0])
	libMediathek.setSetting('tokenPlayer', apitokens[1])
	return