# -*- coding: utf-8 -*-
from datetime import date
import xbmc,sys
import time

dateformat = 'weekday, DD. Month YYYY'  

months = {
			"Januar":1,
			"Februar":2,
			"März":3,
			"April":4,
			"Mai":5
		}#todo

def getMinutes():
	videodate = xbmc.getInfoLabel("ListItem.Date")
	t = videodate.split(" ")[-1]
	HH,MM = t.split(":")
	return int(HH) * 60 + int(MM)
	
def timeToMM(t):
	HH,MM = t.split(":")
	return int(HH) * 60 + int(MM)
	
def getDuration():
	d = xbmc.getInfoLabel("ListItem.Duration").split(":")
	for i, val in enumerate(d[::-1]):
		if i == 0:
			duration = int(val)
		elif i == 1:
			duration += int(val) * 60
		elif i == 2:
			duration += int(val) * 3600
	return duration
def getChannelName():
	channel = xbmc.getInfoLabel("ListItem.ChannelName")
	channel = channel.replace("HD","").replace(" ","").replace(".","").replace("-","").replace("/","").lower()
	return channel
	
def getDate():#TODO find out if there is a batter way to do this (JSON???)
	#videodate = xbmc.getInfoLabel("ListItem.Date")
	
	if dateformat == 'weekday, DD. Month YYYY':
		return getDateDE()
	
def getDateDE():
	videodate = xbmc.getInfoLabel("ListItem.StartDate")
	d = videodate.split(" ")
	DD = int(d[1].replace(".",""))
	MM = int(months[d[2]])
	YYYY = int(d[3])
	delta = date.today() - date(YYYY, MM, DD)
	return delta.days
	
def getInfos():
	
	xbmc.log(xbmc.getInfoLabel("ListItem.Label"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Label2"))
	xbmc.log(xbmc.getInfoLabel("ListItem.OriginalTitle"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Episode"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Season"))
	xbmc.log(xbmc.getInfoLabel("ListItem.FileName"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Date"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Tagline"))
	xbmc.log(xbmc.getInfoLabel("ListItem.EpisodeName"))
	xbmc.log(xbmc.getInfoLabel("ListItem.Duration"))
	xbmc.log("#############")
	xbmc.log(xbmc.getInfoLabel("ListItem.Path"))
	xbmc.log("#############")
	xbmc.log(xbmc.getInfoLabel("ListItem.FileNameAndPath"))
	xbmc.log("#############")
	xbmc.log(sys.listitem.getLabel("Path"))
	dict = {}
	#videodate = xbmc.getInfoLabel("ListItem.Date")
	#xbmc.log(videodate)#25.04.2016 19:50
	dict["epoch"] = int(time.mktime(time.strptime(xbmc.getInfoLabel("ListItem.Date"), '%d.%m.%Y %H:%M')))
	dict["date"] = xbmc.getInfoLabel("ListItem.FileName").split(" ")[0]
	dict["time"] = getMinutes()
	dict["duration"] = getDuration()
	dict["name"] = xbmc.getInfoLabel("ListItem.Title")
	dict["episode"] = xbmc.getInfoLabel("ListItem.EpisodeName")

	dict["day"] = getDate()
	dict["channel"] = getChannelName()
	return dict