# -*- coding: utf-8 -*-
import libBr
import resources.lib.helper as helper


channels = {"br":"br",
			   "brfernsehen":"br",
			   "brnord":"br",
			   "brfernsehennord":"br",
			   "ardalpha":"ardalpha",
			  }
def play():
	dict = helper.getInfos()
	libBr.libBrPvrPlay(dict)