# -*- coding: utf-8 -*-
import libArd
import resources.lib.helper as helper


channels = {"daserste":"daserste",
			   "einsfestival":"einsfestival",
			   "wdr":"wdr",
			   "wdrköln":"wdr",
			   "br":"br",
			   "brfernsehen":"br",
			   "brnord":"br",
			   "brfernsehennord":"br",
			   "mdr":"mdr",
			   "mdrsachsen":"mdr",
			   "mdrthüringen":"mdr",
			   "mdrsachsenanhalt":"mdr",
			   "rbb":"rbb",
			   "rbbberlin":"rbb",
			   "rbbbrandenburg":"rbb",
			   "sr":"sr",#todo make more
			   "hr":"hr",#todo make more
			   "ndr":"ndr",
			   "tagesschau24":"tagesschau24",
			   "ardalpha":"ardalpha",
			   "einsplus":"einsplus",
			   "swr":"swr",
			   "swrrheinlandpfalz":"swr",
			   "swrbadenwürttemberg":"swr",
			  }
def play():
	dict = helper.getInfos()
	dict["channel"] = dict["channel"].replace(" HD","")
	if dict["channel"] == 'mdrsachsen' or dict["channel"] == 'mdrsachsenanhalt' or dict["channel"] == 'mdrthüringen':
		if dict["time"] == 1140:
			#libArd.libArdPvrPlay(dict["time"],dict["day"],dict["name"],dict["channel"])
			libArd.libArdPvrPlay(dict)
		else:
			#libArd.libArdPvrPlay(dict["time"],dict["day"],dict["name"],channels[dict["channel"]])
			dict["channel"] = channels[dict["channel"]]
			libArd.libArdPvrPlay(dict)
			
	else:
		#libArd.libArdPvrPlay(dict["time"],dict["day"],dict["name"],channels[dict["channel"]])
		dict["channel"] = channels[dict["channel"]]
		libArd.libArdPvrPlay(dict)