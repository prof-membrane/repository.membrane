# -*- coding: utf-8 -*-
import xbmc
import resources.lib.helper as helper
import resources.lib.ard as ard
import resources.lib.br as br
import resources.lib.zdf as zdf

channel = helper.getChannelName()
date = 0
if date < 0:#TODO
	xbmc.log("Show in future")
	xbmc.executebuiltin("Notification(Kein Video gefunden,Sendung liegt in der Zukunft, 7000)")
		
elif channel in br.channels:
	br.play()
elif channel in ard.channels:
	ard.play()
elif channel in zdf.channels:
	zdf.play()
#elif channel in arte.channels:
#	arte.play()
#elif channel in servustv.channels:
#	servustv.play()
else:
	xbmc.log("channel not supported")
	xbmc.executebuiltin("Notification(Kein Video gefunden,Sender wird nicht unterstützt, 7000)")