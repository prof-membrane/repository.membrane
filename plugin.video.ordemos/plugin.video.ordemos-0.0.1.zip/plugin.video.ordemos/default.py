# -*- coding: utf-8 -*-
import libMediathek
import xbmc
import xbmcplugin
import xbmcgui


livestreams = [
['BR Fernsehen','http://irtdashreference-i.akamaihd.net/dash/live/901161/bfs/manifestBR.mpd'],
#['BR Fernsehen','http://akamai-progressive.irt.de/hbb4all/keepixo/br_kochshow/manifest.mpd'],#broken
['RBB','http://einfest_dash-i.akamaihd.net/dash/live/925660/rbbtest/manifest.mpd'],
#['',''],
]
videostreams = [
['RBB: Ein Sommer in Brandenburg','http://akamai-progressive.irt.de/hbb4all/sommer_brandenburg/dash/sommer_brandenburg.mpd','RBB\n\nDASH\nh264\n??MBit/s'],
['HR: Hessenschau 10.08.2016','http://media_pm.hr.de/test/adaptiveStreaming2016/2016-08-10/default_ref-0908161714448_file-saw2odin_HD-AVCI100-25i-TFF-AR16_9-1920x1080-26m-52s-16singletracks-saw2odin-hessenschau-ganz1920x1080-50p-8000kbit.mp4','RBB\n\n1920x1080\nhttp/mp4\nh264\n8MBit/s'],
#['bua','http://pd-media.zdf.de/Huberbuam_1080p_SbS_12MBit.mp4.zip'],
#['',''],
]
uhdstreams = [
['Arte: Le Corsaire','http://akamai-progressive.irt.de/arte_uhd_opera_ateme/M4S/3840x2160p50_8bar_h265_main_bt709_gop100_bit14M_max14M_buf20M.mpd','Arte \n\nDASH\nHEVC\n14MBit/s','10090'],
['RBB: Verknallt und Abgedreht Folge 1','http://akamai-progressive.irt.de/tvring/VuA_Folge_01/mp4/VuA_Folge_01_uhd.mp4','RBB \n\nhttp/mp4\nHEVC\n12MBit/s','1474'],
['ZDF: Terra X - Mythos Wolfskind','http://pd-media.zdf.de/wk_h265_HDR-12M.mp4','ZDF\n\nhttp/mp4\nHEVC\n12MBit/s\nHDR','2640'],
#['','',''],
]
vrstreams = [
['Neo Magazin Royale','http://pd-media.zdf.de/360/zdf/NMZ-JF-KW35/video/download/4K/de/NMZ-JF-KW35-webgl_4K.mp4']
]

def main():
	libMediathek.addEntry({'name':'Livestreams','mode':'live','type':'dir'})
	libMediathek.addEntry({'name':'Videos','mode':'video','type':'dir'})
	libMediathek.addEntry({'name':'UHD Demos','mode':'uhd','type':'dir'})
	#libMediathek.addEntry({'name':'VR Demos','mode':'vr','type':'dir'})
	
def live():
	_list(livestreams)
def video():
	_list(videostreams)
def uhd():
	_list(uhdstreams)
def vr():
	_list(vrstreams)
	
def _list(streams):
	xbmc.log('main')
	for stream in streams:
		name = stream[0]
		url = stream[1]
		plot = ''
		duration = ''
		if len(stream) > 2:
			plot = stream[2]
		if len(stream) > 3:
			duration = stream[3]
		libMediathek.addEntry({'name':name,'url':url,'mode':'play','type':'video','plot':plot,'duration':duration})
		
def play():
	url = params['url']
	listitem = xbmcgui.ListItem(path=url)
	#listitem.setProperty('inputstreamaddon', 'Input Stream')
	if url.endswith('.mpd'):
		listitem.setProperty('inputstreamaddon', 'inputstream.mpd')
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)


modes = {
'main': main,
'live': live,
'video': video,
'uhd': uhd,
'vr': vr,
'play': play
}	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	if not params.has_key('mode'):
		main()
	else:
		modes.get(params['mode'],main)()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
list()