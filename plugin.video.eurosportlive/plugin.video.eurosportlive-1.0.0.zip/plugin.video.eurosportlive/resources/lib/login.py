# -*- coding: utf-8 -*-
import urllib
import re
import libmediathek3 as libMediathek


headerLogin = 	{
			'Content-Type':'application/json',
			}
			

def login():
	url = 'https://www.eurosport.de/_wscommunityV8_/Community_V8.svc/LoginEurosport'
	email = libMediathek.getSetting('email')
	password = libMediathek.getSetting('password')
	post = '{"email":"'+email+'","password":"'+password+'","dropletId":"148"}'
	libMediathek.log(post)
	
	response = libMediathek.getUrl(url,post=post,cookies=True,headers=headerLogin)
	libMediathek.log(response)
	return
	