# -*- coding: utf-8 -*-
import urllib
import re
import json
import libmediathek3 as libMediathek
import base64

def getVideoUrl():
	url = 'https://www.eurosport.de/watch-eurosport-live.shtml'
	response = libMediathek.getUrl(url,cookies=True)
	url = re.compile('<source src="(.+?)"', re.DOTALL).findall(response)[0]
	d = {}
	d['media'] = []
	d['media'].append({'url':'http:'+url, 'type': 'video', 'stream':'HLS'})
	return d
