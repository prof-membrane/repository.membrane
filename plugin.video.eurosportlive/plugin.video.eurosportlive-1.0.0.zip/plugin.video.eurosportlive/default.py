# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import resources.lib.login as login
import resources.lib.player as player
def main():
	login.login()
	l = []
	l.append({'_name':'Play', 'mode':'play', '_type': 'video'})
	return l
	
def play():
	return player.getVideoUrl()


modes = {
'main': main,
'play': play
}	

def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		libMediathek.endOfDirectory()	
list()