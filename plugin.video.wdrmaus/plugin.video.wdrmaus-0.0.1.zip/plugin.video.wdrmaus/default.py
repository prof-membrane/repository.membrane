# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import xbmcplugin
import xbmcaddon
import libwdr
import re

translation = xbmcaddon.Addon().getLocalizedString
xml = 'http://www.wdrmaus.de/_export/videositemap.php5'

def main():
	l = []
	l.append({'name':'Sachgeschichten', 'mode':'listVideos', '_type':'dir'})
	l.append({'name':'Lachgeschichten', 'mode':'listVideos', '_type':'dir'})
	l.append({'name':'Mausspots', 'mode':'listVideos', '_type':'dir'})
	l.append({'name':'Lieder', 'mode':'listVideos', '_type':'dir'})
	
	#names = []
	#response = libMediathek.getUrl(xml)
	#categories = re.compile('<video:category>(.+?)</video:category>', re.DOTALL).findall(response)
	#for cat in categories:
	#	if not cat in names:
	#		l.append({'name':cat, 'mode':'listVideos', '_type':'dir'})
	#		names.append(cat)
	return l
	
def listVideos():
	l = []
	response = libMediathek.getUrl(xml)
	videos = re.compile('<url>(.+?)</url>', re.DOTALL).findall(response)
	for video in videos:
		#libMediathek.log(video)
		if params['name'] == re.compile('<video:category>(.+?)</video:category>', re.DOTALL).findall(video)[0]:
			d = {}
			d['name'] = re.compile('<video:title><!\[CDATA\[(.+?)\]\]></video:title>', re.DOTALL).findall(video)[0].replace('![CDATA[','').replace(']]','')
			d['_thumb'] = 'http://' + re.compile('<video:thumbnail_loc><!\[CDATA\[//(.+?)\]\]></video:thumbnail_loc>', re.DOTALL).findall(video)[0].replace('![CDATA[','').replace(']]','')
			d['url'] = re.compile('<video:player_loc.+?><!\[CDATA\[(.+?)\]\]></video:player_loc>', re.DOTALL).findall(video)[0].replace('![CDATA[','').replace(']]','')
			d['_type'] = 'video'
			d['mode'] = 'libWdrPlayJs'
			libMediathek.log(str(d))
			l.append(d)
	return l

modes = {
'main': main,
'listVideos': listVideos,
}
	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	mode = params.get('mode','main')
	if mode.startswith('libWdr'):
		libwdr.list()
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
list()