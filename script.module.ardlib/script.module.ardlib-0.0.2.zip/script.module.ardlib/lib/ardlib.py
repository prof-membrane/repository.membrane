# -*- coding: utf-8 -*-
import listing
import rssparser
import player


def getNew():
	return listing.listRSS('http://www.ardmediathek.de/tv/Neueste-Videos/mehr?documentId=23644268&m23644322=quelle.tv&rss=true')
def getMostViewed():
	return listing.listRSS('http://www.ardmediathek.de/tv/Meistabgerufene-Videos/mehr?documentId=21282514&m23644322=quelle.tv&rss=true')
def getAZ(letter):
	return listing.getAZ(letter)
def getDate(url):
	return listing.listDate(url)

def getVideoUrl(url):
	return player.getVideoUrl(url)
def getPage(url):
	return listing.listRSS(url)
	
#def getAZ(letter):
#	return listing.getAZ(letter)
def getVideosXml(videoId):
	return listing.getVideosXml(videoId)
def parser(data):
	return rssparser.parser(data)
	
	