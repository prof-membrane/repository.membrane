# -*- coding: utf-8 -*-
import libMediathek
import xbmc
import xbmcplugin
import xbmcgui


streams = [
	['ZDF','http://zdf1314-lh.akamaihd.net/i/de14_v1@392878/master.m3u8?dw=0'],
	['Olympia 1','http://zdf0304-lh.akamaihd.net/i/de03_v1@392855/master.m3u8?dw=0'],
	['Olympia 2','http://zdf0304-lh.akamaihd.net/i/de04_v1@392856/master.m3u8?dw=0'],
	['Olympia 3','http://zdf0506-lh.akamaihd.net/i/de05_v1@392857/master.m3u8?dw=0'],
	['Olympia 4','http://zdf0506-lh.akamaihd.net/i/de06_v1@392858/master.m3u8?dw=0'],
	['Olympia 5','http://zdf0708-lh.akamaihd.net/i/de07_v1@392868/master.m3u8?dw=0'],
	['Olympia 6','http://zdf0708-lh.akamaihd.net/i/de08_v1@392869/master.m3u8?dw=0'],
]

def main():
	xbmc.log('main')
	for name,url in streams:
		libMediathek.addEntry({'name':name,'url':url,'mode':'play','type':'video'})
def play():
	url = params['url']
	listitem = xbmcgui.ListItem(path=url)
	#listitem.setProperty('inputstreamaddon', 'Input Stream')
	#listitem.setProperty('inputstreamaddon', 'inputstream.mpd')
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)


modes = {
'main': main,
'play': play
}	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	if not params.has_key('mode'):
		main()
	else:
		modes.get(params['mode'],main)()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
list()