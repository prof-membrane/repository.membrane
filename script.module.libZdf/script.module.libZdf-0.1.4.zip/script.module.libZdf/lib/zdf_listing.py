﻿#!/usr/bin/python
# -*- coding: utf-8 -*-
import re
import sys
import xbmcplugin
import xbmcgui
import urllib
import _utils as utils
import fanart
#import requests


baseUrl = "http://www.zdf.de"
#'http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd=C&detailLevel=2&characterRangeStart=A'
fallbackImage = "http://www.zdf.de/ZDFmediathek/img/fallback/946x532.jpg"
defaultThumb = ''

def getXML(url,page=1):
	if page > 1:
		url += '&offset='+str((page-1)*50)
	print url
	#t = []
	list = []
	response = utils.getUrl(url)
	#r = requests.get(url)
	#response = r.text.decode('utf-8')
	additionalTeaser=re.compile('<additionalTeaser>(.+?)</additionalTeaser>', re.DOTALL).findall(response)[0]
	if not '<teasers>' in response:
		return list,False
	teasers=re.compile('<teasers>(.+?)</teasers>', re.DOTALL).findall(response)[0]
	match_teaser=re.compile('<teaser(.+?)</teaser>', re.DOTALL).findall(teasers)
	for teaser in match_teaser:
		dict = {}
		#match_member=re.compile('member="(.+?)"', re.DOTALL).findall(teaser)
		dict['type'] = re.compile('<type>(.+?)</type>', re.DOTALL).findall(teaser)[0]
		dict['thumb'] = chooseThumb(re.compile('<teaserimages>(.+?)</teaserimages>', re.DOTALL).findall(teaser)[0])
		dict.update(getInfo(re.compile('<information>(.+?)</information>', re.DOTALL).findall(teaser)[0]))
		dict.update(getDetails(re.compile('<details>(.+?)</details>', re.DOTALL).findall(teaser)[0]))
		#title = cleanTitle(title)
		#print dict
		if dict['type'] == 'sendung' and dict['duration'] != '0':
			dict['url'] = baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=' + dict['assetId']
			dict['fanart'] = dict['thumb']
			list.append(dict)
		elif dict['type'] == 'video':
			dict['plot'] += '\n\n'+dict['airtime'].split(' ')[0]+' | '+toMin(dict['duration'])+' | '+dict['channel']
			dict['url'] = baseUrl+'/ZDFmediathek/xmlservice/web/beitragsDetails?id=' + dict['assetId']
			f = fanart.getFanart(dict['originChannelId'])
			if f:
				dict['fanart'] = f
			list.append(dict)
		elif dict['type'] == 'rubrik' or dict['type'] == 'thema':
			dict['url'] = baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=' + dict['assetId']
			list.append(dict)
		#thumbQuality = dict['thumb'].split('/')[-2]
		#t.append([dict['assetId'],thumbQuality])
	#fanart.addFanart(t)
	if additionalTeaser == 'true':
		return list,True
	else:
		return list,False
			
			
		
"""		
			addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id='+assetId,2,thumb,plot,channel)
		elif type == 'video':
			stuff = stuff + addLink(title,assetId,3,thumb,plot,length,airtime,timetolive,fsk,hasCaption,channel=channel)
		#elif type == 'imageseries_informativ':#TODO
		#	addLink(title,assetId,3,thumb,plot,length,airtime,timetolive,fsk,hasCaption)
		elif type == 'rubrik' and length != '0':
			stuff = stuff + addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&ak=web&id='+assetId,2,thumb,plot,channel)
		elif type == 'topthema' or type == 'thema' and length != '0':
			stuff = stuff + addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&ak=web&id='+assetId,2,thumb,plot,channel)
		elif type == 'sender' and length != '0':
			stuff = stuff + addDir(title + ' (' + length + ')',baseUrl+'/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&ak=web&id='+assetId,2,thumb,plot,channel)
		elif type == 'livevideo':
			if match_member[0] == 'onAir':
				stuff = stuff + addLink(title,assetId,3,thumb,plot,0,airtime,timetolive,fsk,hasCaption,channel=channel)

	items = []
	l = getAZ(letter)
	for name, url, thumb in l:
		u = sys.argv[0]+"?url="+urllib.quote_plus(baseUrl+url+'&m23644322=quelle.tv&rss=true')+"&name="+urllib.quote_plus(name)+"&mode=listVideosRss"+"&nextpage=True"+"&hideshowname=True"+"&showName="+urllib.quote_plus(name)
		liz = xbmcgui.ListItem(name, iconImage=defaultThumb, thumbnailImage=thumb)
		liz.setInfo(type="Video", infoLabels={"Title": name})
		if useThumbAsFanart:
			if not thumb or thumb==icon or thumb==defaultThumb:
				thumb = defaultBackground
			liz.setProperty("fanart_image", thumb)
		else:
			liz.setProperty("fanart_image", defaultBackground)
		items.append([u, liz, True])
	return items
"""		

def getInfo(infos):
	dict = {}
	dict['name']=re.compile('<title>(.+?)</title>', re.DOTALL).findall(infos)[0]
	try:
		dict['plot']=re.compile('<detail>(.+?)</detail>', re.DOTALL).findall(infos)[0]
	except: pass
		
	return dict
	
def chooseThumb(images,maxW=476):
	thumb = fallbackImage
	height = 0
	width = 0
	match_images=re.compile('<teaserimage.+?key="(.+?)x(.+?)">(.+?)</teaserimage>', re.DOTALL).findall(images)
	for w,h,image in match_images:
		if not "fallback" in image:
			if int(h) > height or int(w) > width:
				if int(w) <= maxW:
					height = int(h)
					width = int(w)
					thumb = image
	#print str(width)+'x'+str(height)
	return thumb

def getDetails(details):
	dict = {}
	try:
		dict['assetId']=re.compile('<assetId>(.+?)</assetId>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['originChannelId']=re.compile('<originChannelId>(.+?)</originChannelId>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['channel']=re.compile('<channel>(.+?)</channel>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['channelLogo']=re.compile('<channelLogoSmall>(.+?)</channelLogoSmall>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['airtime']=re.compile('<airtime>(.+?)</airtime>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['timetolive']=re.compile('<timetolive>(.+?)</timetolive>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['fsk']=re.compile('<fsk>(.+?)</fsk>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['hasCaption']=re.compile('<hasCaption>(.+?)</hasCaption>', re.DOTALL).findall(details)[0]
	except: pass
	try:
		dict['vcmsUrl']=re.compile('<vcmsUrl>(.+?)</vcmsUrl>', re.DOTALL).findall(details)[0]
	except: pass
		
	try:
		if '<lengthSec>' in details:
			dict['duration'] = int(re.compile('<lengthSec>(.+?)</lengthSec>', re.DOTALL).findall(details)[0])
		else:
			length=re.compile('<length>(.+?)</length>', re.DOTALL).findall(details)[0]
			if ' min ' in length:
				l = length.split(' min ')
				length = int(l[0]) * 60 + int(l[1])
			elif ' min' in length:
				l = length.replace(' min','')
				length = int(l) * 60
			elif '.000' in length:#get seconds
				length = length.replace('.000','')
				l = length.split(':')
				length = int(l[0]) * 3600 + int(l[1]) * 60 + int(l[2])
			dict['duration'] = length
	except: pass
	
	return dict
	
def toMin(s):
	m, s= divmod(int(s), 60)
	M = str(m)
	S = str(s)
	if len(M) == 1:
		M = '0'+M
	if len(S) == 0:
		S = '00'
	elif len(S) == 1:
		S = '0'+S
	return M+':'+S+' Min.'