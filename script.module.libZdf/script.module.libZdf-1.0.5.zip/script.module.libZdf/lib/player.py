import xbmc

class myPlayer( xbmc.Player ):

    def __init__( self, *args ):
        xbmc.log('####################################################################')
