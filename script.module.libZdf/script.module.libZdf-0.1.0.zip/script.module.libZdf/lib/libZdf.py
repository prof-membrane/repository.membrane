﻿# -*- coding: utf-8 -*-
import zdf_listing
import zdf_play
import libZdfSubtitle

def getNew(entries=50):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=%5FSTARTSEITE')[:entries]
def getMostViewed(entries=50):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/meistGesehen?maxLength=50&id=%5FGLOBAL')[:entries]
def getAZ(letter):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd='+letter+'&detailLevel=2&characterRangeStart='+letter)
def getSearch(search_string,page=1):
	return zdf_listing.getXML('https://www.zdf.de/ZDFmediathek/xmlservice/web/detailsSuche?searchString='+search_string+'&maxLength=20')

	
def getXML(url,page=1):
	return zdf_listing.getXML(url,page)
def getVideoUrl(url,useSub=False):
	print 'playing:'+url
	video,subUrl,offset = zdf_play.getVideoUrl(url)
	if useSub and subUrl:
		return video,libZdfSubtitle.getSub(subUrl,offset)
	else:
		return video,False
	

	
import time
import urllib,urllib2,re,random,xbmcplugin,xbmcgui,xbmcaddon,cookielib,HTMLParser,datetime
import sys
from datetime import date, timedelta
pluginhandle = int(sys.argv[1])
hideAudioDisa = True
showSubtitles = False
helix = False
fanart = ''
weekdayDict = { '0': 'Sonntag',#translation(31013),#Sonntag
				'1': 'Montag',#translation(31014),#Montag
				'2': 'Dienstag',#translation(31015),#Dienstag
				'3': 'Mittwoch',#translation(31016),#Mittwoch
				'4': 'Donnerstag',#translation(31017),#Donnerstag
				'5': 'Freitag',#translation(31018),#Freitag
				'6': 'Samstag',#translation(31019)}#Samstag
				}
cannelList = [['3sat',                  'ZDF',  '1209116'],
			  ['ARD-alpha',             'ARD',  '5868'   ],
			  ['Arte',                  'Arte', ''       ],
			  ['BR',                    'ARD',  '2224'   ],
			  #['Einsfestival',          'ARD',  '673348' ],
			  ['EinsPlus',              'ARD',  '4178842'],
			  ['Das Erste',             'ARD',  '208'    ],
			  ['HR',                    'ARD',  '5884'   ],
			  ['MDR Fernsehen',         'ARD',  '5882'   ],
			  ['MDR Thüringen',         'ARD',  '1386988'],
			  ['MDR Sachsen',           'ARD',  '1386804'],
			  ['NDR Fernsehen',         'ARD',  '5906'   ],
			  ['Phoenix',               'ZDF',  '2256088'],
			  ['RB',                    'ARD',  '5898'   ],
			  ['RBB',                   'ARD',  '5874'   ],
			  ['SR',                    'ARD',  '5870'   ],
			  ['SWR Fernsehen',         'ARD',  '5310'   ],
			  ['SWR Rheinland-Pfalz',   'ARD',  '5872'   ],
			  ['SWR Baden-Württemberg', 'ARD',  '5904'   ],
			  ['tagesschau24',          'ARD',  '5878'   ],
			  ['WDR',                   'ARD',  '5902'   ],
			  ['ZDF',                   'ZDF',  '1209114'],
			  ['ZDFinfo',               'ZDF',  '1209120'],
			  ['ZDF.kultur',            'ZDF',  '1317640'],
			  ['ZDFneo',                'ZDF',  '1209122']]

def listMain():
	addDir({'name':'Neu', 'mode':'_listPage', 'url':'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=%5FSTARTSEITE'})
	addDir({'name':'Meistgesehen', 'mode':'_listPage', 'url':'http://www.zdf.de/ZDFmediathek/xmlservice/web/meistGesehen?maxLength=50&id=%5FGLOBAL'})
	addDir({'name':'Sendungen A-Z', 'mode':'listLetters'})
	addDir({'name':'Sendung nach Datum', 'mode':'listDate'})
	addDir({'name':'Rubriken', 'mode':'_listPage', 'url':'http://www.zdf.de/ZDFmediathek/xmlservice/web/rubriken'})
	addDir({'name':'Themen', 'mode':'_listPage', 'url':'http://www.zdf.de/ZDFmediathek/xmlservice/web/themen'})
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def listLetters():
	dict = {}
	dict['name'] = "0-9"
	dict['url'] = 'http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd=0%2D9&detailLevel=2&characterRangeStart=0%2D9'
	dict['mode'] = '_listPage'
	addDir(dict)
	
	letters = [chr(i) for i in xrange(ord('a'), ord('z')+1)]
	for letter in letters:
		letter = letter.upper()
		dict['name'] = letter
		dict['url'] = 'http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd='+letter+'&detailLevel=2&characterRangeStart='+letter
		addDir(dict)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
def listDate():
	dict = {}
	dict['mode'] = 'listDateChannels'
	dict['name'] = 'Heute'#translation(31020)
	dict['datum']  = '0'
	addDir(dict)
	dict['name'] = 'Gestern'#translation(31021)
	dict['datum']  = '1'
	addDir(dict)
	i = 2
	while i <= 6:
		day = date.today() - timedelta(i)
		dict['name'] = weekdayDict[day.strftime("%w")]
		dict['datum']  = str(i)
		addDir(dict)
		i += 1
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
def listDateChannels():
	datum = params['datum']
	dict = {}
	day = date.today() - timedelta(int(datum))
	ddmmyy = day.strftime('%d%m%y')
	for channel,source,id in cannelList:
		if source == 'ZDF':
			dict['mode'] = '_listPage'
			dict['name'] = channel
			dict['url']  = 'http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungVerpasst?startdate='+ddmmyy+'&channelFilter='+id+'&enddate='+ddmmyy+'&maxLength=50'
			addDir(dict)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def _listPage():
	url = params['url']
	if params.has_key('page'):
		page = int(params['page']) + 1
		items,nextPage = getXML(url,page)
	else:
		page = 1
		items,nextPage = getXML(url)
	#print items
	for dict in items:
		if dict['type'] == 'sendung' or dict['type'] == 'rubrik' or dict['type'] == 'thema':
			dict['mode'] = '_listPage'
			addDir(dict)
		elif dict['type'] == 'video':
			dict['mode'] = 'play'
			addLink(dict)
	if nextPage:
		#addDir({'name':translation(31040),'url':url,'page':page,'fanart':fanart,'mode':3})
		addDir({'name':'Naechste Seite','url':url,'page':page,'fanart':fanart,'mode':'_listPage'})
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def play():
	url,sub = getVideoUrl(params['url'],showSubtitles)
	listitem = xbmcgui.ListItem(path=url)
	if showSubtitles and helix and sub:
		listitem.setSubtitles(sub)
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	if showSubtitles and not helix and sub:
		xbmc.sleep(2000)
		xbmc.Player().setSubtitles(sub)
	
	
def addLink(dict):
	name = dict['name']
	url  = dict['url']
	mode  = dict['mode']
	iconimage = dict['thumb']
	if dict.has_key('plot'):
		plot = dict['plot']
	else:
		plot = ''
	if dict.has_key('duration'):
		duration = dict['duration']
	else:
		duration = ''
	if dict.has_key('fanart'):
		fanart = dict['fanart']
	else:
		fanart = ''
	if hideAudioDisa:
		if 'Hörfassung' in name or 'Audiodeskription' in name:
			return False
	#name = urllib.unquote(name).decode('utf-8')
	name = name.replace('&amp;','&')
	"""
	name = html_parser.unescape(fix_name(name))
	plot = html_parser.unescape(fix_name(plot))
	if xbmcplugin.getSetting(pluginhandle,"description") == 'true' and not plot == '':
		name = name + ' - ' + plot
	"""
	#u=sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf-8'))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name.encode('utf-8'))
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": plot , "Plotoutline": plot , "Duration": duration } )
	#liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": plot , "Plotoutline": plot} )
	liz.setProperty('IsPlayable', 'true')
	if fanart:
		liz.setProperty('fanart_image',fanart)
	else:
		liz.setProperty('fanart_image',iconimage)
	#xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="movies" )
	xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="episodes" )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
	return ok

def addDir(dict):
	#dict = addMissingEntriesDict(dict)
	#name = urllib.unquote(name).decode('utf-8')
	u = sys.argv[0]+'?'
	i = 0
	for key in dict.keys():
		if i > 0:
			u += '&'
		#u += key + '=' + urllib.quote_plus(str(dict[key]).encode('utf-8'))
		u += key + '=' + urllib.quote_plus(str(dict[key]))
		i += 1
	
	ok=True
	liz=xbmcgui.ListItem(dict.get('name',''), iconImage="DefaultFolder.png", thumbnailImage=dict.get('thumb',''))
	liz.setInfo( type="Video", infoLabels={ "Title": dict.get('name','') , "Plot": dict.get('plot','') , "Plotoutline": dict.get('plot','') } )
	liz.setProperty('fanart_image',dict.get('thumb',''))
	#xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="movies" )
	xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="episodes" )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	
params = {}
def list():	
	global params
	params = get_params()
	print params
	for key,val in params.items():
		print key
		print val
		print urllib.unquote_plus(val)
		try:
			params[key] = urllib.unquote_plus(val)
		except: 
			print 'Cant unquote this: '+ str(val)

	if not params.has_key('mode'):
		listMain()
	elif params['mode']=='listDate':
		listDate()
	elif params['mode']=='listDateChannels':
		listDateChannels()
	elif params['mode']=='listLetters':
		listLetters()
	elif params['mode']=='_listPage':
		_listPage()
	elif params['mode']=='play':
		play()
	else:
		listMain()
		

def get_params():
	param={}
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
								
	return param