# -*- coding: utf-8 -*-
import zdf_listing
import zdf_play
import libZdfSubtitle

def getNew(entries=50):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=%5FSTARTSEITE')[:entries]
def getMostViewed(entries=50):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/meistGesehen?maxLength=50&id=%5FGLOBAL')[:entries]
def getAZ(letter):
	return zdf_listing.getXML('http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungenAbisZ?characterRangeEnd='+letter+'&detailLevel=2&characterRangeStart='+letter)
def getSearch(search_string,page=1):
	return zdf_listing.getXML('https://www.zdf.de/ZDFmediathek/xmlservice/web/detailsSuche?searchString='+search_string+'&maxLength=20')

	
def getXML(url,page=1):
	return zdf_listing.getXML(url,page)
def getVideoUrl(url,useSub=False):
	print 'playing:'+url
	video,subUrl,offset = zdf_play.getVideoUrl(url)
	if useSub and subUrl:
		return video,libZdfSubtitle.getSub(subUrl,offset)
	else:
		return video,False