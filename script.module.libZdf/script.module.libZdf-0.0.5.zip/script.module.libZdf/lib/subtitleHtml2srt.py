import time
import re

def convert(content,offset = 0):
	srt = ''
	content = content.replace('  <','<')
	matchLine = re.compile('<p begin="(.+?)" end="(.+?)"(.+?)>(.+?)</p>', re.DOTALL).findall(content)
	i = 1
	for begin, end, info, line in matchLine:
		srt += str(i)+'\n'
		srt += _s2time(begin) + ' --> ' + _s2time(end) + '\n'
		line = line.replace('<span tts:color="','<font color="')
		line = line.replace('">','>')
		line = line.replace('</span>','</font>')
		if 'tts:color' in info:
			color = re.compile('tts:color="(.+?)"', re.DOTALL).findall(info)[0]
			srt += '<font color="'+color+'>'+line+'</font>'
		else:
			srt += line
		srt += '\n\n'
		i += 1
	return srt.replace('<br />','\n')#.encode('utf-8')  
		


def _s2time(s):
	ms = s[-1] + '00'
	return time.strftime('%H:%M:%S', time.gmtime(int(s[:-2])))+','+ms
