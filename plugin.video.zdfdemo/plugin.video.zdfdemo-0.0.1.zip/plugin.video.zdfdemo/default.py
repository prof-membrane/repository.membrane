# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import xbmc
import xbmcaddon
import xbmcplugin
import resources.lib.jsonparser as jsonParser

translation = xbmcaddon.Addon().getLocalizedString

def main():
	return jsonParser.main()
		
def play():
	d = {}
	d['media'] = []
	d['media'].append({'url':params['url'], 'type': 'video', 'stream':'HLS'})
	return d


modes = {
'main': main,
'play': play
}	

def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
list()