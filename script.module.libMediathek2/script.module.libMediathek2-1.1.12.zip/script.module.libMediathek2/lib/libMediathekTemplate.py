import urllib
import urllib2
import socket
import xbmc
import xbmcaddon
import xbmcvfs
import re
