# -*- coding: utf-8 -*-
import libMediathek
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import json
import re
import _utils#todo: move to lib


def main():#TODO translation
	url = 'https://www.nhl.com/video/'
	response = _utils.getUrl(url)
	jsonraw = re.compile('dataBootstrap.+?= (.+?);\n', re.DOTALL).findall(response)[0]
	j = json.loads(jsonraw)
	l = []
	#xbmc.log('####################')
	#xbmc.log(str(j))
	for topic in j['navData']['mainMenu']['topics']:
		#xbmc.log(str(topic))
		if topic['type'] == 'topic':
			d = {}
			d['name'] = topic['title']
			d['url'] = 'https://search-api.svc.nhl.com/svc/search/v2/nhl_global_en/topic/' + topic['id'] + '?page=1&sort=new&type=video&hl=false&expand=image.cuts.640x360%2Cimage.cuts.1136x640'
			d['type'] = 'dir'
			d['mode'] = 'listVideos'
			l.append(d)
		elif topic['type'] == 'topic':
			catName = topic['title']
			for topic2 in topic['topics']:
				d = {}
				d['name'] = catName + ' - ' + topic2['title']
				d['url'] = 'https://search-api.svc.nhl.com/svc/search/v2/nhl_global_en/topic/' + topic2['id'] + '?page=1&sort=new&type=video&hl=false&expand=image.cuts.640x360%2Cimage.cuts.1136x640'
				d['type'] = 'dir'
				d['mode'] = 'listVideos'
				l.append(d)
	libMediathek.addEntries(l)
				
def listVideos():
	response = _utils.getUrl(params['url'])
	j = json.loads(response)
	
	l = []
	for doc in j['docs']:
		xbmc.log(str(doc))
		d = {}
		d['name'] = doc['title']
		d['plot'] = doc['bigBlurb']
		s = doc['duration'].split(':')
		d['duration'] = str(int(s[0]) * 60 + int(s[1]))
		d['thumb'] = doc['image']['cuts']['640x360']['src']
		d['url'] = 'https://nhl.bamcontent.com/nhl/id/v1/' + doc['asset_id'] + '/details/web-v1.json'
		d['type'] = 'video'
		d['mode'] = 'play'
		l.append(d)
	libMediathek.addEntries(l)
	
def play():
	response = _utils.getUrl(params['url'])
	j = json.loads(response)
	for vid in j['playbacks']:
		if vid['name'] == 'HTTP_CLOUD_WIRED_60':
			url = vid['url']
			xbmc.log(url)
			listitem = xbmcgui.ListItem(path=url)
			#if showSubtitles and subUrl:
			#	sub = libMediathek.ttml2Srt(subUrl)
			#	listitem.setSubtitles([sub])
			xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	
	

modes = {
'main': main,
'listVideos': listVideos,
'play': play,
}	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	if not params.has_key('mode'):
		main()
	else:
		modes.get(params['mode'],main)()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
list()