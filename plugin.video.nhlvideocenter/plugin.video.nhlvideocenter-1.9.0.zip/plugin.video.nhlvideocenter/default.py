# -*- coding: utf-8 -*-
import libMediathek2 as libMediathek 
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import json
import re
import _utils#todo: move to lib


def main():#TODO translation
	url = 'https://www.nhl.com/video/'
	response = _utils.getUrl(url)
	jsonraw = re.compile('dataBootstrap.+?= (.+?);\n', re.DOTALL).findall(response)[0]
	j = json.loads(jsonraw)
	l = []
	#xbmc.log('####################')
	#xbmc.log(str(j))
	for topic in j['navData']['mainMenu']['topics']:
		#xbmc.log(str(topic))
		if topic['type'] == 'topic':
			d = {}
			d['_name'] = topic['title']
			d['url'] = 'https://search-api.svc.nhl.com/svc/search/v2/nhl_global_en/topic/' + topic['id'] + '?page=1&sort=new&type=video&hl=false&expand=image.cuts.640x360%2Cimage.cuts.1136x640'
			d['_type'] = 'dir'
			d['mode'] = 'listVideos'
			l.append(d)
		elif topic['type'] == 'category':
			catName = topic['title']
			for topic2 in topic['topics']:
				d = {}
				#d['name'] = catName + ' - ' + topic2['title']
				d['_name'] = catName + ' - ' + topic2['title']
				d['url'] = 'https://search-api.svc.nhl.com/svc/search/v2/nhl_global_en/topic/' + topic2['id'] + '?page=1&sort=new&type=video&hl=false&expand=image.cuts.640x360%2Cimage.cuts.1136x640'
				d['_type'] = 'dir'
				d['mode'] = 'listVideos'
				l.append(d)
	libMediathek.addEntries(l)
				
def listVideos():
	response = _utils.getUrl(params['url'])
	j = json.loads(response)
	
	l = []
	for doc in j['docs']:
		xbmc.log(str(doc))
		d = {}
		#d['_name'] = doc['title']
		d['_name'] = doc['blurb']
		d['_plot'] = doc['bigBlurb']
		s = doc['duration'].split(':')
		d['_duration'] = str(int(s[0]) * 60 + int(s[1]))
		d['_thumb'] = doc['image']['cuts']['640x360']['src']
		d['url'] = 'https://nhl.bamcontent.com/nhl/id/v1/' + doc['asset_id'] + '/details/web-v1.json'
		d['_type'] = 'video'
		d['mode'] = 'play'
		l.append(d)

	#libMediathek.addEntries(l)
		
	#l2 = []
	page = int(params['url'].split('page=')[-1].split('&')[0])
	if page * j['meta']['page_size'] < j['meta']['hits']:
		d = {}
		d['url'] = params['url'].replace('page='+str(page),'page='+str(page+1))
		d['type'] = 'nextPage'
		d['mode'] = 'listVideos'
		l.append(d)
		#l2.append(d)
		
	libMediathek.addEntries(l)
	#libMediathek.addEntries(l2)
	
def play():
	response = _utils.getUrl(params['url'])
	j = json.loads(response)
	for vid in j['playbacks']:
		if vid['name'] == 'HTTP_CLOUD_WIRED_60':
			url = vid['url']
			xbmc.log(url)
			listitem = xbmcgui.ListItem(path=url)
			#if showSubtitles and subUrl:
			#	sub = libMediathek.ttml2Srt(subUrl)
			#	listitem.setSubtitles([sub])
			xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	
	

modes = {
'main': main,
'listVideos': listVideos,
'play': play,
}	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	if not params.has_key('mode'):
		main()
		xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	else:
		modes.get(params['mode'],main)()
		#if params['mode'] == 'listVideosStub':
		#	xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=False)	
		#else:
		xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	#xbmcplugin.endOfDirectory(int(sys.argv[1]),updateListing=True)	
	#xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
list()