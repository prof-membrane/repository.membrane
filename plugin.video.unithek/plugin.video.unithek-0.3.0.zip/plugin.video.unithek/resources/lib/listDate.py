import urllib
import urllib2
import re
import random
import xbmcplugin
import xbmcgui
import xbmcaddon
import cookielib
import HTMLParser
import datetime
import xbmc
import xbmcaddon
import xbmcvfs
import time
import string
import sys
import hashlib

import libMediathek2 as libMediathek

translation = xbmcaddon.Addon(id='script.module.libMediathek').getLocalizedString

def listDateMain():
	libMediathek.populateDirDate('listDateChannels')
	return []
	
def listDateChannels():
	d = params['datum']
	l = []
	l.append({'_name':'ARD-Alpha', 'mode':'libBrListDateVideos', 'datum': d})
	l.append({'_name':'BR', 'mode':'libBrListDateVideos', 'datum': d})
	return l