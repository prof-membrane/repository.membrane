﻿# -*- coding: utf-8 -*-


import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib

import threading

import libmediathek3 as libMediathek

import lib3sat
import libard
import libbr
import libdaserste
import libhr
import libmdr
import libndr
import libsr
import libswr
import libwdr
import libzdf

translation = libMediathek.getTranslation

log = libMediathek.log
import time
t = time.time() * 1000

	
def logtime():
	xbmc.log(str(time.time() * 1000 - t))

def listMain():
	l = []
	l.append({'_name':translation(31031), 'mode':'listMV'})
	l.append({'_name':translation(31032), 'mode':'listAZ'})
	l.append({'_name':translation(31033), 'mode':'listDateChannels'})
	return l
	
def listMV():
	l = []
	log('start ard')
	logtime()
	l += libard.getMostViewed()
	log('startzdf')
	logtime()
	l += libzdf.getMostViewed()[:50]
	log('finished')
	logtime()
	libMediathek.sortAZ()
	return l

def listAZ():
	log('start')
	logtime()
	l = []
	t1 = threading.Thread(target=getA)
	t2 = threading.Thread(target=getZ)
	t1.start()
	t2.start()
	t1.join()
	t2.join()
	l += la
	l += lz
	log('finished')
	logtime()
	libMediathek.sortAZ()
	return l#"""
def getA():
	global la
	la = libard.libArdListShows()
	
def getZ():
	global lz
	lz = libzdf.libZdfListAZ()
	
def listDateChannels():
	l = []
	l.append({'name':'3sat', 'mode':'lib3satListDate'})
	l.append({'name':'ARD-Alpha', 'mode':'libBrListChannelDate', 'channel':'ARD-Alpha'})
	l.append({'name':'BR', 'mode':'libBrListChannelDate', 'channel':'BR'})
	l.append({'name':'Das Erste', 'mode':'libDasErsteListDate'})
	l.append({'name':'HR', 'mode':'libHrListDate'})
	l.append({'name':'MDR', 'mode':'libMdrListDate'})
	#l.append({'name':'MDR', 'mode':'libArdListChannelDate', 'channel':'MDR'})
	l.append({'name':'NDR', 'mode':'libNdrListDate'})
	l.append({'name':'One', 'mode':'libArdListChannelDate','channel':'One'})
	#l.append({'name':'Phoenix', 'mode':'libZdfListChannelDate', 'channel':'phoenix'})
	l.append({'name':'RB', 'mode':'libArdListChannelDate','channel':'RB'})
	l.append({'name':'RBB', 'mode':'libArdListChannelDate','channel':'RBB'})
	l.append({'name':'SR', 'mode':'libSrListDate'})
	l.append({'name':'SWR', 'mode':'libSwrListDate'})
	l.append({'name':'Tagesschau24', 'mode':'libArdListChannelDate','channel':'tagesschau24'})
	l.append({'name':'WDR', 'mode':'libWdrListDate'})
	l.append({'name':'ZDF', 'mode':'libZdfListChannelDate', 'channel':'zdf'})
	l.append({'name':'ZDF Info', 'mode':'libZdfListChannelDate', 'channel':'zdfinfo'})
	l.append({'name':'ZDF Neo', 'mode':'libZdfListChannelDate', 'channel':'zdfneo'})
	
	return l
	
def list():	
	xbmc.log(str(sys.argv))
	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','listMain')
	xbmc.log(mode)
	if mode.startswith('lib3sat'):
		lib3sat.list()
	elif mode.startswith('libArd'):
		libard.list()
	elif mode.startswith('libBr'):
		libbr.list()
	elif mode.startswith('libDasErste'):
		libdaserste.list()
	elif mode.startswith('libHr'):
		libhr.list()
	elif mode.startswith('libMdr'):
		libmdr.list()
	elif mode.startswith('libNdr'):
		libndr.list()
	elif mode.startswith('libSr'):
		libsr.list()
	elif mode.startswith('libSwr'):
		libswr.list()
	elif mode.startswith('libWdr'):
		libwdr.list()
	elif mode.startswith('libZdf'):
		libzdf.list()
	else:
		xbmc.log
		l = modes.get(mode,listMain)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
		
modes = {
	'listDateChannels': listDateChannels,
	'listAZ': listAZ,
	'listMV': listMV,
	}
list()