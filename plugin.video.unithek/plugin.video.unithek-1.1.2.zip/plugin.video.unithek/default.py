﻿# -*- coding: utf-8 -*-


import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib

import threading

import libmediathek3 as libMediathek

import lib3sat
import libard
import libarte
import libbr
import libdaserste
import libhr
import libkika
import libmdr
import libndr
import libsr
import libswr
import libwdr
import libzdf

translation = libMediathek.getTranslation

log = libMediathek.log
import time
t = time.time() * 1000
#staticShows = ['mdr.json']
staticShows = ['3sat.json', 'ard.json', 'arte.json', 'br.json', 'daserste.json', 'kika.json', 'mdr.json', 'ndr.json', 'sr.json', 'swr.json', 'wdr.json', 'zdf.json']
	
def logtime():
	xbmc.log(str(time.time() * 1000 - t))

def listMain():
	l = []
	l.append({'_name':translation(31031), 'mode':'listMV', 				'_type':'dir'})
	l.append({'_name':translation(31032), 'mode':'listAZ', 				'_type':'dir'})
	l.append({'_name':translation(31033), 'mode':'listDateChannels', 	'_type':'dir'})
	l.append({'_name':'Detailsuche',	  'mode':'listSearchable', 		'_type':'dir'})#TODO Move to .po
	return l
	
def listMV():
	l = []
	l += libard.getMostViewed()
	l += libzdf.getMostViewed()[:50]
	libMediathek.sortAZ()
	return l

def listAZ():
	l = []
	"""
	t1 = threading.Thread(target=getA)
	t2 = threading.Thread(target=getZ)
	t1.start()
	t2.start()
	t1.join()
	t2.join()
	l += la
	l += lz
	"""
	import json
	for f in staticShows:
		j = json.loads(libMediathek.f_open(libMediathek.pathAddon('/shows/'+f)))
		l += j['list']
		
	libMediathek.sortAZ()
	
	return l
	
def getA():
	global la
	la = libard.libArdListShows()
	
def getZ():
	global lz
	lz = libzdf.libZdfListShows()
	
def listDateChannels():
	l = []
	l.append({'name':'3sat',			'mode':'lib3satListDate', 		'_type':'dir'})
	l.append({'name':'ARD-Alpha',		'mode':'libBrListChannelDate', 	'_type':'dir', 'channel':'ARD-Alpha', })
	l.append({'name':'Arte', 			'mode':'libArteListDate', 		'_type':'dir'})
	l.append({'name':'BR',				'mode':'libBrListChannelDate', 	'_type':'dir', 'channel':'BR'})
	l.append({'name':'Das Erste', 		'mode':'libDasErsteListDate', 	'_type':'dir'})
	l.append({'name':'HR', 				'mode':'libHrListDate', 		'_type':'dir'})
	l.append({'name':'KiKa', 			'mode':'libKikaListDate', 		'_type':'dir'})
	l.append({'name':'MDR', 			'mode':'libMdrListDate', 		'_type':'dir'})
	l.append({'name':'MDR+', 			'mode':'libMdrListPlus', 		'_type':'dir', 'url':'http://www.mdr.de/mediathek/livestreams/mdr-plus/mediathek-mdrplus-100-meta.xml'})
	#l.append({'name':'MDR', 			'mode':'libArdListChannelDate', '_type':'dir', 'channel':'MDR'})
	l.append({'name':'NDR', 			'mode':'libNdrListDate', 		'_type':'dir'})
	l.append({'name':'One', 			'mode':'libArdListChannelDate',	'_type':'dir', 'channel':'One'})
	#l.append({'name':'Phoenix',	 	'mode':'libZdfListChannelDate', '_type':'dir', 'channel':'phoenix'})
	l.append({'name':'RB', 				'mode':'libArdListChannelDate',	'_type':'dir', 'channel':'RB'})
	l.append({'name':'RBB', 			'mode':'libArdListChannelDate',	'_type':'dir', 'channel':'RBB'})
	l.append({'name':'SR', 				'mode':'libSrListDate', 		'_type':'dir'})
	l.append({'name':'SWR', 			'mode':'libSwrListDate', 		'_type':'dir'})
	l.append({'name':'Tagesschau24', 	'mode':'libArdListChannelDate',	'_type':'dir', 'channel':'tagesschau24'})
	l.append({'name':'WDR', 			'mode':'libWdrListDate', 		'_type':'dir'})
	l.append({'name':'ZDF', 			'mode':'libZdfListChannelDate', '_type':'dir', 'channel':'zdf'})
	l.append({'name':'ZDF Info', 		'mode':'libZdfListChannelDate', '_type':'dir', 'channel':'zdfinfo'})
	l.append({'name':'ZDF Neo', 		'mode':'libZdfListChannelDate', '_type':'dir', 'channel':'zdfneo'})
	return l
def listSearchable():
	libMediathek.searchWorkaroundRemove()
	l = []
	l.append({'name':'3sat Mediathek',		'mode':'lib3satSearch', 		'_type':'dir'})
	#l.append({'name':'ARD Mediathek', 		'mode':'libArdSearch',	 		'_type':'dir'})
	#l.append({'name':'Arte Mediathek', 		'mode':'libArteSearch', 		'_type':'dir'})
	l.append({'name':'BR Mediathek',		'mode':'libBrSearch', 			'_type':'dir'})
	#l.append({'name':'Das Erste Mediathek', 'mode':'libDasErsteSearch', 	'_type':'dir'})
	#l.append({'name':'HR Mediathek', 		'mode':'libHrSearch',	 		'_type':'dir'})
	l.append({'name':'KiKa Mediathek', 		'mode':'libKikaSearch', 		'_type':'dir'})
	#l.append({'name':'MDR Mediathek', 		'mode':'libMdrSearch',	 		'_type':'dir'})
	#l.append({'name':'NDR Mediathek', 		'mode':'libNdrSearch', 			'_type':'dir'})
	#l.append({'name':'SR Mediathek', 		'mode':'libSrSearch',	 		'_type':'dir'})
	l.append({'name':'SWR Mediathek', 		'mode':'libSwrSearch', 			'_type':'dir'})
	l.append({'name':'WDR Mediathek', 		'mode':'libWdrSearch',	 		'_type':'dir'})
	l.append({'name':'ZDF Mediathek', 		'mode':'libZdfSearch',			'_type':'dir'})
	return l
	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','listMain')
	xbmc.log(mode)
	if mode.startswith('lib3sat') or mode.startswith('xml'):
		lib3sat.list()
	elif mode.startswith('libArd'):
		libard.list()
	elif mode.startswith('libArte'):
		libarte.list()
	elif mode.startswith('libBr'):
		libbr.list()
	elif mode.startswith('libDasErste'):
		libdaserste.list()
	elif mode.startswith('libHr'):
		libhr.list()
	elif mode.startswith('libKika'):
		libkika.list()
	elif mode.startswith('libMdr'):
		libmdr.list()
	elif mode.startswith('libNdr'):
		libndr.list()
	elif mode.startswith('libSr'):
		libsr.list()
	elif mode.startswith('libSwr'):
		libswr.list()
	elif mode.startswith('libWdr'):
		libwdr.list()
	elif mode.startswith('libZdf'):
		libzdf.list()
	else:
		l = modes.get(mode,listMain)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
		
modes = {
	'listMV': listMV,
	'listAZ': listAZ,
	'listDateChannels': listDateChannels,
	'listSearchable': listSearchable,
	}

list()