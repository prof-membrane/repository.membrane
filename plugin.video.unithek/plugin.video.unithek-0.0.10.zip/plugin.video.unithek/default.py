﻿# -*- coding: utf-8 -*-
import urllib,urllib2,re,random,xbmcplugin,xbmcgui,xbmcaddon,cookielib,HTMLParser,datetime
#from time import gmtime, strftime
from time import *
from datetime import date, timedelta
from operator import itemgetter
from multiprocessing import Process, Queue
import time
__settings__ = xbmcaddon.Addon()
__language__ = __settings__.getLocalizedString
addon = xbmcaddon.Addon()
translation = addon.getLocalizedString

if __settings__.getSetting("firstrun") == 'true':
	__settings__.setSetting(id="firstrun",value='false')

import resources.lib.utils as utils
import libArd
import libArte
import libZdf

ardLimit = int(addon.getSetting("ardLimit"))
zdfLimit = int(addon.getSetting("zdfLimit"))
showSubtitles = addon.getSetting("showSubtitles") == "true"
hideAudioDisa = addon.getSetting("hideAudioDisa") == "true"
helix = False

html_parser = HTMLParser.HTMLParser()

month = strftime("%m", gmtime())
year = strftime("%Y", gmtime())
startTime = int(round(time.time() * 1000))
viewMode = '515'
viewModeA = '515'
viewModeB = '515'
baseArd = 'http://ardmediathek.de'
def log(message = False):
	print 'Unithek Log: '+message
def logTime():
	print 'Unithek Log: Runtime '+str(int(round(time.time() * 1000)) - startTime)+'ms'

log('Starting')		

COOKIEFILE = xbmc.translatePath(__settings__.getAddonInfo('profile')+"cookies.lwp")
cannelList = [['3sat',                  'ZDF',  '1209116'],
			  ['ARD-alpha',             'ARD',  '5868'   ],
			  ['Arte',                  'Arte', ''       ],
			  ['BR',                    'ARD',  '2224'   ],
			  #['Einsfestival',          'ARD',  '673348' ],
			  ['EinsPlus',              'ARD',  '4178842'],
			  ['Das Erste',             'ARD',  '208'    ],
			  ['HR',                    'ARD',  '5884'   ],
			  ['MDR Fernsehen',         'ARD',  '5882'   ],
			  ['MDR Thüringen',         'ARD',  '1386988'],
			  ['MDR Sachsen',           'ARD',  '1386804'],
			  ['NDR Fernsehen',         'ARD',  '5906'   ],
			  ['Phoenix',               'ZDF',  '2256088'],
			  ['RB',                    'ARD',  '5898'   ],
			  ['RBB',                   'ARD',  '5874'   ],
			  ['SR',                    'ARD',  '5870'   ],
			  ['SWR Fernsehen',         'ARD',  '5310'   ],
			  ['SWR Rheinland-Pfalz',   'ARD',  '5872'   ],
			  ['SWR Baden-Württemberg', 'ARD',  '5904'   ],
			  ['tagesschau24',          'ARD',  '5878'   ],
			  ['WDR',                   'ARD',  '5902'   ],
			  ['ZDF',                   'ZDF',  '1209114'],
			  ['ZDFinfo',               'ZDF',  '1209120'],
			  ['ZDF.kultur',            'ZDF',  '1317640'],
			  ['ZDFneo',                'ZDF',  '1209122']]


weekdayDict = { '0': 'Sonntag',
				'1': 'Montag',
				'2': 'Dienstag',
				'3': 'Mittwoch',
				'4': 'Donnerstag',
				'5': 'Freitag',
				'6': 'Samstag'}
pluginhandle = int(sys.argv[1])

arteDict = { 'Dokumentationen': 'http://www.arte.tv/guide/de/plus7/par_themes?value=DOC',
             'Kino':            'http://www.arte.tv/guide/de/plus7/par_themes?value=CIN',
             'Kultur':          'http://www.arte.tv/guide/de/plus7/par_themes?value=ART',
             'Sport':           False,
             'Technik':         False,
             'Wissen':          'http://www.arte.tv/guide/de/plus7/par_themes?value=ENV'}
zdfDict = {  'Dokumentationen': 'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=546',
             'Kino':            'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=548',
             'Kultur':          'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=554',
             'Sport':           'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=610',
             'Technik':         'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=558',
             'Wissen':          'http://www.zdf.de/ZDFmediathek/xmlservice/web/aktuellste?maxLength=50&id=570'}
ardDict = {  'Dokumentationen': '/tv/Reportage-Doku/mehr?documentId=21301806',
             'Kino':            '/tv/Film-Highlights/mehr?documentId=21301808',
             'Kultur':          '/tv/Kultur/mehr?documentId=21282546',
             'Sport':           '/tv/Sport-in-der-Mediathek/mehr?documentId=26439062',
             'Technik':         '/einslike/Netz-Tech/mehr?documentId=21301898',
             'Wissen':          '/tv/Wissen/mehr?documentId=21282530'}
def MAIN():
	addDir({'name':'Neu',                'mode':100})
	addDir({'name':'Meistgesehen',       'mode':101})
	addDir({'name':'Sendungen A-Z',      'mode':1  })
	addDir({'name':'Sendung nach Datum', 'mode':110})
	#addDir('Themen','Themen',10,'')
	#addDir('Suche','Suche',300,'')
	
	xbmcplugin.endOfDirectory(pluginhandle)
	
def LISTNEW():#100
	list = []
	logTime()
	items  = libArd.getNew()
	for dict in items:
		dict['mode'] = 201
		list.append(dict)
	logTime()
	items = libZdf.getNew()
	for dict in items:
		dict['mode'] = 4
		list.append(dict)
	logTime()
	
	for dict in list:
		addLink(dict)
	logTime()
	xbmcplugin.addSortMethod(pluginhandle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE )
		
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def LISTMV():#101
	logTime()
	list = []
	items  = libArd.getMostViewed()
	for dict in items:
		dict['mode'] = 201
		list.append(dict)
	logTime()
	items = libZdf.getMostViewed()
	for dict in items:
		dict['mode'] = 4
		list.append(dict)
	logTime()
	for dict in list:
		addLink(dict)
	xbmcplugin.addSortMethod(pluginhandle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE )
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def listShowsAZMain():#1
	dict = {}
	dict['name'] = "0-9"
	dict['url'] = "#"
	dict['mode'] = 2
	addDir(dict)
	
	letters = [chr(i) for i in xrange(ord('a'), ord('z')+1)]
	for letter in letters:
		dict['name'] = letter.upper()
		dict['url'] = letter.upper()
		addDir(dict)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def listShows(letter):#2
	list = []
	logTime()
	items = libArd.getAZ(letter)
	for dict in items:
		dict['mode'] = 200
		dict['sortName'] = convSortName(dict['name'],letter.replace('#','0'))
		list.append(dict)
	
	#logTime()
	#items = libArte.getAZ(letter.replace('#','0'))
	#for name,url,thumb,plot in items:
	#	list.append([name,url,thumb,3,convSortName(name,letter.replace('#','0')),'Arte'])
	logTime()
	items = libZdf.getAZ(letter.replace('#','0%2D9'))
	for dict in items:
		dict['mode'] = 3
		dict['sortName'] = convSortName(dict['name'],letter.replace('#','0'))
		list.append(dict)
	
	logTime()
	sortedList = sorted(list, key=itemgetter('sortName'))
	
	for dict in sortedList:#adds ' - $channel' to name if there are multiple channels
		dict['showname'] = dict['name']
		i=0
		j=0
		while i < len(sortedList):
			if dict['name'] == sortedList[i]['name']:
				j += 1
			i += 1
		if j > 1:
			dict['name'] += ' - '+dict['channel']
		addDir(dict)
		
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	#xbmcplugin.addDirectoryItems(int(sys.argv[1]), items)
	#xbmcplugin.addSortMethod(pluginhandle, sortMethod=xbmcplugin.SORT_METHOD_TITLE_IGNORE_THE )
	##xbmcplugin.addSortMethod(pluginhandle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE )
	#xbmcplugin.endOfDirectory(pluginhandle)
	
def listDates():#110
	dict = {}
	dict['mode'] = 111
	dict['name'] = 'Heute'
	dict['url']  = '0'
	addDir(dict)
	dict['name'] = 'Gestern'
	dict['url']  = '1'
	addDir(dict)
	i = 2
	while i <= 6:
		day = date.today() - timedelta(i)
		dict['name'] = weekdayDict[day.strftime("%w")]
		dict['url']  = str(i)
		addDir(dict)
		i += 1
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def listChannels(datum):#111
	dict = {}
	day = date.today() - timedelta(int(datum))
	ddmmyy = day.strftime('%d%m%y')
	for channel,source,id in cannelList:
		if source == 'ARD':
			dict['mode'] = 202
			dict['name'] = channel
			dict['url']  = 'http://www.ardmediathek.de/tv/sendungVerpasst?tag='+datum+'&kanal='+id
			addDir(dict)
		elif source == 'ZDF':
			dict['mode'] = 5
			dict['name'] = channel
			dict['url']  = 'http://www.zdf.de/ZDFmediathek/xmlservice/web/sendungVerpasst?startdate='+ddmmyy+'&channelFilter='+id+'&enddate='+ddmmyy+'&maxLength=50'
			addDir(dict)
		elif source == 'ARTE':
			print 'todo'
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def listZDF(url,fanart):#3
	if params.has_key('page'):
		page = int(params['page']) + 1
		items,nextPage = libZdf.getXML(url,page)
	else:
		page = 1
		items,nextPage = libZdf.getXML(url)
		
	for dict in items:
		dict['mode'] = 4
		dict['fanart'] = fanart
		addLink(dict)
	if nextPage:
		addDir({'name':'Nächste Seite','url':url,'page':page,'fanart':fanart,'mode':3})
	xbmcplugin.endOfDirectory(pluginhandle)
	
def listDateZDF(url):#5
	items = libZdf.getXML(url)
	for dict in items:
		dict['mode'] = 4
		dict['name'] = dict['airtime'].split(' ')[1]+' '+dict['name']
		addLink(dict)
	xbmcplugin.endOfDirectory(pluginhandle)

def playZDF(url,name):#4
	url,sub = libZdf.getVideoUrl(url,showSubtitles)
	listitem = xbmcgui.ListItem(path=url)
	if showSubtitles and helix and sub:
		listitem.setSubtitles(sub)
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	if showSubtitles and not helix and sub:
		xbmc.sleep(2000)
		xbmc.Player().setSubtitles(sub)
	
def listARD(url,fanart,showname):#200
	print 'listARD'
	if params.has_key('page'):
		page = int(params['page']) + 1
		items,nextPage = libArd.getPage(url,page)
	else:
		page = 1
		items,nextPage = libArd.getPage(url)
	
	for dict in items:
		name = dict['name']
		if name.startswith(showname):
			i = len(showname)
			i+=3 # ' - '
			dict['name'] = name[i:]
		dict['fanart'] = fanart
		dict['mode'] = 201
		addLink(dict)
	if nextPage:
		addDir({'name':'Nächste Seite','url':url,'page':page,'fanart':fanart,'showname':showname,'mode':200})
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	xbmc.executebuiltin('Container.SetViewMode('+viewMode+')')
	
def playARD(url,name):#201
	url,sub = libArd.getVideoUrl(url,showSubtitles)
	listitem = xbmcgui.ListItem(path=url)
	if showSubtitles and helix and sub:
		listitem.setSubtitles(sub)
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	if showSubtitles and not helix and sub:
		xbmc.sleep(2000)
		print xbmc.Player().setSubtitles(sub)
		
def listDateARD(url):#202
	items = libArd.getDate(url)
	for dict in items:
		dict['mode'] = 201
		addLink(dict)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
def listThemen():#10
	addDir('Dokumentationen','Dokumentationen',11,'')
	addDir('Kino','Kino',11,'')
	addDir('Kultur','Kultur',11,'')
	addDir('Sport','Sport',11,'')
	addDir('Technik','Technik',11,'')
	addDir('Wissen','Wissen',11,'')
	
def listThema(thema):#11
	if arteDict[thema]:
		listArte(arteDict[thema])
	if zdfDict[thema]:
		listZDF(zdfDict[thema])
	if ardDict[thema]:
		listARD(baseArd+ardDict[thema])

		
def search(url):#300
	keyboard = xbmc.Keyboard('', translation(31000))
	keyboard.doModal()
	if keyboard.isConfirmed() and keyboard.getText():
		search_string = keyboard.getText()
		generalSearch(search_string)
	#addDir('Alle Sender','Suche',301,'')
	#addDir('ARD','Suche',302,'')
	#addDir('Arte','Suche',303,'')
	#addDir('ZDF','Suche',304,'')
def generalSearch(search_string):
	list = []
	items  = libArd.getSearch(urllib.quote_plus(search_string))
	#print items
	for name,url,thumb,plot,duration in items:
		list.append([name,url,thumb,201,plot,duration])
	items = libZdf.getSearch(search_string.replace(' ','+'))
	for name,url,thumb,plot,duration,airtime in items:
		list.append([name,url,thumb,4,plot,duration])
		
	for name,url,thumb,mode,plot,duration in list:
		addLink(name,url,mode,thumb,plot,duration)
	xbmcplugin.addSortMethod(pluginhandle, sortMethod=xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE )
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def convSortName(name,firstletter):
	firstletter = firstletter.lower()
	#hardcoded
	if firstletter != '0':
		name = name.replace('7 Tage','Sieben Tage')
	#umlaute
	name = name.replace('ä','a')
	name = name.replace('ö','o')
	name = name.replace('ü','u')
	name = name.replace('"','')
	name = name.replace('-','')
	name = name.replace("'",'')
	#artikel entfernen:
	if name.startswith('Der ') or name.startswith('der ') or name.startswith('Die ') or name.startswith('die ') or name.startswith('Das ') or name.startswith('das '):
		name = name[4:]
	if name.startswith('zdf') or name.startswith('ZDF') or name.startswith('Zdf'):
		name = name[3:]
	while name.startswith(' '):
		name = name[1:]
	name = name.lower()
	#find first ' s':
	if not name.startswith(firstletter):
		if ' '+firstletter in name:
			width = len(name.split(' '+firstletter)[0]) + 1
			name = name[width:]
		elif firstletter in name:
			width = len(name.split(firstletter)[0])
			name = name[width:]
	return name
	
def getUrl( url , extraheader=True):
	log(url)
	cj = cookielib.LWPCookieJar()
	if os.path.isfile(COOKIEFILE):
		cj.load(COOKIEFILE, ignore_discard=True)

	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	opener.addheaders = [('User-Agent', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2;)')]
	usock=opener.open(url)
	response=usock.read()
	usock.close()
	cj.save(COOKIEFILE, ignore_discard=True)
	return response
	



def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
								
	return param



def addEntry(dict):
	if dict.has_key('type')and dict['type'] == 'video':
		addLink(dict)
	else:
		addDir(dict)

def addLink(dict):
	name = dict['name']
	url  = dict['url']
	mode  = dict['mode']
	iconimage = dict['thumb']
	if dict.has_key('plot'):
		plot = dict['plot']
	else:
		plot = ''
	if dict.has_key('duration'):
		duration = dict['duration']
	else:
		duration = ''
	if dict.has_key('fanart'):
		fanart = dict['fanart']
	else:
		fanart = ''
	
	if hideAudioDisa:
		if 'Hörfassung' in name or 'Audiodeskription' in name:
			return False
	#name = urllib.unquote(name).decode('utf-8')
	name = name.replace('&amp;','&')
	"""
	name = html_parser.unescape(fix_name(name))
	plot = html_parser.unescape(fix_name(plot))
	if xbmcplugin.getSetting(pluginhandle,"description") == 'true' and not plot == '':
		name = name + ' - ' + plot
	"""
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": plot , "Plotoutline": plot , "Duration": duration } )
	#liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": plot , "Plotoutline": plot} )
	liz.setProperty('IsPlayable', 'true')
	if fanart:
		liz.setProperty('fanart_image',fanart)
	else:
		liz.setProperty('fanart_image',iconimage)
	#xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="movies" )
	xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="episodes" )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
	return ok

def addDir(dict):
	#dict = addMissingEntriesDict(dict)
	#name = urllib.unquote(name).decode('utf-8')
	u = sys.argv[0]+'?'
	i = 0
	for key in dict.keys():
		if i > 0:
			u += '&'
		u += key + '=' + urllib.quote_plus(str(dict[key]))
		i += 1
	
	ok=True
	liz=xbmcgui.ListItem(dict.get('name',''), iconImage="DefaultFolder.png", thumbnailImage=dict.get('thumb',''))
	liz.setInfo( type="Video", infoLabels={ "Title": dict.get('name','') , "Plot": dict.get('plot','') , "Plotoutline": dict.get('plot','') } )
	liz.setProperty('fanart_image',dict.get('thumb',''))
	#xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="movies" )
	xbmcplugin.setContent( handle=int( sys.argv[ 1 ] ), content="episodes" )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addMissingEntriesDict(d):
	if not d.has_key('plot'):
		d['plot'] = ''
	if not d.has_key('thumb'):
		d['thumb'] = ''
	return d
			  
params=get_params()
url=None
name=None
thumb=None
fanart=None
showname=None
mode=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		thumb=urllib.unquote_plus(params["thumb"])
except:
		pass
try:
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:
		showname=urllib.unquote_plus(params["showname"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

#if mode==None or url==None or len(url)<1:
if mode==None:
		print ""
		MAIN()

elif mode==1:
		listShowsAZMain()
		
elif mode==2:
		print ""+url
		listShows(url)
		
elif mode==3:
		print ""+url
		listZDF(url,fanart)		
		
elif mode==4:
		print ""+url
		playZDF(url,name)
		
elif mode==5:
		print ""+url
		listDateZDF(url)

elif mode==10:
		print ""+url
		MENUTYPE_1_START(url)
		
elif mode==11:
		print ""+url
		MENUTYPE_1(url)
		
elif mode==12:
		print ""+url
		PLAY_1(url,name,thumb)
		
#elif mode==100:
elif mode==100:
	LISTNEW()

elif mode==101:
	LISTMV()

elif mode==110:
	listDates()

elif mode==111:
	print ""+url
	listChannels(url)

elif mode==200:
	print ""+url
	listARD(url,fanart,showname)

elif mode==201:
	print ""+url
	playARD(url,name)

elif mode==202:
	print ""+url
	listDateARD(url)

elif mode==300:
	print ""+url
	search(url)
	



"""
elif mode==6:
		print ""+url
		VIDEOS(url,name,fanart)

elif mode==7:
		print ""+url
		PLAY(url,name)
		
elif mode==9:
		print ""+url
		SEARCH(url)
"""

#xbmcplugin.endOfDirectory(int(sys.argv[1]))
