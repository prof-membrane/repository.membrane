#!/usr/bin/python
# -*- coding: utf-8 -*-

def addFav(data):
def removeFav(data):
def checkFavExist(data):
