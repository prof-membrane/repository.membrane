# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import xbmc
import xbmcaddon
import xbmcplugin
import resources.lib.jsonparser as jsonParser

translation = xbmcaddon.Addon().getLocalizedString

def main():
	l = [
	{'_name':'Die Bergretter','_type':'dir','mode':'parseVideos','url':'http://hbbtv.zdf.de/zdfstart/idesigner/index.php?id=Bergretter%204K%20%28Backup%29'},
	{'_name':'Der Bergdoktor','_type':'dir','mode':'parseVideos','url':'http://hbbtv.zdf.de/zdfstart/idesigner/index.php?id=Bergdoktor%204K'},
	]
	return l
	
def parseVideos():
	return jsonParser.main(params['url'])
		
def play():
	d = {}
	d['media'] = []
	d['media'].append({'url':params['url'], 'type': 'video', 'stream':'MP4'})
	return d


modes = {
'main': main,
'parseVideos': parseVideos,
'play': play
}	

def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
list()