# -*- coding: utf-8 -*-
import json
import re
import libmediathek3 as libMediathek

def main(url):
	response = libMediathek.getUrl(url)
	libMediathek.log(response)
	js = re.compile('initApp\("start", (.+?)\);').findall(response.replace('\n',''))[0]
	j = json.loads(js)
	l = []
	for page in j['pages']:
		if page['idnam'] == 'start':
			for child in page['props']['children']:
				if child['idnam'] == 'Cluster':
					for data in child['props']['children'][0]['props']['clusterData']:
						d = {}
						
						d['url'] = data['id']
						d['_name'] = data['headtxt'] + ' - ' + data['titletxt']
						d['_plot'] = data['foottxt']
						d['_thumb'] = data['img'].replace('intimg:','http://hbbtv.zdf.de/zdfstart/idesigner/img/')#http://hbbtv.zdf.de/zdfstart/idesigner/img/2c63589c3d51aba35beacfbb6804eb5532ff2764.jpg
						d['mode'] = 'play'
						d['_type'] = 'video'
						l.append(d)
	return l
