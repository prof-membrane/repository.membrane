# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import json
import re

def main():
	response = libMediathek.getUrl('http://hbbtv.zdf.de/zdfstart/idesigner/index.php?id=Bergdoktor%204K')
	js = re.compile('initApp\("start", (.+?)\);', re.DOTALL).findall(response)[0]
	j = json.loads(js)
	l = []
	for page in j['pages']:
		if page['idnam'] == 'start':
			children = page['props']['children']
			for child in children:
				if child['idnam'] == 'Cluster':
					clusters = child['props']['children'][0]['props']['clusterData']
					for cluster in clusters:
						d = {}						
						d['_name'] = cluster['foottxt'] + ' - ' + cluster['titletxt']
						d['_thumb'] = 'http://hbbtv.zdf.de/zdfstart/idesigner/img/' + cluster['img'].replace('intimg:','')
						d['url'] = cluster['id']
						d['mode'] = 'play'
						d['_type'] = 'video'
						l.append(d)
	return l
	
def play():
	d = {}
	d['media'] = []
	d['media'].append({'url':params['url'], 'type': 'video', 'stream':'MP4'})
	return d

modes = {
'main': main,
'play': play
}	

def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		libMediathek.endOfDirectory()	
list()