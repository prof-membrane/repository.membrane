# -*- coding: utf-8 -*-
import sys
import xbmcplugin
import urllib
import libartejsonparser as libArteJsonParser
import libmediathek3 as libMediathek

translation = libMediathek.getTranslation


def libArteListMain():
	l = []
	l.append({'_name':translation(31031), 'mode':'libArteListVideos',	'_type':'dir', 'url':'http://www.arte.tv/hbbtvv2/services/web/index.php/OPA/videos/mostviewed/20/ARTEPLUS7/de/DE'})
	l.append({'_name':translation(31032), 'mode':'libArteListAZ',  		'_type':'dir'})
	l.append({'_name':translation(31033), 'mode':'libArteListDate',		'_type':'dir'})
	return l
	
def libArteListAZ():
	l = []
	l.append({'_name':'360° GEO Reportage', 'mode':'libArteListVideos', '_type':'dir', 'url':'http://www.arte.tv/hbbtvv2/services/web/index.php/OPA/v3/videos/collection/MAGAZINE/RC-014120/de'})
	return libArteJsonParser.getAZ()
	
def libArteListVideos():
	return libArteJsonParser.getVideos(params['url'])

def libArteListDate():
	return libMediathek.populateDirDate('libArteListDateVideos')
		
def libArteListDateVideos():
	return libArteJsonParser.getDate(params['yyyymmdd'])
		
def libArtePlay():
	#return libArteJsonParser.getVideoUrl(params['url'])
	return libArteJsonParser.getVideoUrlWeb(params['url'])
	
def headUrl(url):#TODO: move to libmediathek3
	libMediathek.log(url)
	import urllib2
	req = urllib2.Request(url)
	req.get_method = lambda : 'HEAD'
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
	
	response = urllib2.urlopen(req)
	info = response.info()
	response.close()
	return info
	
def list():	
	modes = {
	'libArteListMain': libArteListMain,
	'libArteListAZ': libArteListAZ,
	'libArteListVideos': libArteListVideos,
	'libArteListDate': libArteListDate,
	'libArteListDateVideos': libArteListDateVideos,
	'libArtePlay': libArtePlay,
	}
	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	mode = params.get('mode','libArteListMain')
	if mode == 'libArtePlay':
		libMediathek.play(libArtePlay())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
