# -*- coding: utf-8 -*-
import json
import libmediathek3 as libMediathek

base = 'https://audiothek.ardmediathek.de'

header = 	{
			'Accept':'application/hal+json',
			'User-Agent':'okhttp/3.3.0',
			'Accept-Encoding':'gzip',
			}
			
def parseMostPlayed():
	response = libMediathek.getUrl(base)
	j = json.loads(response)
	return _grepItems(j['_embedded']['mt:mostPlayed']['_embedded']['mt:items'])
	
def parseFeaturedPlaylists():
	response = libMediathek.getUrl(base)
	j = json.loads(response)
	return _grepEditorialCollections(j['_embedded']['mt:featuredPlaylists']['_embedded']['mt:editorialCollections'])
	
def parseFeaturedProgramSets():
	response = libMediathek.getUrl(base)
	j = json.loads(response)
	return _grepProgramSets(j['_embedded']['mt:featuredProgramSets']['_embedded']['mt:programSets'])

def parseCat():
	#response = libMediathek.getUrl(base+'/editorialcategories'+'?limit=100',header)
	response = libMediathek.getUrl(base+'/editorialcategories',header)
	j = json.loads(response)
	return _grepEditorialCategories(j['_embedded']['mt:editorialCategories'])

def parseProgramSets(url):
	response = libMediathek.getUrl(url+'?limit=100',header)
	j = json.loads(response)
	return _grepProgramSets(j['_embedded']['mt:programSets'])
	
def parseItems(url):#TODO: date
	response = libMediathek.getUrl(url+'?limit=100',header)
	libMediathek.log(response)
	j = json.loads(response)
	return _grepItems(j['_embedded']['mt:items'])
	
	
def _grepItems(j):
	l = []
	for item in j:
		d = {}
		d['_name'] = item['title']
		d['_plot'] = item['synopsis']
		d['_duration'] = str(item['duration'])
		d['_thumb'] = item['_links']['mt:image']['href'].replace('{ratio}','16x9').replace('{width}','640')
		d['url'] = item['_links']['mt:bestQualityPlaybackUrl']['href']
		d['mode'] = 'play'
		d['_type'] = 'video'
		l.append(d)
	return l
	
def _grepEditorialCategories(j):
	l = []
	for item in j:
		d = {}
		d['_name'] = item['title']
		d['_thumb'] = item['_links']['mt:image']['href'].replace('{ratio}','16x9').replace('{width}','640')
		d['url'] = base + '/editorialcategories/' + item['id']
		#d['mode'] = 'listItems'
		d['mode'] = 'listProgramSets'
		d['_type'] = 'dir'
		l.append(d)
	return l
	
def _grepEditorialCollections(j):
	l = []
	for item in j:
		d = {}
		d['_name'] = item['title']
		d['_plot'] = item['synopsis']
		d['_items'] = item['numberOfElements']
		d['_thumb'] = item['_links']['mt:image']['href'].replace('{ratio}','16x9').replace('{width}','640')
		d['url'] = base + '/editorialcollections/' + item['id']
		d['mode'] = 'listItems'
		d['_type'] = 'dir'
		l.append(d)
	return l
	
def _grepProgramSets(j):
	l = []
	for item in j:
		d = {}
		d['_name'] = item['title']
		d['_plot'] = item['synopsis']
		d['_items'] = item['numberOfElements']
		d['_thumb'] = item['_links']['mt:image']['href'].replace('{ratio}','16x9').replace('{width}','640')
		d['url'] = base + '/programsets/' + item['id']
		d['mode'] = 'listItems'
		d['_type'] = 'dir'
		l.append(d)
	return l
	