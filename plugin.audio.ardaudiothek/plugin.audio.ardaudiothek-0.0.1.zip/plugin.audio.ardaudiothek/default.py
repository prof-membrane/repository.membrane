# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import xbmc
import xbmcaddon
import xbmcplugin
import resources.lib.jsonparser as jsonParser

base = 'https://audiothek.ardmediathek.de'

translation = xbmcaddon.Addon().getLocalizedString


def main():
	l = []
	l.append({'_name':'Meistgehört', 'mode':'listMostPlayed', '_type': 'dir'})
	l.append({'_name':'Sammlungen', 'mode':'listFeaturedPlaylists', '_type': 'dir'})#featuredPlaylists
	l.append({'_name':'Ausgewählte Sendungen', 'mode':'listFeaturedProgramSets', '_type': 'dir'})#featuredProgramSets
	l.append({'_name':'Themen', 'mode':'listCategories', '_type': 'dir'})
	return l
	
def listMostPlayed():
	return jsonParser.parseMostPlayed()
	
def listFeaturedPlaylists():
	return jsonParser.parseFeaturedPlaylists()
	
def listFeaturedProgramSets():
	return jsonParser.parseFeaturedProgramSets()
	
def listCategories():
	return jsonParser.parseCat()
	
def listProgramSets():
	return jsonParser.parseProgramSets(params['url'])
	
def listItems():
	return jsonParser.parseItems(params['url'])
	
def play():
	d = {}
	d['media'] = []
	d['media'].append({'url':params['url'], 'stream':'MP4'})
	return d
	return jsonParser.parseAudioUrl(params['url'])


modes = {
'main': main,
'listMostPlayed': listMostPlayed,
'listFeaturedPlaylists': listFeaturedPlaylists,
'listFeaturedProgramSets': listFeaturedProgramSets,
'listCategories': listCategories,
'listProgramSets': listProgramSets,
'listItems': listItems,
'play': play
}	

def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
list()