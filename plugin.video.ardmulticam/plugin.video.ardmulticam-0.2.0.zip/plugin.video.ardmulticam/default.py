﻿# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,string,random,cookielib,xbmcvfs

import time
import json
import libMediathek
import resources.lib._utils as _utils
from operator import itemgetter

channels = 'http://clipsapi.sportschau.de/ARDX/36640243euro2016/3.0/channels.json'
test = 'http://multicam.sportschau.de/match/2017884'
feed = 'http://livestreamapi.sportschau.de/feed/ard/cup=3/livestreaming.json'
idk = 'http://clipsapi.sportschau.de/ARDX/36640243euro2016/3.0/channels/2017884/publications.json'
idk2 = 'http://clipsapi.sportschau.de/ARDX/36640243euro2016/3.0/channels/2017884.json'

pluginhandle = int(sys.argv[1])

perspAlias = {
	'lsf':'Hauptperspektive',
	'playa':'Spielerkamera A',
	'playb':'Spielerkamera B',
	'mc1':'Hauptkamera A',
	'mc2':'Hauptkamera B',
	'cablecam':'Cablecam',
	'tactical':'Dachkamera',
	'revmid':'Gegenseite',
	'heli':'Helikopter'
	}

def main():
	libMediathek.addEntry({'name':'Live', 'mode':'listLive', 'type': 'dir', 'url': feed})
	list = []
	response = _utils.getUrl(channels)
	j = json.loads(response)
	for item in j:
		if 'description' in item['metadata']:
			dict = {}
			dict['name'] = item['metadata']['description']
			dict['shortCode'] = item['shortCode']
			dict['mode'] = 'listVideos'
			dict['type'] = 'dir'
			list.append(dict)
	list = sorted(list, key=itemgetter('name')) 
	libMediathek.addEntries(list)
	
def listLive():
	list = []
	response = _utils.getUrl(params['url'])
	j = json.loads(response)
	for persp in j[0]['VideoStreaming']:
		if persp['Description'] == 'lsf':
			dict = {}
			dict['name'] = 'Hauptperspektive - englischer Kommentator'
			dict['url'] = persp['Url']
			dict['mode'] = 'play'
			dict['type'] = 'video'
			list.append(dict)
			dict = {}
			if persp['Url'].endswith('filter=english)'):
				dict['name'] = 'Hauptperspektive - ohne Kommentator'
				dict['url'] = persp['Url'].replace('filter=english','')
				dict['mode'] = 'play'
				dict['type'] = 'video'
				list.append(dict)
		else:
			dict = {}
			dict['name'] = perspAlias.get(persp['Description'],persp['Description'])
			dict['url'] = persp['Url']
			dict['mode'] = 'play'
			dict['type'] = 'video'
			list.append(dict)
	list = sorted(list, key=itemgetter('name')) 
	libMediathek.addEntries(list)
	
def listVideos():
	list = []
	response = _utils.getUrl('http://clipsapi.sportschau.de/ARDX/36640243euro2016/3.0/channels/' + params['shortCode'] + '/publications.json')
	j = json.loads(response)
	for item in j:
		dict = {}
		dict['id'] = item['id']
		dict['url'] = 'http://clipsapi.sportschau.de/ARDX/36640243euro2016/3.0/channels/' + params['shortCode'] + '/publications/' + item['id'] + '.json'
		if item['hidden']:
			
			print 'TODO'
		else:
			try:
				if 'title_translation_de' in item['metadata']:
					dict['name'] = item['metadata']['title_translation_de'] + ' (' + str(item['videoAssetsCount']) + ')'
				else:
					dict['name'] = item['metadata']['title'] + ' (' + str(item['videoAssetsCount']) + ')'
				#todo thumb
				dict['mode'] = 'listPersp'
				dict['type'] = 'dir'
				list.append(dict)
			except:
				xbmc.log(str(item))
	libMediathek.addEntries(list)
	
def listPersp():
	list = []
	response = _utils.getUrl(params['url'])
	j = json.loads(response)
	for asset in j['videoAssets']:
		dict = {}
		dict['name'] = perspAlias.get(asset['recorderShortCode'],asset['recorderShortCode'])
		dict['duration'] = asset['duration']
		#dict['url'] = 'http://clipassets-i.sportschau.de/' + asset['renditions']['multibitrate'] + '.m3u8'#http://clipassets-p.sportschau.de/59D085D7C0F398439DA19A77FE4DA512/59D085D7C0F398439DA19A77FE4DA512.m3u8
		dict['url'] = 'http://clipassets-p.sportschau.de/' + asset['renditions']['digital'] + '.mp4'#http://clipassets-p.sportschau.de/59D085D7C0F398439DA19A77FE4DA512/59D085D7C0F398439DA19A77FE4DA512.m3u8
		dict['mode'] = 'play'
		dict['type'] = 'video'
		#todo thumb
		list.append(dict)
	libMediathek.addEntries(list)	

	
def play():
	listitem = xbmcgui.ListItem(path=params['url'])
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	

params=libMediathek.get_params()
if not params.has_key('mode'):
	main()
elif params['mode'] == 'listLive':
	listLive()
elif params['mode'] == 'listVideos':
	listVideos()
elif params['mode'] == 'listPersp':
	listPersp()
elif params['mode'] == 'play':
	play()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
