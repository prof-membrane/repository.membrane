﻿# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,string,random,cookielib,xbmcvfs

import time
import json
import libMediathek
import resources.lib._utils as _utils

test = 'http://multicam.sportschau.de/match/2017884'
feed = 'http://livestreamapi.sportschau.de/feed/ard/cup=3/livestreaming.json'
idk = 'http://clipsapi.sportschau.de/ARDX/36640243euro2016/3.0/channels/2017884/publications.json'

pluginhandle = int(sys.argv[1])

def main():
	list = []
	response = _utils.getUrl(feed)
	j = json.loads(response)
	for persp in j[0]['VideoStreaming']:
		dict = {}
		dict['name'] = persp['Name']
		dict['url'] = persp['Url']
		dict['mode'] = 'play'
		dict['type'] = 'video'
		list.append(dict)
	libMediathek.addEntries(list)
	
	
def play():
	listitem = xbmcgui.ListItem(path=params['url'])
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	

params=libMediathek.get_params()
if not params.has_key('mode'):
	main()
elif params['mode'] == 'play':
	play()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
