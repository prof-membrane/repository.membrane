# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import resources.lib.zdfparser as zdfparser
import libzdf
import xbmcaddon
translation = xbmcaddon.Addon().getLocalizedString

def main():
	l = []
	l.append({'_name':translation(30001), 'mode':'listLive','_type':'dir'})
	l.append({'_name':translation(30002), 'mode':'listSports','_type':'dir'})
	return l

def listLive():
	l = [
		{'_name':'Olympia 1','url':'https://olympia1ardmsl-lh.akamaihd.net/i/ows1_msl@167397/master.m3u8','_type':'video','mode':'play'},
		{'_name':'Olympia 2','url':'https://olympia2slmsl-lh.akamaihd.net/i/ows2_msl@37191/master.m3u8','_type':'video','mode':'play'},
		{'_name':'Olympia 3','url':'https://olympia3slmsl-lh.akamaihd.net/i/ows3_msl@37201/master.m3u8','_type':'video','mode':'play'},
		{'_name':'Olympia 4/Das Erste','url':'https://olympia4slmsl-lh.akamaihd.net/i/ows4_msl@39596/master.m3u8','_type':'video','mode':'play'},
		{'_name':'ZDF','url':'http://zdf1314-lh.akamaihd.net/i/de14_v1@392878/master.m3u8','_type':'video','mode':'play'},
	]
	return l
	
def play():
	return {'media':[{'url':params['url'],'stream':'hls','type':'video'}]}
	
def listSports():
	return zdfparser.getSports()
	
def listSport():
	return zdfparser.getSport(params['url'])
	
modes = {
'main': main,
'listLive': listLive,
'listSports': listSports,
'listSport': listSport,
'play':play
}
	
def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	mode = params.get('mode','main')
	if mode == 'play':
		libMediathek.play(play())
	elif mode.startswith('libZdf'):
		libzdf.list()
	else:
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		libMediathek.endOfDirectory()	
list()