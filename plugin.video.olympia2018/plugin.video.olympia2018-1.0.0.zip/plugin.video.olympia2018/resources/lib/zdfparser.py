# -*- coding: utf-8 -*-
import json
import re
import libmediathek3 as libMediathek

baseUrl = 'https://olympia.zdf.de'

def getSports():
	response = libMediathek.getUrl(baseUrl+'/sportarten')
	sports = re.compile('<script id="configuration" type="text/javascript">.+?\'sports\': (.+?)\n', re.DOTALL).findall(response)[0]
	j = json.loads(sports)
	l = []
	for data in j['data']:
		d = {}
		d['_name'] = data['name']
		d['_thumb'] = baseUrl + data['image']
		d['_type'] = 'dir'
		d['url'] = baseUrl + data['url']
		d['mode'] = 'listSport'
		l.append(d)
	return l
	
def getSport(url):
	response = libMediathek.getUrl(url)
	id = re.compile('<div class="content content-teaserlist is-type-lazy".+?data-name="(.+?)"', re.DOTALL).findall(response)[0]
	response = libMediathek.getUrl(baseUrl + '/feeds/' + id)
	j = json.loads(response)
	l = []
	for data in j[id]['data']:
		if data['video'] != None:
			libMediathek.log(str(data))
			d = {}
			d['_name'] = data['title']
			d['_thumb'] = 'http:' + data['thumbnails'][0]['url']
			d['_duration'] = str(data['video']['duration'])
			d['_plot'] = data['text']
			d['_type'] = 'video'
			d['id'] = data['id']
			d['mode'] = 'libZdfPlayById'
			l.append(d)
	return l