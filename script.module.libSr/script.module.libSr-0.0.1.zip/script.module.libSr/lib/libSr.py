# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import libSrJsonParser
import libMediathek

translation = xbmcaddon.Addon(id='script.module.libMediathek').getLocalizedString

def libSrListMain():
	libMediathek.addEntry({'name':translation(31030), 'mode':'libSrListVideos', 'url':'http://hbbtv.sr-mediathek.de/inc/TeaserJSON.php'})
	#libMediathek.addEntry({'name':translation(31031), 'mode':'libSrListVideos', 'url':'http://swrmediathek.de/app-2/index.html'})
	libMediathek.addEntry({'name':translation(31032), 'mode':'libSrListShows', 'url':'http://hbbtv.sr-mediathek.de/inc/SndazJSON.php'})
	libMediathek.addEntry({'name':translation(31033), 'mode':'libSrListDate'})
	#libMediathek.addEntry({'name':translation(31034), 'mode':'libSrListDir', 'url':'http://swrmediathek.de/app-2/rubriken.html'})
	#libMediathek.addEntry({'name':translation(31035), 'mode':'libSrListDir', 'url':'http://swrmediathek.de/app-2/themen.html'})
	#libMediathek.addEntry({'name':translation(31039), 'mode':'libSrSearch'})
	#libMediathek.addEntry({'name':translation(31032), 'mode':'libSrListLetters'})
	#libMediathek.addEntry({'name':translation(31033), 'mode':'libSrListDate'})
	#libMediathek.addEntry({'name':translation(31034), 'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/appdata/servlet/tv/Rubriken/mehr?documentId=21282550&json'})
	
	
def libSrListDate():
	libMediathek.populateDirDate('libSrListDateVideos')
		
def libSrListDateVideos():
	libMediathek.addEntries(libSrJsonParser.getDate(params['datum']))
	
def libSrListShows():
	libMediathek.addEntries(libSrJsonParser.getShows())
		
def libSrListVideos():
	libMediathek.addEntries(libSrJsonParser.getVideos(params['url']))
	
def libSrPlay():
	url = params['url']
	listitem = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	
	
	
	

def list():	
	modes = {
	'libSrListShows': libSrListShows,
	'libSrListVideos': libSrListVideos,
	'libSrListDate': libSrListDate,
	'libSrListDateVideos': libSrListDateVideos,
	'libSrPlay': libSrPlay,
	#'libSrSearch': libSrSearch,
	
	}
	
	
	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	xbmc.log('mode')
	xbmc.log(params.get('mode',''))
	if not params.has_key('mode'):
		libSrListMain()
	else:
		modes.get(params['mode'],libSrListMain)()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	