# -*- coding: utf-8 -*-
import xbmc
import json
import _utils
import re
#import dateutil.parser

def getShows(url='http://hbbtv.sr-mediathek.de/inc/SndazJSON.php'):
	xbmc.log(url)
	response = _utils.getUrl(url)
	
	j = json.loads(response)
	
	l = []
	for letterNumber in j:
		for entry in j[letterNumber]:
			show = _getDictShows(entry)
			if show['entries'] != '0':
				l.append(show)
	#from operator import itemgetter
	l = sorted(l, key=lambda x: x['name'].lower()) 
	return l
	
def getVideos(url):
	#url += '&s=2'
	xbmc.log(url)
	response = _utils.getUrl(url)
	j = json.loads(response)
	l = []
	for entry in j:
		vid = _getDictVideos(entry)
		l.append(vid)
	return l
	
def getDate(day):
	response = _utils.getUrl('http://hbbtv.sr-mediathek.de/inc/SndvrpJSON.php')
	j = json.loads(response)
	l = []
	#if True:
	if day in j:
		#for entry in j[int(day)]:
		for entry in j[day]:
			vid = _getDictVideos(entry,'date')
			l.append(vid)
	return l[::-1]
	
def _getDictShows(jsonDict):
	d = {}
	d['name'] = jsonDict['s_name']
	d['entries'] = jsonDict['s_anzahl']
	d['url'] = 'http://hbbtv.sr-mediathek.de/inc/sendungJSON.php?sid=' + jsonDict['s_id']
	d['plot'] = jsonDict['s_beschreibung']
	d['thumb'] = jsonDict['bild']
	d['mode'] = 'libSrListVideos'
	d['type'] = 'dir'
	
	return d
	
def _getDictVideos(jsonDict,type='video'):
	d = {}
	d['name'] = jsonDict['ueberschrift']
	d['url'] = 'http://sr_hls_od-vh.akamaihd.net/i/' + jsonDict['media_url_firetv']
	d['plot'] = jsonDict['kompletttext']
	d['mpaa'] = jsonDict['fsk']
	d['thumb'] = jsonDict['bild']
	d['aired'] = jsonDict['start'][:4] + '-' + jsonDict['start'][4:6] + '-' + jsonDict['start'][6:8]
	d['airedtime'] = jsonDict['start'][8:10] + ':' + jsonDict['start'][10:12]
	#d['start'] = jsonDict['start']
	if 'playtime_hh' in jsonDict:
		d['duration'] = str(int(jsonDict['playtime_hh']) * 3600 + int(jsonDict['playtime_mm']) * 60 + int(jsonDict['playtime_ss']))
	d['mode'] = 'libSrPlay'
	d['type'] = type
	
	return d