# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import libmdrmetaparser as libMdrMetaParser
import libmdrhtmlparser as libMdrHtmlParser
import libmediathek3 as libMediathek

translation = libMediathek.getTranslation





def getDate(date):
	return libMdrJsonParser.parseDate(date)
def getVideoUrl(url):
	return libMdrJsonParser.parseVideo(url)
def play(dict):
	url = getVideoUrl(dict["url"])
	#listitem = xbmcgui.ListItem(label=video["name"],thumbnailImage=video["thumb"],path=url)
	listitem = xbmcgui.ListItem(label=dict["name"],path=url)
	xbmc.Player().play(url, listitem)	
	

def libMdrListMain():
	l = []
	#libMediathek.addEntries(libMdrMetaParser.testparse())
	l.append({'name':'Neu', 'mode':'libMdrListPlus', 'url':'http://www.mdr.de/mediathek/mediathek-neu-100-meta.xml'})
	l.append({'name':'Meistgesehen', 'mode':'libMdrListPlus', 'url':'http://www.mdr.de/mediathek/mediathek-meistgeklickt-100-meta.xml'})
	l.append({'name':'Sendungen AZ', 'mode':'libMdrListShows'})
	l.append({'name':'Rubriken', 'mode':'libMdrListRubrics'})
	#libMediathek.addEntry({'name':'test', 'mode':'libMdrListVideos', 'url':'http://www.mdr.de/tv/programm/mordenimnorden100-meta.xml'})
	#libMediathek.addEntry({'name':'mdr+', 'mode':'libMdrListVideos', 'url':'http://www.mdr.de/mediathek/livestreams/mdr-plus/mediathek-mdrplus-100-meta.xml'})
	#libMediathek.addEntry({'name':'day', 'mode':'pDays'})
	#libMediathek.addEntry({'name':'Neue Videos', 'mode':'libMdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungverpasst/sendung-verpasst-100~_format-mp111_type-rss.feed'})
	#libMediathek.addEntry({'name':translation(31032), 'mode':'libMdrListLetters'})
	#libMediathek.addEntry({'name':'Videos in Gebärdensprache', 'mode':'libMdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/videos-dgs-100~_format-mp111_type-rss.feed'})
	#libMediathek.addEntry({'name':'Videos mit Untertiteln', 'mode':'libMdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/videos-untertitel-100~_format-mp111_type-rss.feed'})
	
	#libMediathek.addEntry({'name':translation(31033), 'mode':'libMdrListDate'})
	#libMediathek.addEntry({'name':translation(31034), 'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/appdata/servlet/tv/Rubriken/mehr?documentId=21282550&json'})
	return l
def libMdrListRubrics():
	l = [
	{'name':'Reportagen und Dokumentationen','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/reportage/mediathek-reportagen-dokumentationen-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Sport','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/sport/mediathek-sport-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Sachsen','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/sachsen/mediathek-sachsen-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Sachsen-Anhalt','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/sachsen-anhalt/mediathek-sachsen-anhalt-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Thüringen','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/thueringen/mediathek-thueringen-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Kinder','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/kinder/mediathek-kinder-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Filme und Serien','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/film-serie/mediathek-film-serien-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Magazine','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/magazine/mediathek-magazine-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Nachrichten','mode':'libMdrListHtml','url':'http://www.mdr.de/mediathek/themen/nachrichten/mediathek-nachrichten-100_box--5390492834412829556_zc-4e12cc21.html'},
	{'name':'Mdr+', 'mode':'libMdrListPlus', 'url':'http://www.mdr.de/mediathek/livestreams/mdr-plus/mediathek-mdrplus-100-meta.xml'}
	]
	return l
def pDays():
	return libMdrMetaParser.parseDays()
	
def libMdrBroadcast():
	return libMdrMetaParser.parseBroadcast(params['url'])
	
def libMdrListHtml():
	return libMdrHtmlParser.testparse(params['url'])
	
def libMdrListLetters():
	libMediathek.populateDirAZ('libMdrListShows',ignore=['#'])
	return []
	
def libMdrListShows():
	xbmc.log('listshows')
	from operator import itemgetter
	l = sorted(libMdrMetaParser.testparse(), key=itemgetter('_name')) 
	return l
def libMdrListPlus():
	xbmc.log('listplus')
	return libMdrMetaParser.parseMdrPlus(params['url'])
	
def libMdrListVideos():
	return libMdrMetaParser.parseVideos(params['url'])
	#libMediathek.addEntries(libMdrRssParser.parseVideos(params['url']))
	
def libMdrListDate():
	return libMediathek.populateDirDate('libMdrListDateVideos')
	
	
def libMdrListDateVideos():
	return libMdrMetaParser.parseDays()
	#libMediathek.addEntries(libMdrJsonParser.parseDate(params['date'],params['name']))#params['date'] =yyyy-mm-dd
	
def libMdrPlay():
	return libMdrMetaParser.parseVideo(params['url'])
	
	
def list():	
	modes = {
	'libMdrListMain': libMdrListMain,
	'libMdrBroadcast': libMdrBroadcast,
	'pDays': pDays,
	'libMdrListHtml': libMdrListHtml,
	'libMdrListRubrics': libMdrListRubrics,
	
	
	'libMdrListLetters': libMdrListLetters,
	'libMdrListShows': libMdrListShows,
	'libMdrListPlus': libMdrListPlus,
	'libMdrListVideos': libMdrListVideos,
	'libMdrListDate': libMdrListDate,
	'libMdrListDateVideos': libMdrListDateVideos,
	#'libMdrListDateChannels': libMdrListDateChannels,
	'libMdrPlay': libMdrPlay
	}
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	mode = params.get('mode','libMdrListMain')
	xbmc.log(mode)
	if mode == 'libMdrPlay':
		libMediathek.play(libMdrPlay())
	else:
		xbmc.log
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
