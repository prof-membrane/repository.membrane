# -*- coding: utf-8 -*-
import urllib2
import json
import sys
import xbmcplugin
import xbmcgui

def list_all_clusters(letter=False, language = 'de', icon = ''):
	list = []
	api_url = 'http://www.arte.tv/papi/tvguide/epg/clusters/%s/0/ALL.json' % language[0].upper()
	print api_url
	json_data = urllib2.urlopen(api_url).read()
	print json_data
	clusters = json.loads(json_data)['configClusterList']
	lang = language.upper()
	for cluster in clusters:
		try:
			if cluster['hidden']: continue
			cluster_id = cluster['clusterId']
			title = cluster['title' + lang]
			subtitle = cluster['subtitle' + lang]
			desc = cluster['text1' + lang]
			thumb = cluster['img' + lang]['IUR']
			# fanart = cluster['img' + lang]['imageOrigin']
			link = '%s?mode=list-videos&cluster=%s' % (sys.argv[0], cluster_id)
			#print letter
			firstletter = title[0].replace('1','0').replace('2','0').replace('3','0').replace('4','0').replace('5','0').replace('6','0').replace('7','0').replace('8','0').replace('9','0')
			#print firstletter
			if letter == False or letter == firstletter:
				list.append([title,link,thumb,desc])
		except: continue
	return list