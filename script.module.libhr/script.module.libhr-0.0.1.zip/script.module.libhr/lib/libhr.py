# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import libhrparser as libHrParser
import libmediathek3 as libMediathek

translation = libMediathek.getTranslation




def libHrListMain():
	l = []
	#l.append({'_name':translation(31030), 'mode':'libHrListVideos', 'url':'http://swrmediathek.de/app-2/svp.html'})
	#l.append({'_name':translation(31031), 'mode':'libHrListVideos', 'url':'http://swrmediathek.de/app-2/index.html'})
	#l.append({'_name':translation(31032), 'mode':'libHrListDir'})
	l.append({'_name':translation(31033), 'mode':'libHrListDate'})
	#l.append({'_name':translation(31034), 'mode':'libHrListDir', 'url':'http://swrmediathek.de/app-2/rubriken.html'})
	#l.append({'_name':translation(31035), 'mode':'libHrListDir', 'url':'http://swrmediathek.de/app-2/themen.html'})
	#l.append({'_name':translation(31039), 'mode':'libHrSearch'})
	return l

def libHrListDir():
	return libHrParser.parseShows()
	
def libHrListVideos():
	return libHrParser.parseVideos(params['url'])
	
def libHrListDate():
	return libMediathek.populateDirDate('libHrListDateVideos')
		
def libHrListDateVideos():
	return libHrParser.getDate(params['yyyymmdd'])
	

def libHrSearch():
	keyboard = xbmc.Keyboard('', translation(31039))
	keyboard.doModal()
	if keyboard.isConfirmed() and keyboard.getText():
		search_string = urllib.quote_plus(keyboard.getText())
		url = 'http://swrmediathek.de/app-2/suche/' + search_string
		return libHrParser.getList(url,'video','libHrPlay')
	
def libHrPlay():
	d = {}
	d['media'] = []
	d['media'].append({'url':params['url'], 'type': 'video', 'stream':'HLS'})
	return d
	#return libHrJsonParser.getVideo(params['id'])
	
def play(dict):
	return getVideoUrl(dict["url"])
	
def libHrListLetters():
	libMediathek.populateDirAZ('libHrListShows',ignore=['#'])
	return []
	
def libHrListShows():
	return libHrParser.parseShows(params['name'])
	

def list():	
	modes = {
	'libHrListMain': libHrListMain,
	'libHrListDate': libHrListDate,
	'libHrListDateVideos': libHrListDateVideos,
	'libHrPlay': libHrPlay,
	}
	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	mode = params.get('mode','libHrListMain')
	if mode == 'libHrPlay':
		libMediathek.play(libHrPlay())
	else:
		xbmc.log
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	
