# -*- coding: utf-8 -*-
import xbmc
import json
import libmediathek3 as libMediathek
import re
import xml.etree.ElementTree as ET

#import dateutil.parser

baseUrl = 'http://ndr.de'
	
def getDate(yyyymmdd):
	l = []
	response = libMediathek.getUrl('http://www.hr-online.de/website/fernsehen/sendungen/')
	match = re.compile("<div class='dayDate' id='(.+?)' style='cursor:pointer;'>(.+?)</div>", re.DOTALL).findall(response)
	
	yyyy,mm,dd = yyyymmdd.split('-')
	if mm.startswith('0'):
		mm = mm[1:]
	if dd.startswith('0'):
		dd = dd[1:]
	
	url = False
	for id,date in match:
		if date == dd + '. ' + mm + '.':
			id = 0 - int(id)
			url = re.compile("loadPlayItems\('(.+?)'\);", re.DOTALL).findall(response)[id]
			
	if not url:
		return []
	
	response = libMediathek.getUrl(url).decode('cp1252').encode('utf-8')
	items = re.compile('<item>(.+?)</item>', re.DOTALL).findall(response)
	for item in items:
		d = {}
		d['_name'] = re.compile('<title>(.+?)</title>', re.DOTALL).findall(item)[0].replace(' - ganze Sendung','')
		xbmc.log(d['_name'])
		if '<description>' in item:
			d['_plot'] = re.compile('<description>(.+?)</description>', re.DOTALL).findall(item)[0]
		d['url'] = re.compile('file="(.+?)"', re.DOTALL).findall(item)[0]
		#TODO subtitle, duration, showname, date
		d['thumb'] = re.compile('<!\[CDATA\[(.+?)\]\]>', re.DOTALL).findall(item)[0].strip()
		HH,MM,SS = re.compile('duration="(.+?)"', re.DOTALL).findall(item)[0].split(':')
		d['_duration'] = str(int(HH) * 3600 + int(MM) * 60 + int(SS))
		day,time = re.compile('<jwplayer:date>(.+?)</jwplayer:date>', re.DOTALL).findall(item)[0].split(' ')
		d['_aired'] = day.replace('.','-')
		d['_airedtime'] = time
		#d['_'] = re.compile('<jwplayer:author>(.+?)</jwplayer:author>', re.DOTALL).findall(item)[0]
		d['_type'] = 'date'
		d['mode'] = 'libHrPlay'
		l.append(d)
		
	
	return l[::-1]
 
def parseShows():
	response = libMediathek.getUrl('http://www.ndr.de/mediathek/sendungen_a-z/index.html')
	videos = re.compile('<section class="columnedlist">(.+?)<div id="footer">', re.DOTALL).findall(response)[0]
	l = []
	match = re.compile('<a href="(.+?)".+?>(.+?)</a>', re.DOTALL).findall(videos)
	for url,name in match:
		d = {}
		d['url'] = baseUrl + url
		d['_name'] = name
		d['_type'] = 'dir'
		d['mode'] = 'libNdrListVideos'
		l.append(d)
	return l
	
def parseVideos(url):
	response = libMediathek.getUrl(url)
	s = response.split('<div class="pagepadding">')
	s2 = s[-1].split('<div class="pagination">')
	
	videos = re.compile('<div class="modulepadding">.+?<img src="(.+?)".+?<span class="icon icon_video"></span>(.+?)<.+?<a href="(.+?)".+?>(.+?)</a>.+?<p>(.+?)<', re.DOTALL).findall(s2[0])
	l = []
	for thumb,duration,url,name,plot in videos:
		d = {}
		MM,SS = duration.split(' ')[0].split(':')
		d['_duration'] = str(int(MM) * 60 + int(SS))
		d['id'] = url.replace('.html','').split(',')[-1]
		d['_name'] = name
		d['_thumb'] = baseUrl + thumb.replace('-einspaltig.jpg','-zweispaltig.jpg')
		d['_plot'] = plot
		d['_type'] = 'video'
		d['mode'] = 'libNdrPlay'
			
		l.append(d)
	
	xbmc.log(str(len(s)))
	if len(s2) > 1 and '<a title="weiter" href="' in s2[1]:
		d = {}
		d['url'] = baseUrl + re.compile('<a title="weiter" href="(.+?)"', re.DOTALL).findall(s2[1])[0]
		d['_type'] = 'nextPage'
		d['mode'] = 'libNdrListVideos'
		l.append(d)
		
	return l
	