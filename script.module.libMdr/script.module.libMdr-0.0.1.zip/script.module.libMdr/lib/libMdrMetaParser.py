# -*- coding: utf-8 -*-
import xbmc
import json
import _utils
import re
import xml.etree.ElementTree as ET
#import dateutil.parser

base = 'http://www1.wdr.de'

def testparse(url='http://www.mdr.de/mediathek/fernsehen/a-z/sendungenabisz100-meta.xml'):
	response = _utils.getUrl(url)
	root = ET.fromstring(response)
	xbmc.log('################')
	xbmc.log(str(root[2]))
	i = 0
	list = []
	#document,childNodes,childNode,childNodes,properties,propertie#2,document,customElements,queryResult
	for document in root[2][0][1][0][0][1][1][0][5]:
		dict = {}
		for node in document:
			if node.tag == 'properties':
				for node2 in node:
					#
					#if i == 0:
					#	xbmc.log(node2.tag)
					#	xbmc.log(str(node2.attrib))
					#	xbmc.log(node2.attrib.get('name'))
					if node2.attrib.get('name','') == 'mdr-core:teaserText':
						xbmc.log('plot')
						try:
							dict['plot'] = node2[0].text
						except: pass
					elif node2.attrib.get('name','') == 'mdr-core:headline':
						xbmc.log('name')
						#xbmc.log(node2[0].text)
						try:
							dict['name'] = node2[0].text
						except: pass
				i = 1	
			elif node.tag == 'childNodes':
				for node2 in node:
					if node2.attrib.get('name','') == 'mdr-core:teaserImage':
						try: #todo: undo hack
							dict['thumb'] = node2[0][1][1][0][0].text.replace('.html','-resimage_v-variantBig16x9_w-960.png?version=4333')
						except: pass
			elif node.tag == 'customElements':
				#xbmc.log(str(node.tag))
				for node2 in node:
					#xbmc.log(str(node2.tag))
					if node2.tag == 'metaxmlUrl':
						#xbmc.log('##########')
						#xbmc.log(node2.tag)
						dict['url'] = node2.text
		dict['type'] = 'dir'
		dict['mode'] = 'libMdrListVideos'
		xbmc.log(str(dict))
		list.append(dict)
	return list

def parseVideos(url='http://www.mdr.de/tv/programm/mordenimnorden100-meta.xml'):
	response = _utils.getUrl(url)
	root = ET.fromstring(response)
	
	list = []
	#document,broadcasts,broadcast,
	for broadcast in root[0]:
		dict = {}
		for node in broadcast[0]:
			if node.tag == 'videos':
				dict['url'] = node[0][0][0][1].text#todo: makemrobust
			elif node.tag == 'properties':
				for node2 in node:#mdr-core:episodeText
					#xbmc.log(node2.tag)
					#xbmc.log(node2.attrib.get('name',''))
					if node2.attrib.get('name','') == 'mdr-core:episodeText':
						dict['name'] = node2[0].text
					if node2.attrib.get('name','') == 'mdr-core:headline':
						dict['tvshowtitle'] = node2[0].text
						if not 'name' in dict:
							dict['name'] = node2[0].text
					if node2.attrib.get('name','') == 'mdr-core:fsk':
						dict['mpaa'] = node2[0].text
					if node2.attrib.get('name','') == 'mdr-core:language':
						dict['lang'] = node2[0].text
					if node2.attrib.get('name','') == 'mdr-core:episodeNumber':
						dict['episode'] = node2[0].text
					if node2.attrib.get('name','') == 'mdr-core:duration':
						s = node2[0].text.split(':')
						dict['duration'] = str(int(s[0]) * 3600 + int(s[1]) * 60 + int(s[2]))
			elif node.tag == 'childNodes':
				for node2 in node:
					if node2.attrib.get('name','') == 'mdr-core:teaserImage':
						try:
							for node3 in node2[0]:
								if node3.attrib.get('name','') == 'sophora:reference':
									dict['thumb'] = node3[1][0][0].text.replace('.html','-resimage_v-variantBig16x9_w-960.png?version=4333')
						except: pass
					elif node2.attrib.get('name','') == 'mdr-core:copyText':
						try:
							for node3 in node2:
								xbmc.log(node3.tag)
								if node3.tag == 'childNodes':
									for property in node3[0][0]:
										if property.attrib.get('name','') == 'sophora-extension:text':
											dict['plot'] = property[0].text.replace('<br/>','\n')
						except: pass
						
		dict['type'] = 'video'
		dict['mode'] = 'libMdrPlay'
		xbmc.log(str(dict))
		list.append(dict)
	return list
	
def parseDays(url='http://www.mdr.de/mediathek/fernsehen/sendung-verpasst--100-meta.xml'):
	response = _utils.getUrl(url)
	root = ET.fromstring(response)
	l = []
	for childNode in root.find('childNodes'):
		if childNode.attrib.get('name','') == 'mdr-core:broadcastDays':
			for childNode2 in childNode.find('childNodes'):
				d = {}
				for property in childNode2.find('properties'):
					if property.attrib.get('name','') == 'sophora:reference':
						document = property.find('document')
						d['url'] = document.find('customElements').find('metaxmlUrl').text
						for property2 in document.find('properties'):
							if property2.attrib.get('name','') == 'mdr-core:date':
								d['name'] = property2[0].text
								d['date'] = property2[0].text
				d['type'] = 'dir'
				d['mode'] = 'libMdrBroadcast'
				l.append(d)
				xbmc.log(str(d))
	return l

def parseBroadcast(url):
	response = _utils.getUrl(url)
	root = ET.fromstring(response)
	l = []
	for childNode in root.find('childNodes'):
		dict = {}
		xbmc.log('###############')
		
		#for t in childNode:
		#	xbmc.log(t.tag)
		for property in childNode.find('properties'):
			#xbmc.log(property.tag)
			#xbmc.log(property.attrib.get('name',''))
			
			if property.attrib.get('name','') == 'sophora:reference':
				xbmc.log('reference')
				for p in property:
					xbmc.log(p.tag)
				broadcast = property.find('document')
				if broadcast != None:
					for node in broadcast:
						xbmc.log(node.tag)
					
						if node.tag == 'videos':
							dict['url'] = node[0][0][0][1].text#todo: makemrobust
						elif node.tag == 'properties':
							for node2 in node:#mdr-core:episodeText
								#xbmc.log(node2.tag)
								#xbmc.log(node2.attrib.get('name',''))
								if node2.attrib.get('name','') == 'mdr-core:episodeText':
									dict['name'] = node2[0].text
								if node2.attrib.get('name','') == 'mdr-core:headline':
									dict['tvshowtitle'] = node2[0].text
									if not 'name' in dict:
										dict['name'] = node2[0].text
								if node2.attrib.get('name','') == 'mdr-core:fsk':
									dict['mpaa'] = node2[0].text
								if node2.attrib.get('name','') == 'mdr-core:language':
									dict['lang'] = node2[0].text
								if node2.attrib.get('name','') == 'mdr-core:episodeNumber':
									dict['episode'] = node2[0].text
								if node2.attrib.get('name','') == 'mdr-core:duration':
									s = node2[0].text.split(':')
									dict['duration'] = str(int(s[0]) * 3600 + int(s[1]) * 60 + int(s[2]))
						elif node.tag == 'childNodes':
							for node2 in node:
								if node2.attrib.get('name','') == 'mdr-core:teaserImage':
									try:
										for node3 in node2[0]:
											if node3.attrib.get('name','') == 'sophora:reference':
												dict['thumb'] = node3[1][0][0].text.replace('.html','-resimage_v-variantBig16x9_w-960.png?version=4333')
									except: pass
								elif node2.attrib.get('name','') == 'mdr-core:copyText':
									try:
										for node3 in node2:
											xbmc.log(node3.tag)
											if node3.tag == 'childNodes':
												for property2 in node3[0][0]:
													if property2.attrib.get('name','') == 'sophora-extension:text':
														dict['plot'] = property2[0].text.replace('<br/>','\n')
									except: pass
		dict['type'] = 'video'
		dict['mode'] = 'libMdrPlay'
		xbmc.log(str(dict))
		if "name" in dict:
			l.append(dict)
	return l
	

def parseMdrPlus(url):
	response = _utils.getUrl(url)
	root = ET.fromstring(response)
	l = []
	for node in root.find('childNodes').find('childNode').find('childNodes').find('childNode').find('childNodes').find('childNode').find('properties').find('property').find('document').find('customElements').find('queryResult'):
		xbmc.log(str(node.tag))
	for document in root.find('childNodes').find('childNode').find('childNodes').find('childNode').find('childNodes').find('childNode').find('properties').find('property').find('document').find('customElements').find('queryResult'):
		d = {}
		d['duration'] = _durationToS(document.find('customElements').find('duration').text)
		d['url'] = document.find('customElements').find('metaxmlUrl').text
		for property in document.find('properties'):
			if property.attrib.get('name','') == 'mdr-core:headline':
				d['name'] = property[0].text
			if property.attrib.get('name','') == 'mdr-core:teaserText':
				d['plot'] = property[0].text
		for childNode in document.find('childNodes'):
			xbmc.log(str(childNode))
			if childNode.attrib.get('name','') == 'mdr-core:teaserImage':
				xbmc.log('teaser')
				for property in childNode.find('properties'):
					xbmc.log('prop')
					if property.attrib.get('name','') == 'sophora:reference':
						xbmc.log('img')
						d['thumb'] = property.find('document').find('customElements').find('htmlUrl').text.replace('.html','-resimage_v-variantBig16x9_w-960.png?version=4333')
		
		d['type'] = 'video'
		d['mode'] = 'libMdrPlay'
		xbmc.log(str(d))
		l.append(d)
	return l
def parseVideo(url):
	if url.endswith('m3u8'):
		return url
	response = _utils.getUrl(url)
	return re.compile('<adaptiveHttpStreamingRedirectorUrl>(.+?)</adaptiveHttpStreamingRedirectorUrl>', re.DOTALL).findall(response)[0]

def _durationToS(d):
	s = d.split(':')
	if len(s) == 2:
		return str(int(s[0]) * 60 + int(s[1]))
	else:
		return '0'