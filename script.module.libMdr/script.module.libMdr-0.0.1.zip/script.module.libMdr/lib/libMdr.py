# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib
import libMdrMetaParser
import libMediathek

translation = xbmcaddon.Addon(id='script.module.libMediathek').getLocalizedString





def getDate(date):
	return libMdrJsonParser.parseDate(date)
def getVideoUrl(url):
	return libMdrJsonParser.parseVideo(url)
def play(dict):
	url = getVideoUrl(dict["url"])
	#listitem = xbmcgui.ListItem(label=video["name"],thumbnailImage=video["thumb"],path=url)
	listitem = xbmcgui.ListItem(label=dict["name"],path=url)
	xbmc.Player().play(url, listitem)	
	

def libMdrListMain():
	#libMediathek.addEntries(libMdrMetaParser.testparse())
	libMediathek.addEntry({'name':'Neu', 'mode':'libMdrListPlus', 'url':'http://www.mdr.de/mediathek/mediathek-neu-100-meta.xml'})
	libMediathek.addEntry({'name':'Meistgesehen', 'mode':'libMdrListPlus', 'url':'http://www.mdr.de/mediathek/mediathek-meistgeklickt-100-meta.xml'})
	libMediathek.addEntry({'name':'Sendungen AZ', 'mode':'libMdrListShows'})
	#libMediathek.addEntry({'name':'test', 'mode':'libMdrListVideos', 'url':'http://www.mdr.de/tv/programm/mordenimnorden100-meta.xml'})
	#libMediathek.addEntry({'name':'mdr+', 'mode':'libMdrListVideos', 'url':'http://www.mdr.de/mediathek/livestreams/mdr-plus/mediathek-mdrplus-100-meta.xml'})
	libMediathek.addEntry({'name':'mdr+', 'mode':'libMdrListPlus', 'url':'http://www.mdr.de/mediathek/livestreams/mdr-plus/mediathek-mdrplus-100-meta.xml'})
	#libMediathek.addEntry({'name':'day', 'mode':'pDays'})
	#libMediathek.addEntry({'name':'Neue Videos', 'mode':'libMdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungverpasst/sendung-verpasst-100~_format-mp111_type-rss.feed'})
	#libMediathek.addEntry({'name':translation(31032), 'mode':'libMdrListLetters'})
	#libMediathek.addEntry({'name':'Videos in Gebärdensprache', 'mode':'libMdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/videos-dgs-100~_format-mp111_type-rss.feed'})
	#libMediathek.addEntry({'name':'Videos mit Untertiteln', 'mode':'libMdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/videos-untertitel-100~_format-mp111_type-rss.feed'})
	
	#libMediathek.addEntry({'name':translation(31033), 'mode':'libMdrListDate'})
	#libMediathek.addEntry({'name':translation(31034), 'mode':'libArdListVideos', 'url':'http://www.ardmediathek.de/appdata/servlet/tv/Rubriken/mehr?documentId=21282550&json'})
	
def pDays():
	libMediathek.addEntries(libMdrMetaParser.parseDays())
	
def libMdrBroadcast():
	libMediathek.addEntries(libMdrMetaParser.parseBroadcast(params['url']))
	
def libMdrListLetters():
	libMediathek.populateDirAZ('libMdrListShows',ignore=['#'])
	
def libMdrListShows():
	xbmc.log('listshows')
	from operator import itemgetter
	l = sorted(libMdrMetaParser.testparse(), key=itemgetter('name')) 
	libMediathek.addEntries(l)
def libMdrListPlus():
	xbmc.log('listplus')
	libMediathek.addEntries(libMdrMetaParser.parseMdrPlus(params['url']))
	
def libMdrListVideos():
	libMediathek.addEntries(libMdrMetaParser.parseVideos(params['url']))
	#libMediathek.addEntries(libMdrRssParser.parseVideos(params['url']))
	
def libMdrListDate():
	libMediathek.populateDirDate('libMdrListDateVideos')
	
def libMdrListDateVideos():
	libMdrMetaParser.parseDays()
	#libMediathek.addEntries(libMdrJsonParser.parseDate(params['date'],params['name']))#params['date'] =yyyy-mm-dd
	
def libMdrPlay():
	url = libMdrMetaParser.parseVideo(params['url'])
	xbmc.log(url)
	listitem = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
	
	
def list():	
	modes = {
	'libMdrBroadcast': libMdrBroadcast,
	'pDays': pDays,
	
	
	'libMdrListLetters': libMdrListLetters,
	'libMdrListShows': libMdrListShows,
	'libMdrListPlus': libMdrListPlus,
	'libMdrListVideos': libMdrListVideos,
	'libMdrListDate': libMdrListDate,
	'libMdrListDateVideos': libMdrListDateVideos,
	#'libMdrListDateChannels': libMdrListDateChannels,
	'libMdrPlay': libMdrPlay
	}
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	xbmc.log('mode')
	xbmc.log(params.get('mode',''))
	if not params.has_key('mode'):
		libMdrListMain()
	else:
		modes.get(params['mode'],libMdrListMain)()
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	