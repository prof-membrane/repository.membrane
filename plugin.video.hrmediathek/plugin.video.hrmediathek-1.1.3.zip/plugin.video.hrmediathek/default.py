﻿# -*- coding: utf-8 -*-
import libhr

libhr.list()

"""

import xbmc
import xbmcgui
import libmediathek3 as libMediathek

libMediathek.endOfDirectory()
dialog = xbmcgui.Dialog()
title = 'HR Mediathek'
text = 'Wegen Änderungen an der HR Website ist die HR-Mediathek bis auf Weiteres nicht verfügbar.'
dialog.ok(title, text)
xbmc.executebuiltin('XBMC.ActivateWindow(Home)')

"""