﻿# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import libmediathek3 as libMediathek
import libhr

libhr.list()

"""
libMediathek.endOfDirectory()
dialog = xbmcgui.Dialog()
title = 'HR Mediathek'
text = 'Aufgrund von Änderungen an der HR Website ist die HR-Mediathek für Kodi bis auf Weiteres nicht verfügbar.'
dialog.ok(title, text)
xbmc.executebuiltin('XBMC.ActivateWindow(Home)')
"""