# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import libArd
import listing
import urllib

channelList = {'daserste':'208',
			   'br':'2224',
			   'wdr':'5902',
			   'einsfestival':'673348',
			   'mdr':'5882',
			   'mdrsachsen':'1386804',
			   'mdrthüringen':'1386988',
			   'mdrsachsenanhalt':'1386898',
			   'rbb':'5874',
			  }
whitelistGeneral = 	[
						"ardmittagsmagazin",
					]

whitelistShow =		{
						"Unser Sandmännchen":"http://www.ardmediathek.de/tv/Unser-Sandm%C3%A4nnchen/Sendung?documentId=11094342&bcastId=11094342&m23644322=quelle.tv&rss=true",
						"ARD-Mittagsmagazin":"http://www.ardmediathek.de/tv/Mittagsmagazin/Sendung?documentId=314636&bcastId=314636&m23644322=quelle.tv&rss=true",
						"Wer weiß denn sowas?":"http://www.ardmediathek.de/tv/Wer-wei%C3%9F-denn-sowas/Sendung?documentId=29322328&bcastId=29322328&m23644322=quelle.tv&rss=true",
					}

def play(dict):
	video = False
	video = _searchDateList(dict)
	#if not video and dict["name"] in whitelistShow:#TODO
	#	video = _searchShow(dict)
		
	#if not video:#last ditch efford
	#	video = _searchGeneral(dict)
		
	if not video:
		xbmc.executebuiltin("Notification(Kein Video gefunden,Nicht in Mediathek, 7000)")
		xbmc.log("no video found")
		return
		
	xbmc.log('############################')
	xbmc.log(str(video))
	xbmc.log(video["name"])
	xbmc.log(dict["name"])
	showSubtitles = False
	url,sub = libArd.getVideoUrl(video["documentId"],showSubtitles)
	listitem = xbmcgui.ListItem(label=dict["name"],thumbnailImage=video["thumb"],path=url)

	xbmc.Player().play(url, listitem)
	
def _searchDateList(dict):
	items = listing.listDate('http://www.ardmediathek.de/tv/sendungVerpasst?tag='+str(dict["day"])+'&kanal='+channelList[dict["channel"]])
	return _pickEpisode(dict,items)
	
def _searchShow(dict):
	items,nextPage = libArd.getPage(whitelistShow[dict["name"]])
	return _pickEpisode(dict,items)
	
def _searchGeneral(dict):
	#searchString = urllib.quote_plus(dict["episode"])
	searchString = urllib.quote_plus(dict["name"])
	xbmc.log(searchString)
	items = libArd.getSearch(searchString)
	return _pickEpisode(dict,items)
		
def _pickEpisode(dict,items):
	duration = 0
	video = False
	for item in items:
		xbmc.log(str(item))
		HH,MM = item["time"].split(":")
		t = int(HH) * 60 + int(MM)
		if dict["time"] == t:
			if int(item["duration"]) > duration:#picks the longest video, shows may be split up into chuncks
				#TODO: handle videos for audio disabled
				video = item
				duration = int(item["duration"])
	return video
	