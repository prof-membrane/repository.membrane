# -*- coding: utf-8 -*-
import xbmc
import lib.libArd as libArd

libArd.list()