# -*- coding: utf-8 -*-
import listing
import rssparser
import player
import subtitle


def getNew(entries=50):
	return listing.listRSS('http://www.ardmediathek.de/tv/Neueste-Videos/mehr?documentId=23644268&m23644322=quelle.tv&rss=true')[:entries]
def getMostViewed(entries=50):
	return listing.listRSS('http://www.ardmediathek.de/tv/Meistabgerufene-Videos/mehr?documentId=21282514&m23644322=quelle.tv&rss=true')[:entries]
def getAZ(letter):
	return listing.getAZ(letter)
def getDate(url):
	return listing.listDate(url)
def getSearch(search_string,page=0):
	return listing.listVideos('http://www.ardmediathek.de/suche?searchText='+search_string)

def getVideoUrl(url,sub=False):
	if sub:
		videoID = url.split('documentId=')[1]
		if '&' in videoID:
			videoID = videoID.split('&')[0]
		return player.getVideoUrl(url),subtitle.getSub(videoID)
	else:
		return player.getVideoUrl(url),False
def getPage(url,page=1):
	return listing.listRSS(url,page)
	
#def getAZ(letter):
#	return listing.getAZ(letter)
def getVideosXml(videoId):
	return listing.getVideosXml(videoId)
def parser(data):
	return rssparser.parser(data)
	
	