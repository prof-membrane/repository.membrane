#!/usr/bin/python
# -*- coding: utf-8 -*-
import re
import sys
import xbmcplugin
import xbmcgui
import urllib
import rssparser
import _utils as utils
useThumbAsFanart = True
baseUrl = "http://www.ardmediathek.de"
defaultThumb = baseUrl+"/ard/static/pics/default/16_9/default_webM_16_9.jpg"
defaultBackground = "http://www.ard.de/pool/img/ard/background/base_xl.jpg"
icon = ''#todo

def listRSS(url,page=1):
	print url
	if page != 1:
		url += '&mcontents=page.'+str(page)
	print url
	response = utils.getUrl(url)
	return rssparser.parser(response)
def getAzList(letter):
	print 'ARD getaz'
	items = []
	l = getAZ(letter)
	for name, url, thumb in l:
		#u = sys.argv[0]+"?url="+urllib.quote_plus(baseUrl+url+'&m23644322=quelle.tv&rss=true')+"&name="+urllib.quote_plus(name)+"&mode=listVideosRss"+"&nextpage=True"+"&hideshowname=True"+"&showName="+urllib.quote_plus(name)
		u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&name="+urllib.quote_plus(name)+"&mode=2"+"&nextpage=True"+"&hideshowname=True"+"&showName="+urllib.quote_plus(name)
		liz = xbmcgui.ListItem(name, iconImage=defaultThumb, thumbnailImage=thumb)
		liz.setInfo(type="Video", infoLabels={"Title": name})
		if useThumbAsFanart:
			if not thumb or thumb==icon or thumb==defaultThumb:
				thumb = defaultBackground
			liz.setProperty("fanart_image", thumb)
		else:
			liz.setProperty("fanart_image", defaultBackground)
		items.append([u, liz, True])
	return items
		

def getAZ(letter):
	if letter == '#':
		letter = '0-9'
	list = []
	content = utils.getUrl(baseUrl+"/tv/sendungen-a-z?buchstabe="+letter)
	spl = content.split('<div class="teaser" data-ctrl')
	for i in range(1, len(spl), 1):
		dict = {}
		entry = spl[i]
		url = re.compile('href="(.+?)"', re.DOTALL).findall(entry)[0]
		dict['url'] = baseUrl+url.replace("&amp;","&")+'&m23644322=quelle.tv&rss=true'
		dict['name'] = re.compile('class="headline">(.+?)<', re.DOTALL).findall(entry)[0]
		dict['channel'] = re.compile('class="subtitle">(.+?)<', re.DOTALL).findall(entry)[0]
		thumbId = re.compile('/image/(.+?)/16x9/', re.DOTALL).findall(entry)[0]
		dict['thumb'] = baseUrl+"/image/"+thumbId+"/16x9/0"
		list.append(dict)
	return list
	
def getVideosXml(videoId):
	print 'getxml'
	list = []
	content = utils.getUrl(baseUrl+'/ard/servlet/export/collection/collectionId='+videoId+'/index.xml')
	match = re.compile('<content>(.+?)</content>', re.DOTALL).findall(content)
	for item in match:
		clip = re.compile('<clip(.+?)>', re.DOTALL).findall(item)[0]
		if 'isAudio="false"' in clip:
			name = re.compile('<name>(.+?)</name>', re.DOTALL).findall(item)[0]
			length = re.compile('<length>(.+?)</length>', re.DOTALL).findall(item)[0]
			if not '<mediadata:images/>' in item:
				thumb = re.compile('<image.+?url="(.+?)"', re.DOTALL).findall(item)[-1]
			else:
				thumb = ''
			id = re.compile(' id="(.+?)"', re.DOTALL).findall(clip)[0]
			list.append([name, id, thumb, length])
	return list
	

def listDate(url):
	list =[]
	response = utils.getUrl(url)
	match = re.compile('<div class="infoText">(.+?)<div class="box">', re.DOTALL).findall(response)
	entries = match[0].split('<div class="box"')
	for entry in entries:
		videos = entry.split('<div class="entry" data-ctrl-VORABENDcollapse-entry="')
		videos = videos[1:]
		for video in videos:
			date = re.compile('<span class="date">(.+?)</span>', re.DOTALL).findall(video)[0]
			titel = re.compile('<span class="titel">(.+?)</span>', re.DOTALL).findall(video)[0]
			match = re.compile('<div class="media mediaA">.+?<a href="(.+?)" class="mediaLink">.+?urlScheme&#039;:&#039;(.+?)##width##.+?<h4 class="headline">(.+?)</h4>.+?<p class="subtitle">(.+?)</p>', re.DOTALL).findall(video)
			#http://www.ardmediathek.de/ard/servlet/image/00/32/75/15/44/1547339463/16x9/320
			for url,thumb,name,plot in match:
				dict = {}
				length = plot.split(' ')[0]
				l = length.split(':')
				dict['duration'] = str(int(l[0])*60+int(l[1]))
				dict['name'] = date + ' ' + titel+' - '+name
				dict['thumb'] = 'http://www.ardmediathek.de/ard/servlet'+thumb+'0'
				dict['plot'] = plot
				dict['url'] = baseUrl+url
				list.append(dict)
		#print entry
		
	return list
	
def listVideos(url,page=1):
	list =[]
	content = utils.getUrl(url)
	spl = content.split('<div class="teaser" data-ctrl')
	for i in range(1, len(spl), 1):
		entry = spl[i]
		match = re.compile('documentId=(.+?)&', re.DOTALL).findall(entry)
		videoID = match[0]
		matchTitle = re.compile('class="headline">(.+?)<', re.DOTALL).findall(entry)
		match = re.compile('class="dachzeile">(.+?)<', re.DOTALL).findall(entry)
		if match and match[0].endswith("Uhr"):
			date = match[0]
			date = date.split(" ")[0]
			date = date[:date.rfind(".")]
			if showDateInTitle:
				title = date+" - "+matchTitle[0]
		elif match:
			title = match[0]+" - "+matchTitle[0]
		else:
			title = matchTitle[0]
		match = re.compile('class="subtitle">(.+?) \\| (.+?) min(.+?)</p>', re.DOTALL).findall(entry)
		match2 = re.compile('class="subtitle">(.+?) min.*?</p>', re.DOTALL).findall(entry)
		#plot = re.compile('<class="teasertext">(.+?)<', re.DOTALL).findall(entry)[0]
		plot = ''
		duration = ""
		desc = ""
		if match:
			date = match[0][0]
			date = date[:date.rfind(".")]
			duration = match[0][1]
			channel = match[0][2].replace("<br/>","")
			if "00:" in duration:
				duration = 1
			if showDateInTitle:
				title = date+" - "+title
			desc = channel+" ("+date+")\n"+title
		elif match2:
			duration = match2[0]
			if "00:" in duration:
				duration = 1
		title = cleanTitle(title)
		match = re.compile('/image/(.+?)/16x9/', re.DOTALL).findall(entry)
		thumb = ""
		if match:
			thumb = baseUrl+"/image/"+match[0]+"/16x9/448"
		#addLink(title, videoID, 'playVideo', thumb, duration, desc)
		list.append([title,videoID,thumb,plot,duration])
	return list
	

def cleanTitle(title):
	title = title.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&#034;", "\"").replace("&#039;", "'").replace("&quot;", "\"").replace("&szlig;", "�").replace("&ndash;", "-")
	title = title.replace("&Auml;", "�").replace("&Uuml;", "�").replace("&Ouml;", "�").replace("&auml;", "�").replace("&uuml;", "�").replace("&ouml;", "�").replace("&eacute;", "�").replace("&egrave;", "�")
	title = title.replace("&#x00c4;","�").replace("&#x00e4;","�").replace("&#x00d6;","�").replace("&#x00f6;","�").replace("&#x00dc;","�").replace("&#x00fc;","�").replace("&#x00df;","�")
	title = title.replace("&apos;","'").strip()
	return title