# -*- coding: utf-8 -*-
import libmediathek3 as libMediathek
import xbmc
import xbmcplugin
import xbmcgui
import json
import libwdr as libWdr

def main():
	l = []
	l.append({'name':'2016', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-106~_format-mp111_type-rss.feed'})
	l.append({'name':'2015', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-108~_format-mp111_type-rss.feed'})
	l.append({'name':'2014', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-110~_format-mp111_type-rss.feed'})
	l.append({'name':'2013', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-112~_format-mp111_type-rss.feed'})
	l.append({'name':'2012', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-114~_format-mp111_type-rss.feed'})
	l.append({'name':'2011', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-116~_format-mp111_type-rss.feed'})
	l.append({'name':'2010', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-118~_format-mp111_type-rss.feed'})
	l.append({'name':'2009', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-120~_format-mp111_type-rss.feed'})
	l.append({'name':'2008', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-122~_format-mp111_type-rss.feed'})
	l.append({'name':'2007', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-124~_format-mp111_type-rss.feed'})
	l.append({'name':'2006', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-126~_format-mp111_type-rss.feed'})
	l.append({'name':'2005', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-128~_format-mp111_type-rss.feed'})
	l.append({'name':'2004', 'mode':'libWdrListFeed', 'url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/rockpalast-132~_format-mp111_type-rss.feed'})
	l.append({'name':'Älter', 'mode':'oldVideos'})
	return l
	
def oldVideos():
	#TODO:
	#http://www1.wdr.de/mediathek/video/sendungen/rockpalast/video-joan-armatrading-in-essen--100.html
	#http://www1.wdr.de/mediathek/video/sendungen/rockpalast/video-joan-armatrading-in-koeln--102.html
	#http://www1.wdr.de/mediathek/video/sendungen/rockpalast/video-mothers-finest--102.html
	#http://www1.wdr.de/mediathek/video/sendungen/rockpalast/video-rockpalast-amor--carl-carlton--the-songdogs-crossroads-102.html
	#http://www1.wdr.de/mediathek/video/sendungen/rockpalast/video-thumb-100.html #bizarre neue nacht?!
	
	l = []
	l.append({'name':'Mother\'s Finest (1978)','plot':'Mothers Finest eröffneten die Live-Übertragung der 2. Rocknacht mit einem absoluten Power Konzert. Eine pulsierende Mischung aus (Hard)Rock, Funk und Soul. Im Mittelpunkt Sängerin Joyce Kennedy. Ein Höhepunkt: Wizzards Bass Solo. Nach dem Rockpalast Konzert waren Mothers Finest in ganz Europa bekannt.','thumb':'http://www1.wdr.de/fernsehen/rockpalast/bands/mothers-finest-100~_v-gseapremiumxl.jpg','url':'http://www1.wdr.de/mediathek/video/sendungen/rockpalast/video-mothers-finest--100.html','aired':'1987-03-04','duration':'3594','mode':'libWdrPlay','type':'video'})
	#l.append({'name':'','plot':'','thumb':'','url':'','aired':'','duration':''})
	return l

def list():	
	global params
	params = libMediathek.get_params()
	global pluginhandle
	pluginhandle = int(sys.argv[1])
	
	mode = params.get('mode','main')
	if mode.startswith('libWdr'):
		libWdr.list()
	else:
		xbmc.log
		l = modes.get(mode)()
		libMediathek.addEntries(l)
		xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)	

modes = {
'main': main,
'oldVideos': oldVideos,
}	

list()